﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
   public class Order
    {
        public string txt_no { get; set; }
        public string txt_prDate { get; set; }
        public string txt_phoneNo { get; set; }
        public string pr_buyer { get; set; }
        public string pr_biz { get; set; }
        public string pr_center { get; set; }

        public string pr_fund { get; set; }
        public string pr_district { get; set; }
        public string pr_institute { get; set; }
        public string pr_institutePw { get; set; }
        public string txt_name { get; set; }
        public string txt_product { get; set; }
        public string txt_reason { get; set; }
        public string txt_count { get; set; }
        public string txt_total { get; set; }

        public string box_method { get; set; }
        public string box_day { get; set; }
        public string txt_vendor { get; set; }
        public string txt_1 { get; set; }

        public string txt_2 { get; set; }
        public string txt_3 { get; set; }
        public string txt_label1 { get; set; }

        public string txt_label2 { get; set; }
        public string txt_label3 { get; set; }
        public string txt_buyer { get; set; }
        public string txt_leaderBuyer { get; set; }



    }
}

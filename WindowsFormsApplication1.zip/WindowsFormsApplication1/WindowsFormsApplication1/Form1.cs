﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using Word = Microsoft.Office.Interop.Word;
using System.Data.OleDb;
using SergeUtils;


namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {

        /* private Excel.Application App;
         private Excel.Range rng = null;*/
        DataTable dt = new DataTable();
        static SetOfData1 ds = new SetOfData1();
        Product prd = new Product();
        Dictionary<string, string> gl = new Dictionary<string, string>();
        Dictionary<string, string> ba = new Dictionary<string, string>();
        Dictionary<string, string> fund = new Dictionary<string, string>();
        Dictionary<string, string> costCenter = new Dictionary<string, string>();
        Dictionary<string, string> functionalArea = new Dictionary<string, string>();



        public class MethodItem
        {
            public string Name { get; set; }
            public StringMatchingMethod Value { get; set; }
        }


        public Form1()
        {

            InitializeComponent();

            DataColumn dc1 = new DataColumn("ที่", typeof(string));
            DataColumn dc2 = new DataColumn("รหัสภาระผูกพัน (ผังบัญชี) / รหัสสินทรัพย์", typeof(string));
            DataColumn dc3 = new DataColumn("ภาระผูกพัน (ผังบัญชี) / หมวดสินทรัพย์", typeof(string));
            DataColumn dc4 = new DataColumn("รายการและรายละเอียด", typeof(string));
            DataColumn dc5 = new DataColumn("จำนวน", typeof(int));
            DataColumn dc6 = new DataColumn("หน่วยนับ", typeof(string));
            DataColumn dc7 = new DataColumn("ราคาต่อหน่วย", typeof(int));
            DataColumn dc8 = new DataColumn("ราคาครั้งหลังสุด / ท้องตลาด", typeof(int));
            DataColumn dc9 = new DataColumn("วงเงินที่จะซื้อ / จ้าง", typeof(int));

            dt.Columns.Add(dc1);
            dt.Columns.Add(dc2);
            dt.Columns.Add(dc3);
            dt.Columns.Add(dc4);
            dt.Columns.Add(dc5);
            dt.Columns.Add(dc6);
            dt.Columns.Add(dc7);
            dt.Columns.Add(dc8);
            dt.Columns.Add(dc9);



        }

        public Order orderPr = new Order();

        NamePwd namePwd = new NamePwd();



        private void Form1_Load(object sender, EventArgs e)
        {
            gl = namePwd.addDictionaryGl();


        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            string[] glPw = null;
            glPw = order_gl.Text.Split(new[] { "  /  " }, StringSplitOptions.None);
            order_glPw.Text = glPw[1];
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void label26_Click(object sender, EventArgs e)
        {

        }

        private void label22_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        public DataTable ReadExcel(string fileName, string fileExt)
        {
            string conn = string.Empty;
            DataTable dtexcel = new DataTable();

            if (fileExt.CompareTo(".xls") == 0)
                conn = @"provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + fileName + ";Extended Properties='Excel 8.0;HRD=Yes;IMEX=1';"; //for below excel 2007  
            else
                conn = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + fileName + ";Extended Properties='Excel 12.0;HDR=NO';"; //for above excel 2007  
            using (OleDbConnection con = new OleDbConnection(conn))
            {
                try
                {
                    // OleDbDataAdapter oleAdpt = new OleDbDataAdapter("select F2 as fileName from [Sheet1$]", con); //here we read data from sheet1  
                    OleDbDataAdapter oleAdpt = new OleDbDataAdapter("select * from [Sheet1$]", con); //here we read data from sheet1  
                    oleAdpt.Fill(dtexcel); //fill excel data into dataTable  
                }
                catch { }
            }
            return dtexcel;
        }

        /*    private void box_attach_Click(object sender, EventArgs e)
            {
                /*string filePath = string.Empty;
                string fileExt = string.Empty;
                OpenFileDialog file = new OpenFileDialog(); //open dialog to choose file  
                if (file.ShowDialog() == System.Windows.Forms.DialogResult.OK) //if there is a file choosen by the user  
                {
                    filePath = file.FileName; //get the path of the file  
                    fileExt = Path.GetExtension(filePath); //get the file extension  
                    if (fileExt.CompareTo(".xls") == 0 || fileExt.CompareTo(".xlsx") == 0)
                    {
                        try
                        {
                            DataTable dtExcel = new DataTable();
                            dtExcel = ReadExcel(filePath, fileExt); //read excel file  
                            dataGridView1.Visible = true;

                            dataGridView1.DataSource = dtExcel;
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message.ToString());
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please choose .xls or .xlsx file only.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error); //custom messageBox to show error  
                    }
                }

                OpenFileDialog OFD = new OpenFileDialog();
                OFD.Filter = "Excel Worksheets|*.xls;*.xlsx;*.xlsm;*.csv";
                if (OFD.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    App = new Excel.Application();
                    App.Visible = true;
                    App.Workbooks.Open(OFD.FileName);
                }
                else { return; }

                try { rng = (Excel.Range)App.InputBox("Please select a range", "Range Selection", Type: 8); }
                catch { } // user pressed cancel on input box

                if (rng != null)
                {
                    // DataTable dt = ConvertRangeToDataTable();
                    dt = ConvertRangeToDataTable();
                    if (dt != null) { dataGridView1.DataSource = dt; }
                }
                _Dispose();

            }
            */
        /*
        private DataTable ConvertRangeToDataTable()
        {
            try
            {
                DataTable dt = new DataTable();
                int ColCount = rng.Columns.Count;
                int RowCount = rng.Rows.Count;

                /*   for (int i = 0; i < ColCount; i++)
                   {
                       DataColumn dc = new DataColumn();
                       dt.Columns.Add(dc);
                   } 
                DataColumn dc1 = new DataColumn("ที่", typeof(string));
                DataColumn dc2 = new DataColumn("รหัสภาระผูกพัน (ผังบัญชี)", typeof(string));
                DataColumn dc3 = new DataColumn("ภาระผูกพัน (ผังบัญชี)", typeof(string));
                DataColumn dc4 = new DataColumn("รายการและรายละเอียด", typeof(string));
                DataColumn dc5 = new DataColumn("จำนวน", typeof(string));
                DataColumn dc6 = new DataColumn("หน่วยนับ", typeof(string));
                DataColumn dc7 = new DataColumn("ราคาต่อหน่วย", typeof(string));
                DataColumn dc8 = new DataColumn("ราคาครั้งหลังสุด / ท้องตลาด", typeof(string));
                DataColumn dc9 = new DataColumn("วงเงินที่จะซื้อ / จ้าง", typeof(string));
                dt.Columns.Add(dc1);
                dt.Columns.Add(dc2);
                dt.Columns.Add(dc3);
                dt.Columns.Add(dc4);
                dt.Columns.Add(dc5);
                dt.Columns.Add(dc6);
                dt.Columns.Add(dc7);
                dt.Columns.Add(dc8);
                dt.Columns.Add(dc9);
          
                for (int i = 1; i <= RowCount; i++)
                {
                    DataRow dr = dt.NewRow();
                    dr[0] = rng.Cells[i, 1].Value2;
                    dr[1] = rng.Cells[i, 8].Value2;
                    dr[2] = rng.Cells[i, 7].Value2;
                    dr[3] = rng.Cells[i, 2].Value2;
                    dr[4] = rng.Cells[i, 3].Value2;
                    dr[5] = rng.Cells[i, 4].Value2;
                    dr[6] = rng.Cells[i, 5].Value2;
                    dr[7] = null;
                    dr[8] = rng.Cells[i, 6].Value2;
                    dt.Rows.Add(dr);
                }
                return dt;
            }
            catch { return null; }
        }

        private void _Dispose()
        {
            try { System.Runtime.InteropServices.Marshal.ReleaseComObject(rng); }
            catch { }
            finally { rng = null; }
            try { App.Quit(); System.Runtime.InteropServices.Marshal.ReleaseComObject(App); }
            catch { }
            finally { App = null; }
        }
*/
        private void label27_Click(object sender, EventArgs e)
        {

        }

        private void label30_Click(object sender, EventArgs e)
        {

        }

        private void label29_Click(object sender, EventArgs e)
        {

        }

        private void label32_Click(object sender, EventArgs e)
        {

        }

        private void label35_Click(object sender, EventArgs e)
        {

        }
        /* public void createnewrow()
         {
             if (dt.Rows.Count <= 0)
             {

                 DataColumn dc1 = new DataColumn("ที", typeof(int));
                 DataColumn dc2 = new DataColumn("ภาระผูกพัน", typeof(string));
                 DataColumn dc3 = new DataColumn("ประเภทสินค้า", typeof(string));
                 DataColumn dc4 = new DataColumn("รายการและรายละเอียด", typeof(string));
                 DataColumn dc5 = new DataColumn("จำนวน", typeof(int));
                 DataColumn dc6 = new DataColumn("หน่วยนับ", typeof(string));
                 DataColumn dc7 = new DataColumn("ราคาในท้องตลาดปัจจุบัน", typeof(int));
                 DataColumn dc8 = new DataColumn("ราคาครั้งหลังสุดต่อหน่วย", typeof(int));
                 DataColumn dc9 = new DataColumn("วงเงิน", typeof(int));


                 dt.Columns.Add(dc1);
                 dt.Columns.Add(dc2);
                 dt.Columns.Add(dc3);
                 dt.Columns.Add(dc4);
                 dt.Columns.Add(dc5);
                 dt.Columns.Add(dc6);
                 dt.Columns.Add(dc7);
                 dt.Columns.Add(dc8);
                 dt.Columns.Add(dc9);





                 dt.Rows.Add(order_no.Text, order_gl.SelectedItem.ToString(), order_boxProductType.SelectedItem.ToString(), order_productDetail.Text, Convert.ToInt32(order_noUnit.Text), order_typeofunit.Text, Convert.ToInt32(order_unitPrice.Text), Convert.ToInt32(order_unitPrice.Text),Convert.ToInt32(order_total.Text));


                 dataGridView2.DataSource = dt;
                 ds.Tables.Add(dt);

             }
             else
             {

                 dt.Rows.Add(order_no.Text, order_gl.SelectedItem.ToString(), order_boxProductType.SelectedItem.ToString(), order_productDetail.Text, Convert.ToInt32(order_noUnit.Text), order_typeofunit.Text, Convert.ToInt32(order_unitPrice.Text), Convert.ToInt32(order_unitPrice.Text), Convert.ToInt32(order_total.Text));

                 dataGridView2.DataSource = dt;


             }
         }
 */


        public void createnewrow()
        {
            if (order_lastPrice.Text != "")
            {
                string[] gl = null;
                gl = order_gl.Text.Split(new[] { "  /  " }, StringSplitOptions.None);
                dt.Rows.Add(order_no.Text, order_glPw.Text, gl[0], order_productDetail.Text, Convert.ToInt32(order_noUnit.Text), order_typeofunit.Text, Convert.ToInt32(order_unitPrice.Text), order_lastPrice.Text, Convert.ToInt32(order_total.Text));
            }
            else
            {
                string[] gl = null;
                gl = order_gl.Text.Split(new[] { "  /  " }, StringSplitOptions.None);
                dt.Rows.Add(order_no.Text, order_glPw.Text, gl[0], order_productDetail.Text, Convert.ToInt32(order_noUnit.Text), order_typeofunit.Text, Convert.ToInt32(order_unitPrice.Text), null, Convert.ToInt32(order_total.Text));
            }
            dataGridView2.DataSource = dt;
        }

        private void button1_Click(object sender, EventArgs e)
        {


            if (order_gl.Text != "" && order_gl.Text != "ประเภทภาระผูกพัน / หมวดทรัพย์สิน" && order_glPw.Text != "" && order_productDetail.Text != "" && order_productDetail.Text != "กรุณากรอกรายการและรายละเอียดสินค้า" && order_typeofunit.Text != "" && order_unitPrice.Text != "" && order_unitPrice.Text != "กรุณากรอกหน่วยนับ" && order_noUnit.Text != "" && order_total.Text != "")
            {

                if (!order_typeofunit.Items.Contains(order_typeofunit.Text))
                {
                    MessageBox.Show("กรุณาเลือก \"ลักษณะนาม\" ที่มีอยู่ในระบบเท่านั้น");
                    order_typeofunit.Text = "กรุณากรอกหน่วยนับ";
                }
                else {
                    createnewrow();
                    if (total(dt) > 0)
                    {
                        txt_total.Text = total(dt).ToString();
                    }
                    else
                    {
                        txt_total.Text = "0";
                    }
                    if (dt.Rows.Count > 0)
                    {
                        txt_count.Text = dt.Rows.Count.ToString();
                    }
                    else
                    {
                        txt_count.Text = "0";
                    }
                    order_no.Value++;
                    order_gl.Text = "ประเภทภาระผูกพัน";
                    order_glPw.ResetText();
                    order_boxProductType.Text = "ประเภทสินค้า";
                    order_productDetail.Text = "กรุณากรอกรายการและรายละเอียดสินค้า";
                    order_typeofunit.Text = "กรุณากรอกหน่วยนับ";
                    order_unitPrice.ResetText();
                    order_total.ResetText();
                    order_noUnit.ResetText();
                    order_lastPrice.ResetText();
                    btn_korGumNod.Visible = false;


                }
            }
            else
            {
                MessageBox.Show("กรุณากรอกข้อมูลให้ครบ");
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (order_no.Value != 0 && order_no.Value != 1) {
                dt.Rows.Remove(dt.Rows[dt.Rows.Count - 1]);
                order_no.Value--;
            }
            else
            {
                order_no.Value = 1;
            }

            if (total(dt) > 0)
            {
                txt_total.Text = total(dt).ToString();
            }
            else
            {
                txt_total.Text = "0";
            }
            if (dt.Rows.Count > 0)
            {
                txt_count.Text = dt.Rows.Count.ToString();
            }
            else
            {
                txt_count.Text = "0";
            }
        }

        private void listView2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            //listView_order.Items.Clear();
            dt.Rows.Clear();
            order_no.Value = 1;
            if (total(dt) > 0)
            {
                txt_total.Text = total(dt).ToString();
            }
            else
            {
                txt_total.Text = "0";
            }
            if (dt.Rows.Count > 0)
            {
                txt_count.Text = dt.Rows.Count.ToString();
            }
            else
            {
                txt_count.Text = "0";
            }
        }

        private void label36_Click(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label38_Click(object sender, EventArgs e)
        {

        }

        private void textBox13_TextChanged(object sender, EventArgs e)
        {

        }

        private void order_no_ValueChanged(object sender, EventArgs e)
        {

        }

        private void btn_save_Click(object sender, EventArgs e)
        {

        }

        private void box_center_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void order_total_TextChanged(object sender, EventArgs e)
        {
            /*
            try
            {
                if (order_total.Text != "" && Convert.ToInt32(order_total.Text) >= 30000 && Convert.ToInt32(order_total.Text) <= 500000)
                {
                    btn_korGumNod.Visible = true;
                    MessageBox.Show("กรุณา อย่าลืม! กรอกข้อกำหนด");
                    if (box_prBuyer.Text != "ขอซื้อ/จ้าง" && order_productDetail.Text != "กรุณากรอกรายการและรายละเอียดสินค้า" && order_productDetail.Text != "")
                    {
                        createWord();
                    }
                    else
                    {
                        MessageBox.Show("คุณยังทำรายการไม่ครบ" + Environment.NewLine + "กรุณาดูช่อง \"ประเภทเอกสาร\" และ \"รายการและรายละเอียด\" ว่าได้กรอกและเลือกครบแล้ว ");
                    }
                } else
                {
                    btn_korGumNod.Visible = false;
                }

            }
            catch
            {
                order_total.Text = "";
            }
            */
        }
        private void box_prBuyer_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (box_prBuyer.Text == "ใบขอจ้าง" || box_prBuyer.Text == "ใบขอเช่า") {

                MessageBox.Show("กรุณา อย่าลืม! กรอกข้อกำหนด");
                btn_korGumNodPrBuyer.Visible = true;
                object oMissing = System.Reflection.Missing.Value;
                object oEndOfDoc = "\\endofdoc"; /* \endofdoc is a predefined bookmark */

                //Start Word and create a new document.
                Word._Application oWord;
                Word._Document oDoc;
                oWord = new Word.Application();

                oWord.Visible = true;
                oDoc = oWord.Documents.Add(ref oMissing);

                //Insert a paragraph at the beginning of the document.
                Word.Paragraph oPara1;
                oPara1 = oDoc.Content.Paragraphs.Add(ref oMissing);
                if (box_prBuyer.Text == "ใบขอเช่า")
                {
                    oPara1.Range.Text = "ข้อกำหนดคุณสมบัติการเช่า";
                }
                else if (box_prBuyer.Text == "ใบขอจ้าง")
                {
                    oPara1.Range.Text = "ข้อกำหนดคุณสมบัติการจ้าง";
                }
                oPara1.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;

            }
            else
            {
                btn_korGumNodPrBuyer.Visible = false;
            }
        }

        private void txt_product_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btn_print_Click(object sender, EventArgs e)
        {
            int i = 2;
            if (txt_phoneNo.Text == "" || txt_vendor.Text == "" || txt_product.Text == "" || txt_reason.Text == "" || txt_buyer.Text == "" || txt_leaderBuyer.Text == "" || box_institutePw.Text == "")
            {
                i--;
            }
            foreach (Control c in this.Controls)
            {
                if (c is ComboBox)
                {
                    ComboBox comboBox = c as ComboBox;
                    if (comboBox.Text == string.Empty)
                    {
                        i--;
                    }
                }
            }
            if (i != 2)
            {
                MessageBox.Show("กรุณากรอกข้อมูลให้ครบ");
            } else if (Convert.ToInt32(txt_count.Text) == 0) {
                MessageBox.Show("กรุณากรอกข้อมูลให้ครบ");
            }
            else if ((btn_day.Checked == false && btn_date.Checked == false) || txt_phoneNo.Text == "กรุณากรอกเบอร์โทรศัพท์" || txt_vendor.Text == "กรุณากรอกชื่อผู้ประกอบการ" || box_institute.Text == "ประเภทหน่วยงาน" || box_institutePw.Text == "กรุณากรอกรหัส" || box_biz.Text == "ประเภทธุรกิจ" || box_center.Text == "ประเภทศูนย์ต้นทุน" || box_fund.Text == "ประเภทกองทุน / เงินทุน" || box_district.Text == "ประเภทเขตตามหน้าที่" || box_prBuyer.Text == "ขอซื้อ/จ้าง" || txt_name.Text == "กรุณาเลือกชื่อรองอธิการบดี" || txt_product.Text == "กรุณาระบุสิ่งที่ต้องการจัดซื้อหรือจัดจ้าง"
             || txt_reason.Text == "กรุณาระบุจุดประสงค์" || box_method.Text == "กรุณาเลือกวิธี" || txt_buyer.Text == "กรุณากรอกชื่อผู้ขอซื้อหรือขอจ้าง" || (txt_leaderBuyer.Text == "กรุณากรอกชื่อผู้อำนวยการของหน่วยงาน" || txt_leaderBuyer.Text == "กรุณากรอกชื่อผู้อำนวยการ" + box_institute.Text))
            {
                MessageBox.Show("กรุณากรอกข้อมูลให้ครบ");
            }
            else if (txt_staff1.Enabled == true && txt_committee1.Enabled == true && txt_president1.Enabled == true & txt_secretary1.Enabled == true && txt_committee2.Enabled == true && txt_president2.Enabled == true & txt_secretary2.Enabled == true)
            {
                MessageBox.Show("กรุณากรอกข้อมูลให้ครบ");
            }
            else if (btn_committeeCheck.Checked == true)
            {
                if (txt_president1.Text == "กรุณากรอกชื่อประธานกรรมการ" || txt_committee1.Text == "กรุณากรอกชื่อกรรมการ" || txt_secretary1.Text == "กรุณากรอกชื่อกรรมการและเลขานุการ")
                {
                    MessageBox.Show("กรุณากรอกข้อมูลให้ครบ");
                }
                else
                {
                    Print f2 = new Print();
                    f2.orderPr.txt_no = this.txt_no.Value.ToString();
                    f2.orderPr.txt_prDate = this.txt_prDate.Value.ToString();
                    f2.orderPr.txt_phoneNo = this.txt_phoneNo.Text;
                    f2.orderPr.pr_biz = this.box_biz.Text;
                    f2.orderPr.pr_center = this.box_center.Text;
                    f2.orderPr.pr_fund = this.box_fund.Text;
                    f2.orderPr.pr_district = this.box_district.Text;
                    f2.orderPr.pr_institute = this.box_institute.Text;
                    f2.orderPr.pr_institutePw = this.box_institutePw.Text;

                    if (box_prBuyer.Text == "ใบขอซื้อ")
                    {
                        f2.orderPr.pr_buyer = "ใบขอซื้อ";
                    }
                    else if (box_prBuyer.Text == "ใบขอจ้าง")
                    {
                        f2.orderPr.pr_buyer = "ใบขอจ้าง";
                    }
                    else if (box_prBuyer.Text == "ใบขอเช่า")
                    {
                        f2.orderPr.pr_buyer = "ใบขอเช่า";
                    }
                    f2.orderPr.txt_name = this.txt_name.Text;
                    f2.orderPr.txt_product = this.txt_product.Text;
                    f2.orderPr.txt_reason = this.txt_reason.Text;
                    f2.orderPr.box_method = this.box_method.Text;

                    if (btn_date.Checked == true)
                    {
                        f2.orderPr.box_day = "วันที่ " + txt_day.Value.ToLongDateString();
                    }
                    else
                    {
                        f2.orderPr.box_day = this.box_day.Text + " วัน";
                    }
                    f2.orderPr.txt_vendor = this.txt_vendor.Text;
                    f2.orderPr.txt_1 = "1. " + this.txt_president1.Text;
                    f2.orderPr.txt_2 = "2. " + this.txt_committee1.Text;
                    f2.orderPr.txt_3 = "3. " + this.txt_secretary1.Text;
                    f2.orderPr.txt_label1 = "ประธานกรรมการ";
                    f2.orderPr.txt_label2 = "กรรมการ";
                    f2.orderPr.txt_label3 = "กรรมการและเลขานุการ";
                    f2.orderPr.txt_buyer = this.txt_buyer.Text;
                    f2.orderPr.txt_leaderBuyer = this.txt_leaderBuyer.Text;
                    f2.orderPr.txt_total = this.txt_total.Text;
                    f2.orderPr.txt_count = this.txt_count.Text;
                    f2.Oong.dtable = dt;

                    f2.Show();
                }
            }
            else if (btn_personCheck.Checked == true)
            {
                if (txt_staff1.Text == "กรุณากรอกชื่อผู้ตรวจรับพัสดุ")
                {
                    MessageBox.Show("กรุณากรอกข้อมูลให้ครบ");
                }
                else
                {
                    Print f2 = new Print();
                    f2.orderPr.txt_no = this.txt_no.Value.ToString();
                    f2.orderPr.txt_prDate = this.txt_prDate.Value.ToString();
                    f2.orderPr.txt_phoneNo = this.txt_phoneNo.Text;
                    f2.orderPr.pr_biz = this.box_biz.Text;
                    f2.orderPr.pr_center = this.box_center.Text;
                    f2.orderPr.pr_fund = this.box_fund.Text;
                    f2.orderPr.pr_district = this.box_district.Text;
                    f2.orderPr.pr_institute = this.box_institute.Text;
                    f2.orderPr.pr_institutePw = this.box_institutePw.Text;

                    if (box_prBuyer.Text == "ใบขอซื้อ")
                    {
                        f2.orderPr.pr_buyer = "ใบขอซื้อ";
                    }
                    else if (box_prBuyer.Text == "ใบขอจ้าง")
                    {
                        f2.orderPr.pr_buyer = "ใบขอจ้าง";
                    }
                    else if (box_prBuyer.Text == "ใบขอเช่า")
                    {
                        f2.orderPr.pr_buyer = "ใบขอเช่า";
                    }
                    f2.orderPr.txt_name = this.txt_name.Text;
                    f2.orderPr.txt_product = this.txt_product.Text;
                    f2.orderPr.txt_reason = this.txt_reason.Text;
                    f2.orderPr.box_method = this.box_method.Text;

                    if (btn_date.Checked == true)
                    {
                        f2.orderPr.box_day = "วันที่ " + txt_day.Value.ToLongDateString();
                    }
                    else
                    {
                        f2.orderPr.box_day = this.box_day.Text + " วัน";
                    }
                    f2.orderPr.txt_vendor = this.txt_vendor.Text;
                    f2.orderPr.txt_1 = "1. " + this.txt_staff1.Text;
                    f2.orderPr.txt_2 = "";
                    f2.orderPr.txt_3 = "";
                    f2.orderPr.txt_label1 = "ผู้ตรวจรับพัสดุ";
                    f2.orderPr.txt_label2 = "";
                    f2.orderPr.txt_label3 = "";
                    f2.orderPr.txt_buyer = this.txt_buyer.Text;
                    f2.orderPr.txt_leaderBuyer = this.txt_leaderBuyer.Text;
                    f2.orderPr.txt_total = this.txt_total.Text;
                    f2.orderPr.txt_count = this.txt_count.Text;
                    f2.Oong.dtable = dt;

                    f2.Show();
                }

            }
            else if (txt_president2.Text == "กรุณากรอกชื่อประธานกรรมการ" || txt_committee2.Text == "กรุณากรอกชื่อกรรมการ" || txt_secretary2.Text == "กรุณากรอกชื่อกรรมการและเลขานุการ")
            {
                MessageBox.Show("กรุณากรอกข้อมูลให้ครบ");
            }
            else
            {
                Print f2 = new Print();
                f2.orderPr.txt_no = this.txt_no.Value.ToString();
                f2.orderPr.txt_prDate = this.txt_prDate.Value.ToString();
                f2.orderPr.txt_phoneNo = this.txt_phoneNo.Text;
                f2.orderPr.pr_biz = this.box_biz.Text;
                f2.orderPr.pr_center = this.box_center.Text;
                f2.orderPr.pr_fund = this.box_fund.Text;
                f2.orderPr.pr_district = this.box_district.Text;
                f2.orderPr.pr_institute = this.box_institute.Text;
                f2.orderPr.pr_institutePw = this.box_institutePw.Text;

                if (box_prBuyer.Text == "ใบขอซื้อ")
                {
                    f2.orderPr.pr_buyer = "ใบขอซื้อ";
                }
                else if (box_prBuyer.Text == "ใบขอจ้าง")
                {
                    f2.orderPr.pr_buyer = "ใบขอจ้าง";
                }
                else if (box_prBuyer.Text == "ใบขอเช่า")
                {
                    f2.orderPr.pr_buyer = "ใบขอเช่า";
                }
                f2.orderPr.txt_name = this.txt_name.Text;
                f2.orderPr.txt_product = this.txt_product.Text;
                f2.orderPr.txt_reason = this.txt_reason.Text;
                f2.orderPr.box_method = this.box_method.Text;

                if (btn_date.Checked == true)
                {
                    f2.orderPr.box_day = "วันที่ " + txt_day.Value.ToLongDateString();
                }
                else
                {
                    f2.orderPr.box_day = this.box_day.Text + " วัน";
                }
                f2.orderPr.txt_vendor = this.txt_vendor.Text;
                f2.orderPr.txt_1 = "1. " + this.txt_president2.Text;
                f2.orderPr.txt_2 = "2. " + this.txt_committee2.Text;
                f2.orderPr.txt_3 = "3. " + this.txt_secretary2.Text;
                f2.orderPr.txt_label1 = "ประธานกรรมการ";
                f2.orderPr.txt_label2 = "กรรมการ";
                f2.orderPr.txt_label3 = "กรรมการและเลขานุการ";
                f2.orderPr.txt_buyer = this.txt_buyer.Text;
                f2.orderPr.txt_leaderBuyer = this.txt_leaderBuyer.Text;
                f2.orderPr.txt_total = this.txt_total.Text;
                f2.orderPr.txt_count = this.txt_count.Text;
                f2.Oong.dtable = dt;

                f2.Show();
            }

            //txt_president1.Text == "กรุณากรอกชื่อประธานกรรมการ" || txt_committee1.Text == "กรุณากรอกชื่อกรรมการ" || txt_secretary1.Text == "กรุณากรอกชื่อกรรมการและเลขานุการ"


        }


        private void label25_Click(object sender, EventArgs e)
        {

        }

        private void order_noUnit_TextChanged(object sender, EventArgs e)
        {
            try
            {
                int a = Convert.ToInt32(order_noUnit.Text);
            }
            catch
            {
                order_noUnit.Text = "";
            }

            if (order_unitPrice.Text != "" && order_noUnit.Text != "")
            {
                try
                {
                    order_total.Text = (Convert.ToInt32(order_unitPrice.Text) * Convert.ToInt32(order_noUnit.Text)).ToString();
                }
                catch
                {
                    order_noUnit.Text = "";

                }


            } else if (order_unitPrice.Text == "" && order_noUnit.Text == "")
            {
                order_total.Text = "";
            }
        }

        private void order_unitPrice_TextChanged(object sender, EventArgs e)
        {

            try {
                int a = Convert.ToInt32(order_unitPrice.Text);
            }
            catch
            {
                order_unitPrice.Text = "";
            }


            if (order_unitPrice.Text != "" && order_noUnit.Text != "")
            {

                try
                {
                    order_total.Text = (Convert.ToInt32(order_unitPrice.Text) * Convert.ToInt32(order_noUnit.Text)).ToString();
                }
                catch
                {
                    order_unitPrice.Text = "";

                }
            }
            else if (order_unitPrice.Text == "" || order_noUnit.Text == "")
            {
                order_total.Text = "";
            }
        }

        private void btn_check_Click(object sender, EventArgs e)
        {
            string checkTxt = order_boxProductType.Text;

            //Index
            int karupunOfficeIndex = -2;
            int karupunVehicleIndex = -2;
            int karupunAgricultureIndex = -2;
            int karupunElectricalAndRadioIndex = -2;
            int karupunAdvertiseIndex = -2;
            int karupunMedicalIndex = -2;
            int karupunHomeAndKitchenIndex = -2;
            int karupunIndustryIndex = -2;
            int karupunSportIndex = -2;
            int karupunExploreIndex = -2;
            int karupunWeaponIndex = -2;
            int karupunMusicIndex = -2;
            int karupunComputerIndex = -2;
            /////
            int wassaduOfficeIndex = -2;
            int wassaduElectricAndRadioIndex = -2;
            int wassaduHomeAndKitchenIndex = -2;
            int wassaduVehicleIndex = -2;
            int wassaduFlameIndex = -2;
            int wassaduScienceAndMedIndex = -2;
            int wassaduAgriculturalIndex = -2;
            int wassaduAdvertisementIndex = -2;
            int wassaduSportIndex = -2;
            int wassaduComputerIndex = -2;
            int wassaduFieldIndex = -2;
            int wassaduEducationIndex = -2;
            int wassaduExploreIndex = -2;
            int wassaduMusicIndex = -2;
            int wassaduConstructIndex = -2;
            int wassaduClothesIndex = -2;

            //string of prd
            string[] karupunOffice = prd.karupunOffice();
            string[] karupunVehicle = prd.karupunVehicle();
            string[] karupunAgriculture = prd.karupunAgriculture();
            string[] karupunElectricalAndRadio = prd.karupunElectricalAndRadio();
            string[] karupunAdvertise = prd.karupunAdvertise();
            string[] karupunMedical = prd.karupunMedical();
            string[] karupunHomeAndKitchen = prd.karupunHomeAndKitchen();
            string[] karupunIndustry = prd.karupunIndustry();
            string[] karupunSport = prd.karupunSport();
            string[] karupunExplore = prd.karupunExplore();
            string[] karupunWeapon = prd.karupunWeapon();
            string[] karupunMusic = prd.karupunMusic();
            string[] karupunComputer = prd.karupunComputer();
            /////
            string[] wassaduOffice = prd.wassaduOffice();
            string[] wassaduElectricAndRadio = prd.wassaduElectricAndRadio();
            string[] wassaduHomeAndKitchen = prd.wassaduHomeAndKitchen();
            string[] wassaduVehicle = prd.wassaduVehicle();
            string[] wassaduFlame = prd.wassaduFlame();
            string[] wassaduScienceAndMed = prd.wassaduScienceAndMed();
            string[] wassaduAgricultural = prd.wassaduAgricultural();
            string[] wassaduAdvertisement = prd.wassaduAdvertisement();
            string[] wassaduSport = prd.wassaduSport();
            string[] wassaduComputer = prd.wassaduComputer();
            string[] wassaduField = prd.wassaduField();
            string[] wassaduEducation = prd.wassaduEducation();
            string[] wassaduExplore = prd.wassaduExplore();
            string[] wassaduMusic = prd.wassaduMusic();
            string[] wassaduConstruct = prd.wassaduConstruct();
            string[] wassaduClothes = prd.wassaduClothes();




            //string[] of prd

            string[] unitKarupunOffice = prd.unitKarupunOffice();
            string[] unitKarupunVehicle = prd.unitKarupunVehicle();
            string[] unitKarupunAgriculture = prd.unitKarupunAgriculture();
            string[] unitKarupunElectricalAndRadio = prd.unitKarupunElectricalAndRadio();
            string[] unitKarupunAdvertise = prd.unitKarupunAdvertise();
            string[] unitKarupunMedical = prd.unitKarupunMedical();
            string[] unitKarupunHomeAndKitchen = prd.unitKarupunHomeAndKitchen();
            string[] unitKarupunIndustry = prd.unitKarupunIndustry();
            string[] unitKarupunSport = prd.unitKarupunSport();
            string[] unitKarupunExplore = prd.unitKarupunExplore();
            string[] unitKarupunWeapon = prd.unitKarupunWeapon();
            string[] unitKarupunComputer = prd.unitKarupunComputer();
            ////

            //minimize
            int min = 1000;

            //method for
            for (int i = 0; i < karupunOffice.Length; i++)
            {
                if (checkTxt.IndexOf(karupunOffice[i]) != -1)
                {
                    karupunOfficeIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(karupunOffice[i]));
                }

            }
            for (int i = 0; i < karupunVehicle.Length; i++)
            {
                if (checkTxt.IndexOf(karupunVehicle[i]) != -1)
                {
                    karupunVehicleIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(karupunVehicle[i]));
                }

            }
            for (int i = 0; i < karupunAgriculture.Length; i++)
            {
                if (checkTxt.IndexOf(karupunAgriculture[i]) != -1)
                {
                    karupunAgricultureIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(karupunAgriculture[i]));
                }

            }
            for (int i = 0; i < karupunElectricalAndRadio.Length; i++)
            {
                if (checkTxt.IndexOf(karupunElectricalAndRadio[i]) != -1)
                {
                    karupunElectricalAndRadioIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(karupunElectricalAndRadio[i]));
                }

            }
            for (int i = 0; i < karupunAdvertise.Length; i++)
            {
                if (checkTxt.IndexOf(karupunAdvertise[i]) != -1)
                {
                    karupunAdvertiseIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(karupunAdvertise[i]));
                }

            }
            for (int i = 0; i < karupunMedical.Length; i++)
            {
                if (checkTxt.IndexOf(karupunMedical[i]) != -1)
                {
                    karupunMedicalIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(karupunMedical[i]));
                }

            }
            for (int i = 0; i < karupunHomeAndKitchen.Length; i++)
            {
                if (checkTxt.IndexOf(karupunHomeAndKitchen[i]) != -1)
                {
                    karupunHomeAndKitchenIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(karupunHomeAndKitchen[i]));
                }

            }
            for (int i = 0; i < karupunIndustry.Length; i++)
            {
                if (checkTxt.IndexOf(karupunIndustry[i]) != -1)
                {
                    karupunIndustryIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(karupunIndustry[i]));
                }

            }
            for (int i = 0; i < karupunSport.Length; i++)
            {
                if (checkTxt.IndexOf(karupunSport[i]) != -1)
                {
                    karupunSportIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(karupunSport[i]));
                }

            }
            for (int i = 0; i < karupunExplore.Length; i++)
            {
                if (checkTxt.IndexOf(karupunExplore[i]) != -1)
                {
                    karupunExploreIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(karupunExplore[i]));
                }

            }
            for (int i = 0; i < karupunWeapon.Length; i++)
            {
                if (checkTxt.IndexOf(karupunWeapon[i]) != -1)
                {
                    karupunWeaponIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(karupunWeapon[i]));
                }

            }
            for (int i = 0; i < karupunMusic.Length; i++)
            {
                if (checkTxt.IndexOf(karupunMusic[i]) != -1)
                {
                    karupunMusicIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(karupunMusic[i]));
                }

            }
            for (int i = 0; i < karupunComputer.Length; i++)
            {
                if (checkTxt.IndexOf(karupunComputer[i]) != -1)
                {
                    karupunComputerIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(karupunComputer[i]));
                }

            }
            ////

            for (int i = 0; i < wassaduOffice.Length; i++)
            {
                if (checkTxt.IndexOf(wassaduOffice[i]) != -1)
                {
                    wassaduOfficeIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(wassaduOffice[i]));
                }

            }

            for (int i = 0; i < wassaduElectricAndRadio.Length; i++)
            {
                if (checkTxt.IndexOf(wassaduElectricAndRadio[i]) != -1)
                {
                    wassaduElectricAndRadioIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(wassaduElectricAndRadio[i]));
                }

            }

            for (int i = 0; i < wassaduHomeAndKitchen.Length; i++)
            {
                if (checkTxt.IndexOf(wassaduHomeAndKitchen[i]) != -1)
                {
                    wassaduHomeAndKitchenIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(wassaduHomeAndKitchen[i]));
                }

            }

            for (int i = 0; i < wassaduVehicle.Length; i++)
            {
                if (checkTxt.IndexOf(wassaduVehicle[i]) != -1)
                {
                    wassaduVehicleIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(wassaduVehicle[i]));
                }

            }



            for (int i = 0; i < wassaduFlame.Length; i++)
            {
                if (checkTxt.IndexOf(wassaduFlame[i]) != -1)
                {
                    wassaduFlameIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(wassaduFlame[i]));
                }

            }


            for (int i = 0; i < wassaduScienceAndMed.Length; i++)
            {
                if (checkTxt.IndexOf(wassaduScienceAndMed[i]) != -1)
                {
                    wassaduScienceAndMedIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(wassaduScienceAndMed[i]));
                }

            }

            for (int i = 0; i < wassaduAgricultural.Length; i++)
            {
                if (checkTxt.IndexOf(wassaduAgricultural[i]) != -1)
                {
                    wassaduAgriculturalIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(wassaduAgricultural[i]));
                }

            }
            for (int i = 0; i < wassaduAdvertisement.Length; i++)
            {
                if (checkTxt.IndexOf(wassaduAdvertisement[i]) != -1)
                {
                    wassaduAdvertisementIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(wassaduAdvertisement[i]));
                }

            }

            for (int i = 0; i < wassaduSport.Length; i++)
            {
                if (checkTxt.IndexOf(wassaduSport[i]) != -1)
                {
                    wassaduSportIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(wassaduSport[i]));
                }

            }

            for (int i = 0; i < wassaduComputer.Length; i++)
            {
                if (checkTxt.IndexOf(wassaduComputer[i]) != -1)
                {
                    wassaduComputerIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(wassaduComputer[i]));
                }

            }


            for (int i = 0; i < wassaduField.Length; i++)
            {
                if (checkTxt.IndexOf(wassaduField[i]) != -1)
                {
                    wassaduFieldIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(wassaduField[i]));
                }

            }

            for (int i = 0; i < wassaduEducation.Length; i++)
            {
                if (checkTxt.IndexOf(wassaduEducation[i]) != -1)
                {
                    wassaduEducationIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(wassaduEducation[i]));
                }

            }

            for (int i = 0; i < wassaduExplore.Length; i++)
            {
                if (checkTxt.IndexOf(wassaduExplore[i]) != -1)
                {
                    wassaduExploreIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(wassaduExplore[i]));
                }

            }

            for (int i = 0; i < wassaduMusic.Length; i++)
            {
                if (checkTxt.IndexOf(wassaduMusic[i]) != -1)
                {
                    wassaduMusicIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(wassaduMusic[i]));
                }

            }

            for (int i = 0; i < wassaduConstruct.Length; i++)
            {
                if (checkTxt.IndexOf(wassaduConstruct[i]) != -1)
                {
                    wassaduConstructIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(wassaduConstruct[i]));
                }

            }

            for (int i = 0; i < wassaduClothes.Length; i++)
            {
                if (checkTxt.IndexOf(wassaduClothes[i]) != -1)
                {
                    wassaduClothesIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(wassaduClothes[i]));
                }

            }

            if (min == 1000)
            {
                MessageBox.Show("ไม่พบรายการและรายละเอียดดังกล่าวในระบบ กรุณาเลือกภาระผูกพันด้วยตัวเอง");
            }


            //method if

            if (wassaduOfficeIndex > -1 && checkTxt.IndexOf(wassaduOffice[wassaduOfficeIndex]) == min)
            {
                order_boxProductType.Text = wassaduOffice[wassaduOfficeIndex];
                order_gl.Text = "ค่าวัสดุสำนักงาน";
                order_glPw.Text = gl["ค่าวัสดุสำนักงาน"];
            }
            if (wassaduElectricAndRadioIndex > -1 && checkTxt.IndexOf(wassaduElectricAndRadio[wassaduElectricAndRadioIndex]) == min)
            {
                order_boxProductType.Text = wassaduElectricAndRadio[wassaduElectricAndRadioIndex];
                order_gl.Text = "ค่าวัสดุไฟฟ้าและวิทยุ";
                order_glPw.Text = gl["ค่าวัสดุไฟฟ้าและวิทยุ"];
            }
            if (wassaduHomeAndKitchenIndex > -1 && checkTxt.IndexOf(wassaduHomeAndKitchen[wassaduHomeAndKitchenIndex]) == min)
            {
                order_boxProductType.Text = wassaduHomeAndKitchen[wassaduHomeAndKitchenIndex];
                order_gl.Text = "ค่าวัสดุงานบ้านงานครัว";
                order_glPw.Text = gl["ค่าวัสดุงานบ้านงานครัว"];
            }
            if (wassaduVehicleIndex > -1 && checkTxt.IndexOf(wassaduVehicle[wassaduVehicleIndex]) == min)
            {
                order_boxProductType.Text = wassaduVehicle[wassaduVehicleIndex];
                order_gl.Text = "ค่าวัสดุยานพาหนะและขนส่ง";
                order_glPw.Text = gl["ค่าวัสดุยานพาหนะและขนส่ง"];
            }
            if (wassaduFlameIndex > -1 && checkTxt.IndexOf(wassaduFlame[wassaduFlameIndex]) == min)
            {
                order_boxProductType.Text = wassaduFlame[wassaduFlameIndex];
                order_gl.Text = "ค่าวัสดุเชื้อเพลิงและหล่อลื่น";
                order_glPw.Text = gl["ค่าวัสดุเชื้อเพลิงและหล่อลื่น"];
            }
            if (wassaduScienceAndMedIndex > -1 && checkTxt.IndexOf(wassaduScienceAndMed[wassaduScienceAndMedIndex]) == min)
            {
                order_boxProductType.Text = wassaduScienceAndMed[wassaduScienceAndMedIndex];
                order_gl.Text = "ค่าวัสดุวิทยาศาสตร์หรือการแพทย์";
                order_glPw.Text = gl["ค่าวัสดุวิทยาศาสตร์หรือการแพทย์"];
            }
            if (wassaduAgriculturalIndex > -1 && checkTxt.IndexOf(wassaduAgricultural[wassaduAgriculturalIndex]) == min)
            {
                order_boxProductType.Text = wassaduAgricultural[wassaduAgriculturalIndex];
                order_gl.Text = "ค่าวัสดุการเกษตร";
                order_glPw.Text = gl["ค่าวัสดุการเกษตร"];
            }
            if (wassaduAdvertisementIndex > -1 && checkTxt.IndexOf(wassaduAdvertisement[wassaduAdvertisementIndex]) == min)
            {
                order_boxProductType.Text = wassaduAdvertisement[wassaduAdvertisementIndex];
                order_gl.Text = "ค่าวัสดุโฆษณาและเผยแพร่";
                order_glPw.Text = gl["ค่าวัสดุโฆษณาและเผยแพร่"];
            }
            if (wassaduSportIndex > -1 && checkTxt.IndexOf(wassaduSport[wassaduSportIndex]) == min)
            {
                order_boxProductType.Text = wassaduSport[wassaduSportIndex];
                order_gl.Text = "ค่าวัสดุกีฬา";
                order_glPw.Text = gl["ค่าวัสดุกีฬา"];
            }
            if (wassaduComputerIndex > -1 && checkTxt.IndexOf(wassaduComputer[wassaduComputerIndex]) == min)
            {
                order_boxProductType.Text = wassaduComputer[wassaduComputerIndex];
                order_gl.Text = "ค่าวัสดุคอมพิวเตอร์";
                order_glPw.Text = gl["ค่าวัสดุคอมพิวเตอร์"];
            }
            if (wassaduFieldIndex > -1 && checkTxt.IndexOf(wassaduField[wassaduFieldIndex]) == min)
            {
                order_boxProductType.Text = wassaduField[wassaduFieldIndex];
                order_gl.Text = "ค่าวัสดุสนาม";
                order_glPw.Text = gl["ค่าวัสดุสนาม"];
            }
            if (wassaduEducationIndex > -1 && checkTxt.IndexOf(wassaduEducation[wassaduEducationIndex]) == min)
            {
                order_boxProductType.Text = wassaduEducation[wassaduEducationIndex];
                order_gl.Text = "ค่าวัสดุการศึกษา";
                order_glPw.Text = gl["ค่าวัสดุการศึกษา"];
            }
            if (wassaduExploreIndex > -1 && checkTxt.IndexOf(wassaduExplore[wassaduExploreIndex]) == min)
            {
                order_boxProductType.Text = wassaduExplore[wassaduExploreIndex];
                order_gl.Text = "ค่าวัสดุสำรวจ";
                order_glPw.Text = gl["ค่าวัสดุสำรวจ"];
            }
            if (wassaduMusicIndex > -1 && checkTxt.IndexOf(wassaduMusic[wassaduMusicIndex]) == min)
            {
                order_boxProductType.Text = wassaduMusic[wassaduMusicIndex];
                order_gl.Text = "ค่าวัสดุดนตรี";
                order_glPw.Text = gl["ค่าวัสดุดนตรี"];
            }
            if (wassaduConstructIndex > -1 && checkTxt.IndexOf(wassaduConstruct[wassaduConstructIndex]) == min)
            {
                order_boxProductType.Text = wassaduConstruct[wassaduConstructIndex];
                order_gl.Text = "ค่าวัสดุก่อสร้าง";
                order_glPw.Text = gl["ค่าวัสดุก่อสร้าง"];
            }
            if (wassaduClothesIndex > -1 && checkTxt.IndexOf(wassaduClothes[wassaduClothesIndex]) == min)
            {
                order_boxProductType.Text = wassaduClothes[wassaduClothesIndex];
                order_gl.Text = "ค่าวัสดุเครื่องแต่งกาย";
                order_glPw.Text = gl["ค่าวัสดุเครื่องแต่งกาย"];
            }
            if (karupunOfficeIndex > -1 && checkTxt.IndexOf(karupunOffice[karupunOfficeIndex]) == min)
            {
                order_boxProductType.Text = karupunOffice[karupunOfficeIndex];
                // order_typeofunit.Text = unitKarupunOffice[karupunOfficeIndex];
                order_gl.Text = "ค่าครุภัณฑ์สำนักงาน";
                order_glPw.Text = gl["ค่าครุภัณฑ์สำนักงาน"];
                MessageBox.Show("กรุณากรอก \"ข้อกำหนด\" เนื่องจากเป็นพัสดุ ครุภัณฑ์ ครับ");
                if (box_prBuyer.Text == "ใบขอซื้อ" && order_productDetail.Text != "กรุณากรอกรายการและรายละเอียดสินค้า")
                {
                    createWord();
                }
                else
                {
                    MessageBox.Show("คุณยังทำรายการไม่ครบ" + Environment.NewLine + "กรุณาเลือก ประเภทเอกสาร เป็น \"ใบขอซื้อ\" " + Environment.NewLine + "และ กรุณากรอก \"รายการและรายละเอียด\" สินค้า ");
                }

                btn_korGumNod.Visible = true;
            }
            if (karupunVehicleIndex > -1 && checkTxt.IndexOf(karupunVehicle[karupunVehicleIndex]) == min)
            {
                order_boxProductType.Text = karupunVehicle[karupunVehicleIndex];
                // order_typeofunit.Text = unitKarupunVehicle[karupunVehicleIndex];
                order_gl.Text = "ค่าครุภัณฑ์ยานพาหนะและขนส่ง";
                order_glPw.Text = gl["ค่าครุภัณฑ์ยานพาหนะและขนส่ง"];
                MessageBox.Show("กรุณากรอก \"ข้อกำหนด\" เนื่องจากเป็นพัสดุ ครุภัณฑ์ ครับ");
                if (box_prBuyer.Text == "ใบขอซื้อ" && order_productDetail.Text != "กรุณากรอกรายการและรายละเอียดสินค้า")
                {
                    createWord();
                }
                else
                {
                    MessageBox.Show("คุณยังทำรายการไม่ครบ" + Environment.NewLine + "กรุณาเลือก ประเภทเอกสาร เป็น \"ใบขอซื้อ\" " + Environment.NewLine + "และ กรุณากรอก \"รายการและรายละเอียด\" สินค้า ");
                }

                btn_korGumNod.Visible = true;
            }
            if (karupunAgricultureIndex > -1 && checkTxt.IndexOf(karupunAgriculture[karupunAgricultureIndex]) == min)
            {
                order_boxProductType.Text = karupunAgriculture[karupunAgricultureIndex];
                //order_typeofunit.Text = unitKarupunAgriculture[karupunAgricultureIndex];
                order_gl.Text = "ค่าครุภัณฑ์การเกษตร";
                order_glPw.Text = gl["ค่าครุภัณฑ์การเกษตร"];
                MessageBox.Show("กรุณากรอก \"ข้อกำหนด\" เนื่องจากเป็นพัสดุ ครุภัณฑ์ ครับ");
                if (box_prBuyer.Text == "ใบขอซื้อ" && order_productDetail.Text != "กรุณากรอกรายการและรายละเอียดสินค้า")
                {
                    createWord();
                }
                else
                {
                    MessageBox.Show("คุณยังทำรายการไม่ครบ" + Environment.NewLine + "กรุณาเลือก ประเภทเอกสาร เป็น \"ใบขอซื้อ\" " + Environment.NewLine + "และ กรุณากรอก \"รายการและรายละเอียด\" สินค้า ");
                }

                btn_korGumNod.Visible = true;

            }
            if (karupunElectricalAndRadioIndex > -1 && checkTxt.IndexOf(karupunElectricalAndRadio[karupunElectricalAndRadioIndex]) == min)
            {
                order_boxProductType.Text = karupunElectricalAndRadio[karupunElectricalAndRadioIndex];
                //order_typeofunit.Text = unitKarupunElectricalAndRadio[karupunElectricalAndRadioIndex];
                order_gl.Text = "ค่าครุภัณฑ์ไฟฟ้าและวิทยุ";
                order_glPw.Text = gl["ค่าครุภัณฑ์ไฟฟ้าและวิทยุ"];
                MessageBox.Show("กรุณากรอก \"ข้อกำหนด\" เนื่องจากเป็นพัสดุ ครุภัณฑ์ ครับ");
                if (box_prBuyer.Text == "ใบขอซื้อ" && order_productDetail.Text != "กรุณากรอกรายการและรายละเอียดสินค้า")
                {
                    createWord();
                }
                else
                {
                    MessageBox.Show("คุณยังทำรายการไม่ครบ" + Environment.NewLine + "กรุณาเลือก ประเภทเอกสาร เป็น \"ใบขอซื้อ\" " + Environment.NewLine + "และ กรุณากรอก \"รายการและรายละเอียด\" สินค้า ");
                }

                btn_korGumNod.Visible = true;
            }
            if (karupunAdvertiseIndex > -1 && checkTxt.IndexOf(karupunAdvertise[karupunAdvertiseIndex]) == min)
            {
                order_boxProductType.Text = karupunAdvertise[karupunAdvertiseIndex];
                //order_typeofunit.Text = unitKarupunAdvertise[karupunAdvertiseIndex];
                order_gl.Text = "ค่าครุภัณฑ์โฆษณาและเผยแพร่";
                order_glPw.Text = gl["ค่าครุภัณฑ์โฆษณาและเผยแพร่"];
                MessageBox.Show("กรุณากรอก \"ข้อกำหนด\" เนื่องจากเป็นพัสดุ ครุภัณฑ์ ครับ");
                if (box_prBuyer.Text == "ใบขอซื้อ" && order_productDetail.Text != "กรุณากรอกรายการและรายละเอียดสินค้า")
                {
                    createWord();
                }
                else
                {
                    MessageBox.Show("คุณยังทำรายการไม่ครบ" + Environment.NewLine + "กรุณาเลือก ประเภทเอกสาร เป็น \"ใบขอซื้อ\" " + Environment.NewLine + "และ กรุณากรอก \"รายการและรายละเอียด\" สินค้า ");
                }

                btn_korGumNod.Visible = true;
            }

            if (karupunMedicalIndex > -1 && checkTxt.IndexOf(karupunMedical[karupunMedicalIndex]) == min)
            {
                order_boxProductType.Text = karupunMedical[karupunMedicalIndex];
                //order_typeofunit.Text = unitKarupunMedical[karupunMedicalIndex];
                order_gl.Text = "ค่าครุภัณฑ์วิทยาศาสตร์การแพทย์";
                order_glPw.Text = gl["ค่าครุภัณฑ์วิทยาศาสตร์การแพทย์"];
                MessageBox.Show("กรุณากรอก \"ข้อกำหนด\" เนื่องจากเป็นพัสดุ ครุภัณฑ์ ครับ");
                if (box_prBuyer.Text == "ใบขอซื้อ" && order_productDetail.Text != "กรุณากรอกรายการและรายละเอียดสินค้า")
                {
                    createWord();
                }
                else
                {
                    MessageBox.Show("คุณยังทำรายการไม่ครบ" + Environment.NewLine + "กรุณาเลือก ประเภทเอกสาร เป็น \"ใบขอซื้อ\" " + Environment.NewLine + "และ กรุณากรอก \"รายการและรายละเอียด\" สินค้า ");
                }

                btn_korGumNod.Visible = true;
            }
            if (karupunHomeAndKitchenIndex > -1 && checkTxt.IndexOf(karupunHomeAndKitchen[karupunHomeAndKitchenIndex]) == min)
            {
                order_boxProductType.Text = karupunHomeAndKitchen[karupunHomeAndKitchenIndex];
                //order_typeofunit.Text = unitKarupunHomeAndKitchen[karupunHomeAndKitchenIndex];
                order_gl.Text = "ค่าครุภัณฑ์งานบ้านงานครัว";
                order_glPw.Text = gl["ค่าครุภัณฑ์งานบ้านงานครัว"];
                MessageBox.Show("กรุณากรอก \"ข้อกำหนด\" เนื่องจากเป็นพัสดุ ครุภัณฑ์ ครับ");
                if (box_prBuyer.Text == "ใบขอซื้อ" && order_productDetail.Text != "กรุณากรอกรายการและรายละเอียดสินค้า")
                {
                    createWord();
                }
                else
                {
                    MessageBox.Show("คุณยังทำรายการไม่ครบ" + Environment.NewLine + "กรุณาเลือก ประเภทเอกสาร เป็น \"ใบขอซื้อ\" " + Environment.NewLine + "และ กรุณากรอก \"รายการและรายละเอียด\" สินค้า ");
                }

                btn_korGumNod.Visible = true;
            }
            if (karupunIndustryIndex > -1 && checkTxt.IndexOf(karupunIndustry[karupunIndustryIndex]) == min)
            {
                order_boxProductType.Text = karupunIndustry[karupunIndustryIndex];
                //order_typeofunit.Text = unitKarupunIndustry[karupunIndustryIndex];
                order_gl.Text = "ค่าครุภัณฑ์โรงงาน";
                order_glPw.Text = gl["ค่าครุภัณฑ์โรงงาน"];
                MessageBox.Show("กรุณากรอก \"ข้อกำหนด\" เนื่องจากเป็นพัสดุ ครุภัณฑ์ ครับ");
                if (box_prBuyer.Text == "ใบขอซื้อ" && order_productDetail.Text != "กรุณากรอกรายการและรายละเอียดสินค้า")
                {
                    createWord();
                }
                else
                {
                    MessageBox.Show("คุณยังทำรายการไม่ครบ" + Environment.NewLine + "กรุณาเลือก ประเภทเอกสาร เป็น \"ใบขอซื้อ\" " + Environment.NewLine + "และ กรุณากรอก \"รายการและรายละเอียด\" สินค้า ");
                }

                btn_korGumNod.Visible = true;
            }
            if (karupunSportIndex > -1 && checkTxt.IndexOf(karupunSport[karupunSportIndex]) == min)
            {
                order_boxProductType.Text = karupunSport[karupunSportIndex];
                //order_typeofunit.Text = unitKarupunSport[karupunSportIndex];
                order_gl.Text = "ค่าครุภัณฑ์กีฬา";
                order_glPw.Text = gl["ค่าครุภัณฑ์กีฬา"];
                MessageBox.Show("กรุณากรอก \"ข้อกำหนด\" เนื่องจากเป็นพัสดุ ครุภัณฑ์ ครับ");
                if (box_prBuyer.Text == "ใบขอซื้อ" && order_productDetail.Text != "กรุณากรอกรายการและรายละเอียดสินค้า")
                {
                    createWord();
                }
                else
                {
                    MessageBox.Show("คุณยังทำรายการไม่ครบ" + Environment.NewLine + "กรุณาเลือก ประเภทเอกสาร เป็น \"ใบขอซื้อ\" " + Environment.NewLine + "และ กรุณากรอก \"รายการและรายละเอียด\" สินค้า ");
                }

                btn_korGumNod.Visible = true;
            }
            if (karupunExploreIndex > -1 && checkTxt.IndexOf(karupunExplore[karupunExploreIndex]) == min)
            {
                order_boxProductType.Text = karupunExplore[karupunExploreIndex];
                //order_typeofunit.Text = unitKarupunExplore[karupunExploreIndex];
                order_gl.Text = "ค่าครุภัณฑ์สำรวจ";
                order_glPw.Text = gl["ค่าครุภัณฑ์สำรวจ"];
                MessageBox.Show("กรุณากรอก \"ข้อกำหนด\" เนื่องจากเป็นพัสดุ ครุภัณฑ์ ครับ");
                if (box_prBuyer.Text == "ใบขอซื้อ" && order_productDetail.Text != "กรุณากรอกรายการและรายละเอียดสินค้า")
                {
                    createWord();
                }
                else
                {
                    MessageBox.Show("คุณยังทำรายการไม่ครบ" + Environment.NewLine + "กรุณาเลือก ประเภทเอกสาร เป็น \"ใบขอซื้อ\" " + Environment.NewLine + "และ กรุณากรอก \"รายการและรายละเอียด\" สินค้า ");
                }

                btn_korGumNod.Visible = true;
            }

            if (karupunWeaponIndex > -1 && checkTxt.IndexOf(karupunWeapon[karupunWeaponIndex]) == min)
            {
                order_boxProductType.Text = karupunWeapon[karupunWeaponIndex];
                //order_typeofunit.Text = unitKarupunWeapon[karupunWeaponIndex];
                order_gl.Text = "ค่าครุภัณฑ์อาวุธ";
                order_glPw.Text = gl["ค่าครุภัณฑ์อาวุธ"];
                MessageBox.Show("กรุณากรอก \"ข้อกำหนด\" เนื่องจากเป็นพัสดุ ครุภัณฑ์ ครับ");
                if (box_prBuyer.Text == "ใบขอซื้อ" && order_productDetail.Text != "กรุณากรอกรายการและรายละเอียดสินค้า")
                {
                    createWord();
                }
                else
                {
                    MessageBox.Show("คุณยังทำรายการไม่ครบ" + Environment.NewLine + "กรุณาเลือก ประเภทเอกสาร เป็น \"ใบขอซื้อ\" " + Environment.NewLine + "และ กรุณากรอก \"รายการและรายละเอียด\" สินค้า ");
                }

                btn_korGumNod.Visible = true;
            }
            if (karupunMusicIndex > -1 && checkTxt.IndexOf(karupunMusic[karupunMusicIndex]) == min)
            {
                order_boxProductType.Text = karupunMusic[karupunMusicIndex];
                //order_typeofunit.Text = unitKarupunMusic[karupunMusicIndex];
                order_gl.Text = "ค่าครุภัณฑ์ดนตรีและนาฏศิลป์";
                order_glPw.Text = gl["ค่าครุภัณฑ์ดนตรีและนาฏศิลป์"];
                MessageBox.Show("กรุณากรอก \"ข้อกำหนด\" เนื่องจากเป็นพัสดุ ครุภัณฑ์ ครับ");
                if (box_prBuyer.Text == "ใบขอซื้อ" && order_productDetail.Text != "กรุณากรอกรายการและรายละเอียดสินค้า")
                {
                    createWord();
                }
                else
                {
                    MessageBox.Show("คุณยังทำรายการไม่ครบ" + Environment.NewLine + "กรุณาเลือก ประเภทเอกสาร เป็น \"ใบขอซื้อ\" " + Environment.NewLine + "และ กรุณากรอก \"รายการและรายละเอียด\" สินค้า ");
                }

                btn_korGumNod.Visible = true;
            }
            if (karupunComputerIndex > -1 && checkTxt.IndexOf(karupunComputer[karupunComputerIndex]) == min)
            {
                order_boxProductType.Text = karupunComputer[karupunComputerIndex];
                //order_typeofunit.Text = unitKarupunComputer[karupunComputerIndex];
                order_gl.Text = "ค่าครุภัณฑ์คอมพิวเตอร์";
                order_glPw.Text = gl["ค่าครุภัณฑ์คอมพิวเตอร์"];
                MessageBox.Show("กรุณากรอก \"ข้อกำหนด\" เนื่องจากเป็นพัสดุ ครุภัณฑ์ ครับ");
                if (box_prBuyer.Text == "ใบขอซื้อ" && order_productDetail.Text != "กรุณากรอกรายการและรายละเอียดสินค้า")
                {
                    createWord();
                }
                else
                {
                    MessageBox.Show("คุณยังทำรายการไม่ครบ" + Environment.NewLine + "กรุณาเลือก ประเภทเอกสาร เป็น \"ใบขอซื้อ\" " + Environment.NewLine + "และ กรุณากรอก \"รายการและรายละเอียด\" สินค้า ");
                }

                btn_korGumNod.Visible = true;
            }






        }

        private void order_boxProductType_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void order_typeofunit_TextChanged(object sender, EventArgs e)
        {

        }

        private void createWord()
        {
            object oMissing = System.Reflection.Missing.Value;
            object oEndOfDoc = "\\endofdoc"; /* \endofdoc is a predefined bookmark */

            //Start Word and create a new document.
            Word._Application oWord;
            Word._Document oDoc;
            oWord = new Word.Application();

            oWord.Visible = true;
            oDoc = oWord.Documents.Add(ref oMissing);

            //Insert a paragraph at the beginning of the document.
            Word.Paragraph oPara1;
            oPara1 = oDoc.Content.Paragraphs.Add(ref oMissing);
            if (box_prBuyer.Text == "ใบขอซื้อ" && order_productDetail.Text != "กรุณากรอกรายการและรายละเอียดสินค้า")
            {
                oPara1.Range.Text = "ข้อกำหนดคุณสมบัติการซื้อ";
            }
            else if (box_prBuyer.Text == "ใบขอจ้าง")
            {
                oPara1.Range.Text = "ข้อกำหนดคุณสมบัติการจ้าง";
            }
            oPara1.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
            oPara1.Range.Font.Bold = 1;
            oPara1.Format.SpaceAfter = 0;
            oPara1.Range.InsertParagraphAfter();

            //Insert a paragraph at the end of the document.
            Word.Paragraph oPara2;
            object oRng = oDoc.Bookmarks.get_Item(ref oEndOfDoc).Range;
            oPara2 = oDoc.Content.Paragraphs.Add(ref oRng);
            oPara2.Range.Text = order_productDetail.Text;
        }
        private void button1_Click_2(object sender, EventArgs e)
        {
            if (box_prBuyer.Text == "ใบขอซื้อ" && order_productDetail.Text != "กรุณากรอกรายการและรายละเอียดสินค้า")
            {
                createWord();
            }
            else
            {
                MessageBox.Show("คุณยังทำรายการไม่ครบ" + Environment.NewLine + "กรุณาเลือก ประเภทเอกสาร เป็น \"ใบขอซื้อ\" " + Environment.NewLine + "และ กรุณากรอก \"รายการและรายละเอียด\" สินค้า ");
            }
        }

        private void txt_name_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void order_productDetail_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_name_Click(object sender, EventArgs e)
        {
            if (txt_name.Text == "กรุณาเลือกชื่อรองอธิการบดี") { txt_name.Text = null; }

        }

        private void box_institute_SelectedIndexChanged(object sender, EventArgs e)
        {
            lbl_leaderBuyer.Text = "ผู้อำนวยการ" + box_institute.Text;
            txt_leaderBuyer.Text = "กรุณากรอกชื่อผู้อำนวยการ" + box_institute.Text;
        }

        private void box_method_Click(object sender, EventArgs e)
        {
            if (box_method.Text == "กรุณาเลือกวิธี") { box_method.Text = null; }
        }

        private void txt_product_Click(object sender, EventArgs e)
        {
            if (txt_product.Text == "กรุณาระบุสิ่งที่ต้องการจัดซื้อหรือจัดจ้าง") { txt_product.Text = null; }

        }

        private void txt_reason_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_reason_Click(object sender, EventArgs e)
        {
            if (txt_reason.Text == "กรุณาระบุจุดประสงค์") txt_reason.Text = null;
            toolTip_txt_reason.SetToolTip(txt_reason, "จุดประสงค์ต้องสอดคล้องกับสิ่งที่ต้องการจัดซื้อหรือจัดจ้าง");

        }

        private void txt_reason_MouseLeave(object sender, EventArgs e)
        {

        }

        private void txt_reason_MouseHover(object sender, EventArgs e)
        {
            toolTip_txt_reason.SetToolTip(txt_reason, "จุดประสงค์ต้องสอดคล้องกับสิ่งที่ต้องการจัดซื้อหรือจัดจ้าง");
        }

        private void order_productDetail_Click(object sender, EventArgs e)
        {
            if (order_productDetail.Text == "กรุณากรอกรายการและรายละเอียดสินค้า") order_productDetail.Text = null;
        }

        private void order_boxProductType_Click(object sender, EventArgs e)
        {
            if (order_boxProductType.Text == "ประเภทสินค้า") order_boxProductType.Text = null;
        }

        private void btn_suggest_Click(object sender, EventArgs e)
        {
            string checkTxt = order_productDetail.Text;

            //Index
            int karupunOfficeIndex = -2;
            int karupunVehicleIndex = -2;
            int karupunAgricultureIndex = -2;
            int karupunElectricalAndRadioIndex = -2;
            int karupunAdvertiseIndex = -2;
            int karupunMedicalIndex = -2;
            int karupunHomeAndKitchenIndex = -2;
            int karupunIndustryIndex = -2;
            int karupunSportIndex = -2;
            int karupunExploreIndex = -2;
            int karupunWeaponIndex = -2;
            int karupunMusicIndex = -2;
            int karupunComputerIndex = -2;
            /////
            int wassaduOfficeIndex = -2;
            int wassaduElectricAndRadioIndex = -2;
            int wassaduHomeAndKitchenIndex = -2;
            int wassaduVehicleIndex = -2;
            int wassaduFlameIndex = -2;
            int wassaduScienceAndMedIndex = -2;
            int wassaduAgriculturalIndex = -2;
            int wassaduAdvertisementIndex = -2;
            int wassaduSportIndex = -2;
            int wassaduComputerIndex = -2;
            int wassaduFieldIndex = -2;
            int wassaduEducationIndex = -2;
            int wassaduExploreIndex = -2;
            int wassaduMusicIndex = -2;
            int wassaduConstructIndex = -2;
            int wassaduClothesIndex = -2;

            //string of prd
            string[] karupunOffice = prd.karupunOffice();
            string[] karupunVehicle = prd.karupunVehicle();
            string[] karupunAgriculture = prd.karupunAgriculture();
            string[] karupunElectricalAndRadio = prd.karupunElectricalAndRadio();
            string[] karupunAdvertise = prd.karupunAdvertise();
            string[] karupunMedical = prd.karupunMedical();
            string[] karupunHomeAndKitchen = prd.karupunHomeAndKitchen();
            string[] karupunIndustry = prd.karupunIndustry();
            string[] karupunSport = prd.karupunSport();
            string[] karupunExplore = prd.karupunExplore();
            string[] karupunWeapon = prd.karupunWeapon();
            string[] karupunMusic = prd.karupunMusic();
            string[] karupunComputer = prd.karupunComputer();
            /////
            string[] wassaduOffice = prd.wassaduOffice();
            string[] wassaduElectricAndRadio = prd.wassaduElectricAndRadio();
            string[] wassaduHomeAndKitchen = prd.wassaduHomeAndKitchen();
            string[] wassaduVehicle = prd.wassaduVehicle();
            string[] wassaduFlame = prd.wassaduFlame();
            string[] wassaduScienceAndMed = prd.wassaduScienceAndMed();
            string[] wassaduAgricultural = prd.wassaduAgricultural();
            string[] wassaduAdvertisement = prd.wassaduAdvertisement();
            string[] wassaduSport = prd.wassaduSport();
            string[] wassaduComputer = prd.wassaduComputer();
            string[] wassaduField = prd.wassaduField();
            string[] wassaduEducation = prd.wassaduEducation();
            string[] wassaduExplore = prd.wassaduExplore();
            string[] wassaduMusic = prd.wassaduMusic();
            string[] wassaduConstruct = prd.wassaduConstruct();
            string[] wassaduClothes = prd.wassaduClothes();




            //string[] of prd

            string[] unitKarupunOffice = prd.unitKarupunOffice();
            string[] unitKarupunVehicle = prd.unitKarupunVehicle();
            string[] unitKarupunAgriculture = prd.unitKarupunAgriculture();
            string[] unitKarupunElectricalAndRadio = prd.unitKarupunElectricalAndRadio();
            string[] unitKarupunAdvertise = prd.unitKarupunAdvertise();
            string[] unitKarupunMedical = prd.unitKarupunMedical();
            string[] unitKarupunHomeAndKitchen = prd.unitKarupunHomeAndKitchen();
            string[] unitKarupunIndustry = prd.unitKarupunIndustry();
            string[] unitKarupunSport = prd.unitKarupunSport();
            string[] unitKarupunExplore = prd.unitKarupunExplore();
            string[] unitKarupunWeapon = prd.unitKarupunWeapon();
            string[] unitKarupunComputer = prd.unitKarupunComputer();
            ////

            //minimize
            int min = 1000;

            //method for
            for (int i = 0; i < karupunOffice.Length; i++)
            {
                if (checkTxt.IndexOf(karupunOffice[i]) != -1)
                {
                    karupunOfficeIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(karupunOffice[i]));
                }

            }
            for (int i = 0; i < karupunVehicle.Length; i++)
            {
                if (checkTxt.IndexOf(karupunVehicle[i]) != -1)
                {
                    karupunVehicleIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(karupunVehicle[i]));
                }

            }
            for (int i = 0; i < karupunAgriculture.Length; i++)
            {
                if (checkTxt.IndexOf(karupunAgriculture[i]) != -1)
                {
                    karupunAgricultureIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(karupunAgriculture[i]));
                }

            }
            for (int i = 0; i < karupunElectricalAndRadio.Length; i++)
            {
                if (checkTxt.IndexOf(karupunElectricalAndRadio[i]) != -1)
                {
                    karupunElectricalAndRadioIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(karupunElectricalAndRadio[i]));
                }

            }
            for (int i = 0; i < karupunAdvertise.Length; i++)
            {
                if (checkTxt.IndexOf(karupunAdvertise[i]) != -1)
                {
                    karupunAdvertiseIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(karupunAdvertise[i]));
                }

            }
            for (int i = 0; i < karupunMedical.Length; i++)
            {
                if (checkTxt.IndexOf(karupunMedical[i]) != -1)
                {
                    karupunMedicalIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(karupunMedical[i]));
                }

            }
            for (int i = 0; i < karupunHomeAndKitchen.Length; i++)
            {
                if (checkTxt.IndexOf(karupunHomeAndKitchen[i]) != -1)
                {
                    karupunHomeAndKitchenIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(karupunHomeAndKitchen[i]));
                }

            }
            for (int i = 0; i < karupunIndustry.Length; i++)
            {
                if (checkTxt.IndexOf(karupunIndustry[i]) != -1)
                {
                    karupunIndustryIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(karupunIndustry[i]));
                }

            }
            for (int i = 0; i < karupunSport.Length; i++)
            {
                if (checkTxt.IndexOf(karupunSport[i]) != -1)
                {
                    karupunSportIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(karupunSport[i]));
                }

            }
            for (int i = 0; i < karupunExplore.Length; i++)
            {
                if (checkTxt.IndexOf(karupunExplore[i]) != -1)
                {
                    karupunExploreIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(karupunExplore[i]));
                }

            }
            for (int i = 0; i < karupunWeapon.Length; i++)
            {
                if (checkTxt.IndexOf(karupunWeapon[i]) != -1)
                {
                    karupunWeaponIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(karupunWeapon[i]));
                }

            }
            for (int i = 0; i < karupunMusic.Length; i++)
            {
                if (checkTxt.IndexOf(karupunMusic[i]) != -1)
                {
                    karupunMusicIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(karupunMusic[i]));
                }

            }
            for (int i = 0; i < karupunComputer.Length; i++)
            {
                if (checkTxt.IndexOf(karupunComputer[i]) != -1)
                {
                    karupunComputerIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(karupunComputer[i]));
                }

            }
            ////

            for (int i = 0; i < wassaduOffice.Length; i++)
            {
                if (checkTxt.IndexOf(wassaduOffice[i]) != -1)
                {
                    wassaduOfficeIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(wassaduOffice[i]));
                }

            }

            for (int i = 0; i < wassaduElectricAndRadio.Length; i++)
            {
                if (checkTxt.IndexOf(wassaduElectricAndRadio[i]) != -1)
                {
                    wassaduElectricAndRadioIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(wassaduElectricAndRadio[i]));
                }

            }

            for (int i = 0; i < wassaduHomeAndKitchen.Length; i++)
            {
                if (checkTxt.IndexOf(wassaduHomeAndKitchen[i]) != -1)
                {
                    wassaduHomeAndKitchenIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(wassaduHomeAndKitchen[i]));
                }

            }

            for (int i = 0; i < wassaduVehicle.Length; i++)
            {
                if (checkTxt.IndexOf(wassaduVehicle[i]) != -1)
                {
                    wassaduVehicleIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(wassaduVehicle[i]));
                }

            }



            for (int i = 0; i < wassaduFlame.Length; i++)
            {
                if (checkTxt.IndexOf(wassaduFlame[i]) != -1)
                {
                    wassaduFlameIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(wassaduFlame[i]));
                }

            }


            for (int i = 0; i < wassaduScienceAndMed.Length; i++)
            {
                if (checkTxt.IndexOf(wassaduScienceAndMed[i]) != -1)
                {
                    wassaduScienceAndMedIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(wassaduScienceAndMed[i]));
                }

            }

            for (int i = 0; i < wassaduAgricultural.Length; i++)
            {
                if (checkTxt.IndexOf(wassaduAgricultural[i]) != -1)
                {
                    wassaduAgriculturalIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(wassaduAgricultural[i]));
                }

            }
            for (int i = 0; i < wassaduAdvertisement.Length; i++)
            {
                if (checkTxt.IndexOf(wassaduAdvertisement[i]) != -1)
                {
                    wassaduAdvertisementIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(wassaduAdvertisement[i]));
                }

            }

            for (int i = 0; i < wassaduSport.Length; i++)
            {
                if (checkTxt.IndexOf(wassaduSport[i]) != -1)
                {
                    wassaduSportIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(wassaduSport[i]));
                }

            }

            for (int i = 0; i < wassaduComputer.Length; i++)
            {
                if (checkTxt.IndexOf(wassaduComputer[i]) != -1)
                {
                    wassaduComputerIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(wassaduComputer[i]));
                }

            }


            for (int i = 0; i < wassaduField.Length; i++)
            {
                if (checkTxt.IndexOf(wassaduField[i]) != -1)
                {
                    wassaduFieldIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(wassaduField[i]));
                }

            }

            for (int i = 0; i < wassaduEducation.Length; i++)
            {
                if (checkTxt.IndexOf(wassaduEducation[i]) != -1)
                {
                    wassaduEducationIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(wassaduEducation[i]));
                }

            }

            for (int i = 0; i < wassaduExplore.Length; i++)
            {
                if (checkTxt.IndexOf(wassaduExplore[i]) != -1)
                {
                    wassaduExploreIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(wassaduExplore[i]));
                }

            }

            for (int i = 0; i < wassaduMusic.Length; i++)
            {
                if (checkTxt.IndexOf(wassaduMusic[i]) != -1)
                {
                    wassaduMusicIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(wassaduMusic[i]));
                }

            }

            for (int i = 0; i < wassaduConstruct.Length; i++)
            {
                if (checkTxt.IndexOf(wassaduConstruct[i]) != -1)
                {
                    wassaduConstructIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(wassaduConstruct[i]));
                }

            }

            for (int i = 0; i < wassaduClothes.Length; i++)
            {
                if (checkTxt.IndexOf(wassaduClothes[i]) != -1)
                {
                    wassaduClothesIndex = i;
                    min = Math.Min(min, checkTxt.IndexOf(wassaduClothes[i]));
                }

            }

            if (min == 1000) {
                MessageBox.Show("ไม่พบรายการและรายละเอียดดังกล่าวในระบบ กรุณาเลือกภาระผูกพันด้วยตัวเอง");
                order_boxProductType.Text = "ประเภทสินค้า";
            }


            //method if

            if (wassaduOfficeIndex > -1 && checkTxt.IndexOf(wassaduOffice[wassaduOfficeIndex]) == min)
            {
                order_boxProductType.Text = wassaduOffice[wassaduOfficeIndex];
                order_gl.Text = "ค่าวัสดุสำนักงาน";
                order_glPw.Text = gl["ค่าวัสดุสำนักงาน"];
            }
            if (wassaduElectricAndRadioIndex > -1 && checkTxt.IndexOf(wassaduElectricAndRadio[wassaduElectricAndRadioIndex]) == min)
            {
                order_boxProductType.Text = wassaduElectricAndRadio[wassaduElectricAndRadioIndex];
                order_gl.Text = "ค่าวัสดุไฟฟ้าและวิทยุ";
                order_glPw.Text = gl["ค่าวัสดุไฟฟ้าและวิทยุ"];
            }
            if (wassaduHomeAndKitchenIndex > -1 && checkTxt.IndexOf(wassaduHomeAndKitchen[wassaduHomeAndKitchenIndex]) == min)
            {
                order_boxProductType.Text = wassaduHomeAndKitchen[wassaduHomeAndKitchenIndex];
                order_gl.Text = "ค่าวัสดุงานบ้านงานครัว";
                order_glPw.Text = gl["ค่าวัสดุงานบ้านงานครัว"];
            }
            if (wassaduVehicleIndex > -1 && checkTxt.IndexOf(wassaduVehicle[wassaduVehicleIndex]) == min)
            {
                order_boxProductType.Text = wassaduVehicle[wassaduVehicleIndex];
                order_gl.Text = "ค่าวัสดุยานพาหนะและขนส่ง";
                order_glPw.Text = gl["ค่าวัสดุยานพาหนะและขนส่ง"];
            }
            if (wassaduFlameIndex > -1 && checkTxt.IndexOf(wassaduFlame[wassaduFlameIndex]) == min)
            {
                order_boxProductType.Text = wassaduFlame[wassaduFlameIndex];
                order_gl.Text = "ค่าวัสดุเชื้อเพลิงและหล่อลื่น";
                order_glPw.Text = gl["ค่าวัสดุเชื้อเพลิงและหล่อลื่น"];
            }
            if (wassaduScienceAndMedIndex > -1 && checkTxt.IndexOf(wassaduScienceAndMed[wassaduScienceAndMedIndex]) == min)
            {
                order_boxProductType.Text = wassaduScienceAndMed[wassaduScienceAndMedIndex];
                order_gl.Text = "ค่าวัสดุวิทยาศาสตร์หรือการแพทย์";
                order_glPw.Text = gl["ค่าวัสดุวิทยาศาสตร์หรือการแพทย์"];
            }
            if (wassaduAgriculturalIndex > -1 && checkTxt.IndexOf(wassaduAgricultural[wassaduAgriculturalIndex]) == min)
            {
                order_boxProductType.Text = wassaduAgricultural[wassaduAgriculturalIndex];
                order_gl.Text = "ค่าวัสดุการเกษตร";
                order_glPw.Text = gl["ค่าวัสดุการเกษตร"];
            }
            if (wassaduAdvertisementIndex > -1 && checkTxt.IndexOf(wassaduAdvertisement[wassaduAdvertisementIndex]) == min)
            {
                order_boxProductType.Text = wassaduAdvertisement[wassaduAdvertisementIndex];
                order_gl.Text = "ค่าวัสดุโฆษณาและเผยแพร่";
                order_glPw.Text = gl["ค่าวัสดุโฆษณาและเผยแพร่"];
            }
            if (wassaduSportIndex > -1 && checkTxt.IndexOf(wassaduSport[wassaduSportIndex]) == min)
            {
                order_boxProductType.Text = wassaduSport[wassaduSportIndex];
                order_gl.Text = "ค่าวัสดุกีฬา";
                order_glPw.Text = gl["ค่าวัสดุกีฬา"];
            }
            if (wassaduComputerIndex > -1 && checkTxt.IndexOf(wassaduComputer[wassaduComputerIndex]) == min)
            {
                order_boxProductType.Text = wassaduComputer[wassaduComputerIndex];
                order_gl.Text = "ค่าวัสดุคอมพิวเตอร์";
                order_glPw.Text = gl["ค่าวัสดุคอมพิวเตอร์"];
            }
            if (wassaduFieldIndex > -1 && checkTxt.IndexOf(wassaduField[wassaduFieldIndex]) == min)
            {
                order_boxProductType.Text = wassaduField[wassaduFieldIndex];
                order_gl.Text = "ค่าวัสดุสนาม";
                order_glPw.Text = gl["ค่าวัสดุสนาม"];
            }
            if (wassaduEducationIndex > -1 && checkTxt.IndexOf(wassaduEducation[wassaduEducationIndex]) == min)
            {
                order_boxProductType.Text = wassaduEducation[wassaduEducationIndex];
                order_gl.Text = "ค่าวัสดุการศึกษา";
                order_glPw.Text = gl["ค่าวัสดุการศึกษา"];
            }
            if (wassaduExploreIndex > -1 && checkTxt.IndexOf(wassaduExplore[wassaduExploreIndex]) == min)
            {
                order_boxProductType.Text = wassaduExplore[wassaduExploreIndex];
                order_gl.Text = "ค่าวัสดุสำรวจ";
                order_glPw.Text = gl["ค่าวัสดุสำรวจ"];
            }
            if (wassaduMusicIndex > -1 && checkTxt.IndexOf(wassaduMusic[wassaduMusicIndex]) == min)
            {
                order_boxProductType.Text = wassaduMusic[wassaduMusicIndex];
                order_gl.Text = "ค่าวัสดุดนตรี";
                order_glPw.Text = gl["ค่าวัสดุดนตรี"];
            }
            if (wassaduConstructIndex > -1 && checkTxt.IndexOf(wassaduConstruct[wassaduConstructIndex]) == min)
            {
                order_boxProductType.Text = wassaduConstruct[wassaduConstructIndex];
                order_gl.Text = "ค่าวัสดุก่อสร้าง";
                order_glPw.Text = gl["ค่าวัสดุก่อสร้าง"];
            }
            if (wassaduClothesIndex > -1 && checkTxt.IndexOf(wassaduClothes[wassaduClothesIndex]) == min)
            {
                order_boxProductType.Text = wassaduClothes[wassaduClothesIndex];
                order_gl.Text = "ค่าวัสดุเครื่องแต่งกาย";
                order_glPw.Text = gl["ค่าวัสดุเครื่องแต่งกาย"];
            }
            if (karupunOfficeIndex > -1 && checkTxt.IndexOf(karupunOffice[karupunOfficeIndex]) == min)
            {
                order_boxProductType.Text = karupunOffice[karupunOfficeIndex];
                // order_typeofunit.Text = unitKarupunOffice[karupunOfficeIndex];
                order_gl.Text = "ค่าครุภัณฑ์สำนักงาน";
                order_glPw.Text = gl["ค่าครุภัณฑ์สำนักงาน"];
                MessageBox.Show("กรุณากรอก \"ข้อกำหนด\" เนื่องจากเป็นพัสดุ ครุภัณฑ์ ครับ");
                if (box_prBuyer.Text == "ใบขอซื้อ" && order_productDetail.Text != "กรุณากรอกรายการและรายละเอียดสินค้า")
                {
                    createWord();
                }
                else
                {
                    MessageBox.Show("คุณยังทำรายการไม่ครบ" + Environment.NewLine + "กรุณาเลือก ประเภทเอกสาร เป็น \"ใบขอซื้อ\" " + Environment.NewLine + "และ กรุณากรอก \"รายการและรายละเอียด\" สินค้า ");
                }
                btn_korGumNod.Visible = true;
            }
            if (karupunVehicleIndex > -1 && checkTxt.IndexOf(karupunVehicle[karupunVehicleIndex]) == min)
            {
                order_boxProductType.Text = karupunVehicle[karupunVehicleIndex];
                // order_typeofunit.Text = unitKarupunVehicle[karupunVehicleIndex];
                order_gl.Text = "ค่าครุภัณฑ์ยานพาหนะและขนส่ง";
                order_glPw.Text = gl["ค่าครุภัณฑ์ยานพาหนะและขนส่ง"];
                MessageBox.Show("กรุณากรอก \"ข้อกำหนด\" เนื่องจากเป็นพัสดุ ครุภัณฑ์ ครับ");
                if (box_prBuyer.Text == "ใบขอซื้อ" && order_productDetail.Text != "กรุณากรอกรายการและรายละเอียดสินค้า")
                {
                    createWord();
                }
                else
                {
                    MessageBox.Show("คุณยังทำรายการไม่ครบ" + Environment.NewLine + "กรุณาเลือก ประเภทเอกสาร เป็น \"ใบขอซื้อ\" " + Environment.NewLine + "และ กรุณากรอก \"รายการและรายละเอียด\" สินค้า ");
                }
                btn_korGumNod.Visible = true;
            }
            if (karupunAgricultureIndex > -1 && checkTxt.IndexOf(karupunAgriculture[karupunAgricultureIndex]) == min)
            {
                order_boxProductType.Text = karupunAgriculture[karupunAgricultureIndex];
                //order_typeofunit.Text = unitKarupunAgriculture[karupunAgricultureIndex];
                order_gl.Text = "ค่าครุภัณฑ์การเกษตร";
                order_glPw.Text = gl["ค่าครุภัณฑ์การเกษตร"];
                MessageBox.Show("กรุณากรอก \"ข้อกำหนด\" เนื่องจากเป็นพัสดุ ครุภัณฑ์ ครับ");
                if (box_prBuyer.Text == "ใบขอซื้อ" && order_productDetail.Text != "กรุณากรอกรายการและรายละเอียดสินค้า")
                {
                    createWord();
                }
                else
                {
                    MessageBox.Show("คุณยังทำรายการไม่ครบ" + Environment.NewLine + "กรุณาเลือก ประเภทเอกสาร เป็น \"ใบขอซื้อ\" " + Environment.NewLine + "และ กรุณากรอก \"รายการและรายละเอียด\" สินค้า ");
                }
                createWord();
                btn_korGumNod.Visible = true;
            }
            if (karupunElectricalAndRadioIndex > -1 && checkTxt.IndexOf(karupunElectricalAndRadio[karupunElectricalAndRadioIndex]) == min)
            {
                order_boxProductType.Text = karupunElectricalAndRadio[karupunElectricalAndRadioIndex];
                //order_typeofunit.Text = unitKarupunElectricalAndRadio[karupunElectricalAndRadioIndex];
                order_gl.Text = "ค่าครุภัณฑ์ไฟฟ้าและวิทยุ";
                order_glPw.Text = gl["ค่าครุภัณฑ์ไฟฟ้าและวิทยุ"];
                MessageBox.Show("กรุณากรอก \"ข้อกำหนด\" เนื่องจากเป็นพัสดุ ครุภัณฑ์ ครับ");
                if (box_prBuyer.Text == "ใบขอซื้อ" && order_productDetail.Text != "กรุณากรอกรายการและรายละเอียดสินค้า")
                {
                    createWord();
                }
                else
                {
                    MessageBox.Show("คุณยังทำรายการไม่ครบ" + Environment.NewLine + "กรุณาเลือก ประเภทเอกสาร เป็น \"ใบขอซื้อ\" " + Environment.NewLine + "และ กรุณากรอก \"รายการและรายละเอียด\" สินค้า ");
                }
                createWord();
                btn_korGumNod.Visible = true;
            }
            if (karupunAdvertiseIndex > -1 && checkTxt.IndexOf(karupunAdvertise[karupunAdvertiseIndex]) == min)
            {
                order_boxProductType.Text = karupunAdvertise[karupunAdvertiseIndex];
                //order_typeofunit.Text = unitKarupunAdvertise[karupunAdvertiseIndex];
                order_gl.Text = "ค่าครุภัณฑ์โฆษณาและเผยแพร่";
                order_glPw.Text = gl["ค่าครุภัณฑ์โฆษณาและเผยแพร่"];
                MessageBox.Show("กรุณากรอก \"ข้อกำหนด\" เนื่องจากเป็นพัสดุ ครุภัณฑ์ ครับ");
                if (box_prBuyer.Text == "ใบขอซื้อ" && order_productDetail.Text != "กรุณากรอกรายการและรายละเอียดสินค้า")
                {
                    createWord();
                }
                else
                {
                    MessageBox.Show("คุณยังทำรายการไม่ครบ" + Environment.NewLine + "กรุณาเลือก ประเภทเอกสาร เป็น \"ใบขอซื้อ\" " + Environment.NewLine + "และ กรุณากรอก \"รายการและรายละเอียด\" สินค้า " + Environment.NewLine + "และ กรุณากรอก \"รายการและรายละเอียด\" สินค้า " + Environment.NewLine + "และ กรุณากรอก \"รายการและรายละเอียด\" สินค้า ");
                }

                btn_korGumNod.Visible = true;
            }

            if (karupunMedicalIndex > -1 && checkTxt.IndexOf(karupunMedical[karupunMedicalIndex]) == min)
            {
                order_boxProductType.Text = karupunMedical[karupunMedicalIndex];
                //order_typeofunit.Text = unitKarupunMedical[karupunMedicalIndex];
                order_gl.Text = "ค่าครุภัณฑ์วิทยาศาสตร์การแพทย์";
                order_glPw.Text = gl["ค่าครุภัณฑ์วิทยาศาสตร์การแพทย์"];
                MessageBox.Show("กรุณากรอก \"ข้อกำหนด\" เนื่องจากเป็นพัสดุ ครุภัณฑ์ ครับ");
                if (box_prBuyer.Text == "ใบขอซื้อ" && order_productDetail.Text != "กรุณากรอกรายการและรายละเอียดสินค้า")
                {
                    createWord();
                }
                else
                {
                    MessageBox.Show("คุณยังทำรายการไม่ครบ" + Environment.NewLine + "กรุณาเลือก ประเภทเอกสาร เป็น \"ใบขอซื้อ\" " + Environment.NewLine + "และ กรุณากรอก \"รายการและรายละเอียด\" สินค้า ");
                }

                btn_korGumNod.Visible = true;
            }
            if (karupunHomeAndKitchenIndex > -1 && checkTxt.IndexOf(karupunHomeAndKitchen[karupunHomeAndKitchenIndex]) == min)
            {
                order_boxProductType.Text = karupunHomeAndKitchen[karupunHomeAndKitchenIndex];
                //order_typeofunit.Text = unitKarupunHomeAndKitchen[karupunHomeAndKitchenIndex];
                order_gl.Text = "ค่าครุภัณฑ์งานบ้านงานครัว";
                order_glPw.Text = gl["ค่าครุภัณฑ์งานบ้านงานครัว"];
                MessageBox.Show("กรุณากรอก \"ข้อกำหนด\" เนื่องจากเป็นพัสดุ ครุภัณฑ์ ครับ");
                if (box_prBuyer.Text == "ใบขอซื้อ" && order_productDetail.Text != "กรุณากรอกรายการและรายละเอียดสินค้า")
                {
                    createWord();
                }
                else
                {
                    MessageBox.Show("คุณยังทำรายการไม่ครบ" + Environment.NewLine + "กรุณาเลือก ประเภทเอกสาร เป็น \"ใบขอซื้อ\" " + Environment.NewLine + "และ กรุณากรอก \"รายการและรายละเอียด\" สินค้า " + Environment.NewLine + "และ กรุณากรอก \"รายการและรายละเอียด\" สินค้า ");
                }

                btn_korGumNod.Visible = true;
            }
            if (karupunIndustryIndex > -1 && checkTxt.IndexOf(karupunIndustry[karupunIndustryIndex]) == min)
            {
                order_boxProductType.Text = karupunIndustry[karupunIndustryIndex];
                //order_typeofunit.Text = unitKarupunIndustry[karupunIndustryIndex];
                order_gl.Text = "ค่าครุภัณฑ์โรงงาน";
                order_glPw.Text = gl["ค่าครุภัณฑ์โรงงาน"];
                MessageBox.Show("กรุณากรอก \"ข้อกำหนด\" เนื่องจากเป็นพัสดุ ครุภัณฑ์ ครับ");
                if (box_prBuyer.Text == "ใบขอซื้อ" && order_productDetail.Text != "กรุณากรอกรายการและรายละเอียดสินค้า")
                {
                    createWord();
                }
                else
                {
                    MessageBox.Show("คุณยังทำรายการไม่ครบ" + Environment.NewLine + "กรุณาเลือก ประเภทเอกสาร เป็น \"ใบขอซื้อ\" " + Environment.NewLine + "และ กรุณากรอก \"รายการและรายละเอียด\" สินค้า " + Environment.NewLine + "และ กรุณากรอก \"รายการและรายละเอียด\" สินค้า ");
                }

                btn_korGumNod.Visible = true;
            }
            if (karupunSportIndex > -1 && checkTxt.IndexOf(karupunSport[karupunSportIndex]) == min)
            {
                order_boxProductType.Text = karupunSport[karupunSportIndex];
                //order_typeofunit.Text = unitKarupunSport[karupunSportIndex];
                order_gl.Text = "ค่าครุภัณฑ์กีฬา";
                order_glPw.Text = gl["ค่าครุภัณฑ์กีฬา"];
                MessageBox.Show("กรุณากรอก \"ข้อกำหนด\" เนื่องจากเป็นพัสดุ ครุภัณฑ์ ครับ");
                if (box_prBuyer.Text == "ใบขอซื้อ" && order_productDetail.Text != "กรุณากรอกรายการและรายละเอียดสินค้า")
                {
                    createWord();
                }
                else
                {
                    MessageBox.Show("คุณยังทำรายการไม่ครบ" + Environment.NewLine + "กรุณาเลือก ประเภทเอกสาร เป็น \"ใบขอซื้อ\" " + Environment.NewLine + "และ กรุณากรอก \"รายการและรายละเอียด\" สินค้า ");
                }

                btn_korGumNod.Visible = true;
            }
            if (karupunExploreIndex > -1 && checkTxt.IndexOf(karupunExplore[karupunExploreIndex]) == min)
            {
                order_boxProductType.Text = karupunExplore[karupunExploreIndex];
                //order_typeofunit.Text = unitKarupunExplore[karupunExploreIndex];
                order_gl.Text = "ค่าครุภัณฑ์สำรวจ";
                order_glPw.Text = gl["ค่าครุภัณฑ์สำรวจ"];
                MessageBox.Show("กรุณากรอก \"ข้อกำหนด\" เนื่องจากเป็นพัสดุ ครุภัณฑ์ ครับ");
                if (box_prBuyer.Text == "ใบขอซื้อ" && order_productDetail.Text != "กรุณากรอกรายการและรายละเอียดสินค้า")
                {
                    createWord();
                }
                else
                {
                    MessageBox.Show("คุณยังทำรายการไม่ครบ" + Environment.NewLine + "กรุณาเลือก ประเภทเอกสาร เป็น \"ใบขอซื้อ\" " + Environment.NewLine + "และ กรุณากรอก \"รายการและรายละเอียด\" สินค้า ");
                }

                btn_korGumNod.Visible = true;
            }

            if (karupunWeaponIndex > -1 && checkTxt.IndexOf(karupunWeapon[karupunWeaponIndex]) == min)
            {
                order_boxProductType.Text = karupunWeapon[karupunWeaponIndex];
                //order_typeofunit.Text = unitKarupunWeapon[karupunWeaponIndex];
                order_gl.Text = "ค่าครุภัณฑ์อาวุธ";
                order_glPw.Text = gl["ค่าครุภัณฑ์อาวุธ"];
                MessageBox.Show("กรุณากรอก \"ข้อกำหนด\" เนื่องจากเป็นพัสดุ ครุภัณฑ์ ครับ");
                if (box_prBuyer.Text == "ใบขอซื้อ" && order_productDetail.Text != "กรุณากรอกรายการและรายละเอียดสินค้า")
                {
                    createWord();
                }
                else
                {
                    MessageBox.Show("คุณยังทำรายการไม่ครบ" + Environment.NewLine + "กรุณาเลือก ประเภทเอกสาร เป็น \"ใบขอซื้อ\" " + Environment.NewLine + "และ กรุณากรอก \"รายการและรายละเอียด\" สินค้า ");
                }

                btn_korGumNod.Visible = true;
            }
            if (karupunMusicIndex > -1 && checkTxt.IndexOf(karupunMusic[karupunMusicIndex]) == min)
            {
                order_boxProductType.Text = karupunMusic[karupunMusicIndex];
                //order_typeofunit.Text = unitKarupunMusic[karupunMusicIndex];
                order_gl.Text = "ค่าครุภัณฑ์ดนตรีและนาฏศิลป์";
                order_glPw.Text = gl["ค่าครุภัณฑ์ดนตรีและนาฏศิลป์"];
                MessageBox.Show("กรุณากรอก \"ข้อกำหนด\" เนื่องจากเป็นพัสดุ ครุภัณฑ์ ครับ");
                if (box_prBuyer.Text == "ใบขอซื้อ" && order_productDetail.Text != "กรุณากรอกรายการและรายละเอียดสินค้า")
                {
                    createWord();
                }
                else
                {
                    MessageBox.Show("คุณยังทำรายการไม่ครบ" + Environment.NewLine + "กรุณาเลือก ประเภทเอกสาร เป็น \"ใบขอซื้อ\" " + Environment.NewLine + "และ กรุณากรอก \"รายการและรายละเอียด\" สินค้า ");
                }

                btn_korGumNod.Visible = true;
            }
            if (karupunComputerIndex > -1 && checkTxt.IndexOf(karupunComputer[karupunComputerIndex]) == min)
            {
                order_boxProductType.Text = karupunComputer[karupunComputerIndex];
                //order_typeofunit.Text = unitKarupunComputer[karupunComputerIndex];
                order_gl.Text = "ค่าครุภัณฑ์คอมพิวเตอร์";
                order_glPw.Text = gl["ค่าครุภัณฑ์คอมพิวเตอร์"];
                MessageBox.Show("กรุณากรอก \"ข้อกำหนด\" เนื่องจากเป็นพัสดุ ครุภัณฑ์ ครับ");
                if (box_prBuyer.Text == "ใบขอซื้อ" && order_productDetail.Text != "กรุณากรอกรายการและรายละเอียดสินค้า")
                {
                    createWord();
                }
                else
                {
                    MessageBox.Show("คุณยังทำรายการไม่ครบ" + Environment.NewLine + "กรุณาเลือก ประเภทเอกสาร เป็น \"ใบขอซื้อ\" " + Environment.NewLine + "และ กรุณากรอก \"รายการและรายละเอียด\" สินค้า ");
                }

                btn_korGumNod.Visible = true;
            }
        }

        private void order_boxProductType_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_lastPrice_TextChanged(object sender, EventArgs e)
        {
            try {
                int a = Convert.ToInt32(order_lastPrice.Text);
            }
            catch {
                order_lastPrice.Text = null;
            }
        }

        private void box_day_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void box_method_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txt_president_Click(object sender, EventArgs e)
        {
            if (txt_president1.Text == "กรุณากรอกชื่อประธานกรรมการ") txt_president1.Text = null;
        }

        private void txt_president_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_committee_Click(object sender, EventArgs e)
        {
            if (txt_committee1.Text == "กรุณากรอกชื่อกรรมการ") txt_committee1.Text = null;
        }

        private void txt_secretary_Click(object sender, EventArgs e)
        {
            if (txt_secretary1.Text == "กรุณากรอกชื่อกรรมการและเลขานุการ") txt_secretary1.Text = null;
        }

        private void txt_buyer_Click(object sender, EventArgs e)
        {
            if (txt_buyer.Text == "กรุณากรอกชื่อผู้ขอซื้อหรือขอจ้าง") txt_buyer.Text = null;
        }

        private void txt_leaderBuyer_Click(object sender, EventArgs e)
        {
            if (txt_leaderBuyer.Text == "กรุณากรอกชื่อผู้อำนวยการของหน่วยงาน" || txt_leaderBuyer.Text == "กรุณากรอกชื่อผู้อำนวยการ" + box_institute.Text) txt_leaderBuyer.Text = null;
        }

        private void box_day_TextChanged(object sender, EventArgs e)
        {
            try
            {
                int a = Convert.ToInt32(box_day.Text);
            }
            catch
            {
                if (Convert.ToInt32(box_day.Text) < 0)
                {
                    box_day.Text = "0";
                }
            }
        }

        private void box_day_Click(object sender, EventArgs e)
        {

        }
        private void box_institute_KeyPress(object sender, KeyPressEventArgs e)
        {
            //  e.KeyChar = (char)Keys.None;
        }

        private void box_biz_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void box_biz_KeyPress(object sender, KeyPressEventArgs e)
        {
            //  e.KeyChar = (char)Keys.None;
        }

        private void box_center_KeyPress(object sender, KeyPressEventArgs e)
        {
            // e.KeyChar = (char)Keys.None;
        }

        private void box_fund_KeyPress(object sender, KeyPressEventArgs e)
        {
            //  e.KeyChar = (char)Keys.None;
        }

        private void box_district_KeyPress(object sender, KeyPressEventArgs e)
        {
            // e.KeyChar = (char)Keys.None;
        }

        private void box_prBuyer_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = (char)Keys.None;
        }

        private void order_typeofunit_Click(object sender, EventArgs e)
        {
            if (order_typeofunit.Text == "กรุณากรอกหน่วยนับ") order_typeofunit.Text = null;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {


        }

        private void button1_Click_3(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void box_institutePw_TextChanged(object sender, EventArgs e)
        {

        }

        private void box_institutePw_Click(object sender, EventArgs e)
        {
            if (box_institutePw.Text == "กรุณากรอกรหัส") box_institutePw.Text = "";
        }

        private void box_institute_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_day_CheckedChanged(object sender, EventArgs e)
        {
            if (btn_day.Checked == true)
            {
                btn_date.Checked = false;
                txt_day.Enabled = false;
                box_day.Enabled = true;
            }
        }

        private void txt_vendor_Click(object sender, EventArgs e)
        {
            if (txt_vendor.Text == "กรุณากรอกชื่อผู้ประกอบการ") txt_vendor.Text = "";

        }

        private void txt_phoneNo_Click(object sender, EventArgs e)
        {
            if (txt_phoneNo.Text == "กรุณากรอกเบอร์โทรศัพท์") txt_phoneNo.Text = "";
        }

        private void btn_korGumNodPrBuyer_Click(object sender, EventArgs e)
        {
            object oMissing = System.Reflection.Missing.Value;
            object oEndOfDoc = "\\endofdoc"; /* \endofdoc is a predefined bookmark */

            //Start Word and create a new document.
            Word._Application oWord;
            Word._Document oDoc;
            oWord = new Word.Application();

            oWord.Visible = true;
            oDoc = oWord.Documents.Add(ref oMissing);

            //Insert a paragraph at the beginning of the document.
            Word.Paragraph oPara1;
            oPara1 = oDoc.Content.Paragraphs.Add(ref oMissing);
            if (box_prBuyer.Text == "ใบขอเช่า")
            {
                oPara1.Range.Text = "ข้อกำหนดคุณสมบัติการเช่า";
            }
            else if (box_prBuyer.Text == "ใบขอจ้าง")
            {
                oPara1.Range.Text = "ข้อกำหนดคุณสมบัติการจ้าง";
            }
            oPara1.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btn_personCheck_CheckedChanged(object sender, EventArgs e)
        {
            if (btn_personCheck.Checked == true)
            {
                btn_committeeCheck.Checked = false;
                txt_president1.ReadOnly = true;
                txt_president1.Enabled = false;
                txt_committee1.ReadOnly = true;
                txt_committee1.Enabled = false;
                txt_secretary1.ReadOnly = true;
                txt_secretary1.Enabled = false;
                txt_staff1.ReadOnly = false;
                txt_staff1.Enabled = true;
            }

        }

        private void btn_committeeCheck_CheckedChanged(object sender, EventArgs e)
        {
            if (btn_committeeCheck.Checked == true)
            {
                btn_personCheck.Checked = false;
                txt_president1.ReadOnly = false;
                txt_president1.Enabled = true;
                txt_committee1.ReadOnly = false;
                txt_committee1.Enabled = true;
                txt_secretary1.ReadOnly = false;
                txt_secretary1.Enabled = true;
                txt_staff1.ReadOnly = true;
                txt_staff1.Enabled = false;
            }
        }

        private void btn_date_CheckedChanged(object sender, EventArgs e)
        {
            if (btn_date.Checked == true)
            {
                btn_day.Checked = false;
                box_day.Enabled = false;
                txt_day.Enabled = true;
            }
        }

        private void txt_day_ValueChanged(object sender, EventArgs e)
        {
        }

        private void txt_prDate_ValueChanged(object sender, EventArgs e)
        {

        }

        private void box_institute_Click(object sender, EventArgs e)
        {
            if (box_institute.Text == "ประเภทหน่วยงาน")
            {
                box_institute.Text = "";
            }
        }

        private void box_biz_Click(object sender, EventArgs e)
        {
            if (box_biz.Text == "ประเภทธุรกิจ")
            {
                box_biz.Text = "";
            }

        }

        private void box_center_Click(object sender, EventArgs e)
        {
            if (box_center.Text == "ประเภทศูนย์ต้นทุน")
            {
                box_center.Text = "";
            }
        }

        private void box_fund_Click(object sender, EventArgs e)
        {
            if (box_fund.Text == "ประเภทกองทุน / เงินทุน")
            {
                box_fund.Text = "";
            }
        }

        private void box_center_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void box_district_Click(object sender, EventArgs e)
        {
            if (box_district.Text == "ประเภทเขตตามหน้าที่")
            {
                box_district.Text = "";
            }
        }

        private void txt_name_Click_1(object sender, EventArgs e)
        {
            if (txt_name.Text == "กรุณาเลือกชื่อรองอธิการบดี")
            {
                txt_name.Text = "";
            }
        }

        private void order_gl_Click(object sender, EventArgs e)
        {
            if (order_gl.Text == "ประเภทภาระผูกพัน / หมวดทรัพย์สิน")
            {
                order_gl.Text = "";
            }
        }

        private void order_gl_SelectedIndexChanged(object sender, EventArgs e)
        {
            string[] a = null;
            a = order_gl.Text.Split(new[] { "  /  " }, StringSplitOptions.None);
            order_glPw.Text = a[1];
            if (order_gl.Text == "ค่าครุภัณฑ์สำนักงาน  /  " || order_gl.Text == "ค่าครุภัณฑ์ยานพาหนะและขนส่ง  /  " || order_gl.Text == "ค่าครุภัณฑ์การเกษตร  /  " || order_gl.Text == "ค่าครุภัณฑ์ไฟฟ้าและวิทยุ  /  " || order_gl.Text == "ค่าครุภัณฑ์โฆษณาและเผยแพร่  /  " || order_gl.Text == "ค่าครุภัณฑ์วิทยาศาสตร์การแพทย์  /  " || order_gl.Text == "ค่าครุภัณฑ์งานบ้านงานครัว  /  " || order_gl.Text == "ค่าครุภัณฑ์โรงงาน  /  " || order_gl.Text == "ค่าครุภัณฑ์กีฬา  /  " || order_gl.Text == "ค่าครุภัณฑ์สำรวจ  /  " || order_gl.Text == "ค่าครุภัณฑ์อาวุธ  /  " || order_gl.Text == "ค่าครุภัณฑ์ดนตรีและนาฏศิลป์  /  " || order_gl.Text == "ค่าครุภัณฑ์คอมพิวเตอร์  /  ")
            {

                MessageBox.Show("กรุณากรอก \"ข้อกำหนด\" เนื่องจากเป็นพัสดุ ครุภัณฑ์ ครับ");
                if (box_prBuyer.Text == "ใบขอซื้อ" && order_productDetail.Text != "กรุณากรอกรายการและรายละเอียดสินค้า")
                {
                    createWord();
                }
                else
                {
                    MessageBox.Show("คุณยังทำรายการไม่ครบ" + Environment.NewLine + "กรุณาเลือก ประเภทเอกสาร เป็น \"ใบขอซื้อ\" " + Environment.NewLine + "และ กรุณากรอก \"รายการและรายละเอียด\" สินค้า ");
                }

                btn_korGumNod.Visible = true;
            }
            else
            {
                btn_korGumNod.Visible = false;
            }

        }

        private void order_typeofunit_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private int total(DataTable dt)
        {
            int total = 0;
            for (int i = 0; i <= dt.Rows.Count - 1; i++)
            {
                {
                    total = total + Convert.ToInt32(dt.Rows[i][8]);

                }
            }
            return total;
        }

        private void txt_total_TextChanged(object sender, EventArgs e)
        {
            if (Convert.ToInt32(txt_total.Text) < 100000)
            {
                txt_president2.ReadOnly = true;
                txt_committee2.ReadOnly = true;
                txt_secretary2.ReadOnly = true;
                btn_personCheck.Enabled = true;
                btn_committeeCheck.Enabled = true;
                txt_president1.ReadOnly = false;
                txt_president1.Enabled = true;
                txt_committee1.ReadOnly = false;
                txt_committee1.Enabled = true;
                txt_secretary1.ReadOnly = false;
                txt_secretary1.Enabled = true;
                txt_staff1.ReadOnly = false;
                txt_staff1.Enabled = true;
            }
            else
            {
                btn_personCheck.Checked = false;
                btn_committeeCheck.Checked = false;
                btn_committeeCheck.Enabled = false;
                btn_personCheck.Enabled = false;
                txt_president1.ReadOnly = true;
                txt_president1.Enabled = false;
                txt_committee1.ReadOnly = true;
                txt_committee1.Enabled = false;
                txt_secretary1.ReadOnly = true;
                txt_secretary1.Enabled = false;
                txt_staff1.ReadOnly = true;
                txt_staff1.Enabled = false;
                txt_president2.ReadOnly = false;
                txt_committee2.ReadOnly = false;
                txt_secretary2.ReadOnly = false;
            }
        }

        private void txt_count_TextChanged(object sender, EventArgs e)
        {

        }

        private void box_day_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void txt_staff1_Click(object sender, EventArgs e)
        {
            if (txt_staff1.Text == "กรุณากรอกชื่อผู้ตรวจรับพัสดุ")
            {
                txt_staff1.Text = "";
            }

        }

        private void txt_president2_Click(object sender, EventArgs e)
        {
            if (txt_president2.Text == "กรุณากรอกชื่อประธานกรรมการ")
            {
                txt_president2.Text = "";
            }
        }

        private void txt_committee2_Click(object sender, EventArgs e)
        {
            if (txt_committee2.Text == "กรุณากรอกชื่อกรรมการ")
            {
                txt_committee2.Text = "";
            }
        }

        private void txt_secretary2_Click(object sender, EventArgs e)
        {
            if (txt_secretary2.Text == "กรุณากรอกชื่อกรรมการและเลขานุการ")

                txt_secretary2.Text = "";
        }

        private void box_biz_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }
    }
}

    





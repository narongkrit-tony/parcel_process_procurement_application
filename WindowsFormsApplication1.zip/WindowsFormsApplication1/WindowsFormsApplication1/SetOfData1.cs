﻿namespace WindowsFormsApplication1
{
}

namespace WindowsFormsApplication1
{


    public partial class SetOfData1
    {
    }
}
namespace WindowsFormsApplication1 {
    
    
    public partial class SetOfData1 {
    }
}

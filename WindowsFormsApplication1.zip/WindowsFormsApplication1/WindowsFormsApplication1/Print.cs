﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Print : Form
    {
        public Print()
        {
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("th-TH");
            System.Threading.Thread.CurrentThread.CurrentCulture.DateTimeFormat.Calendar = new System.Globalization.ThaiBuddhistCalendar();
            System.Threading.Thread.CurrentThread.CurrentCulture.DateTimeFormat.ShortDatePattern = "dd/MM/yyyy";

            InitializeComponent();
        }
        public Order orderPr = new Order();
        public Data Oong = new Data();

        private void crystalReportViewer1_Load(object sender, EventArgs e)
        {
            Token rpt = new Token();
            rpt.SetDataSource(Oong.dtable);
            rpt.SetParameterValue("txt_no", orderPr.txt_no);
            rpt.SetParameterValue("txt_prDate", orderPr.txt_prDate);
            rpt.SetParameterValue("txt_phoneNo", orderPr.txt_phoneNo);
            rpt.SetParameterValue("pTotal", orderPr.txt_total);
            rpt.SetParameterValue("pTotalWord", ThaiBaht(orderPr.txt_total));
            rpt.SetParameterValue("countRow", orderPr.txt_count);
            string[] biz = null;
            biz = orderPr.pr_biz.Split(new[] { "  /  " }, StringSplitOptions.None);
            rpt.SetParameterValue("box_biz", biz[0]);
            rpt.SetParameterValue("box_bizPw", biz[1]);
            string[] center = null;
            center = orderPr.pr_center.Split(new[] { "  /  " }, StringSplitOptions.None);
            rpt.SetParameterValue("box_center", center[0]);
            rpt.SetParameterValue("box_centerPw", center[1]);
            string[] fund = null;
            fund = orderPr.pr_fund.Split(new[] { "  /  " }, StringSplitOptions.None);
            rpt.SetParameterValue("box_fund", fund[0]);
            rpt.SetParameterValue("box_fundPw", fund[1]);
            string[] district = null;
            district = orderPr.pr_district.Split(new[] { "  /  " }, StringSplitOptions.None);
            rpt.SetParameterValue("box_district", district[0]);
            rpt.SetParameterValue("box_districtPw", district[1]);
            rpt.SetParameterValue("box_institute", orderPr.pr_institute);
            rpt.SetParameterValue("box_institutePw", orderPr.pr_institutePw);
            rpt.SetParameterValue("pName", orderPr.pr_buyer);
            rpt.SetParameterValue("txt_reason", orderPr.txt_reason);
            rpt.SetParameterValue("txt_product", orderPr.txt_product);
            rpt.SetParameterValue("txt_name", orderPr.txt_name);
            rpt.SetParameterValue("box_method", orderPr.box_method);
            if(orderPr.pr_buyer == "ใบขอซื้อ")
            {
                rpt.SetParameterValue("BuyOrSell", "จัดซื้อ");
            }
            else if(orderPr.pr_buyer == "ใบขอจ้าง")
            {
                rpt.SetParameterValue("BuyOrSell", "จัดจ้าง");
            }else if(orderPr.pr_buyer == "ใบขอเช่า")
            {
                rpt.SetParameterValue("BuyOrSell", "ขอเช่า");
            }
            rpt.SetParameterValue("box_day",orderPr.box_day);
            rpt.SetParameterValue("txt_vendor",orderPr.txt_vendor);
            rpt.SetParameterValue("txt_1", orderPr.txt_1);
            rpt.SetParameterValue("txt_2", orderPr.txt_2);
            rpt.SetParameterValue("txt_3", orderPr.txt_3);
            rpt.SetParameterValue("txt_label1", orderPr.txt_label1);
            rpt.SetParameterValue("txt_label2", orderPr.txt_label2);
            rpt.SetParameterValue("txt_label3", orderPr.txt_label3);
            rpt.SetParameterValue("txt_buyer", orderPr.txt_buyer);
            rpt.SetParameterValue("txt_leaderBuyer", orderPr.txt_leaderBuyer);
            crystalReportViewer1.ReportSource = rpt;
            crystalReportViewer1.Refresh();

        }

        public static string ThaiBaht(string txt)
        {
            string bahtTxt, n, bahtTH = "";
            double amount;
            try { amount = Convert.ToDouble(txt); }
            catch { amount = 0; }
            bahtTxt = amount.ToString("####.00");
            string[] num = { "ศูนย์", "หนึ่ง", "สอง", "สาม", "สี่", "ห้า", "หก", "เจ็ด", "แปด", "เก้า", "สิบ" };
            string[] rank = { "", "สิบ", "ร้อย", "พัน", "หมื่น", "แสน", "ล้าน" };
            string[] temp = bahtTxt.Split('.');
            string intVal = temp[0];
            string decVal = temp[1];
            if (Convert.ToDouble(bahtTxt) == 0)
                bahtTH = "ศูนย์บาทถ้วน";
            else
            {
                for (int i = 0; i < intVal.Length; i++)
                {
                    n = intVal.Substring(i, 1);
                    if (n != "0")
                    {
                        if ((i == (intVal.Length - 1)) && (n == "1"))
                            bahtTH += "เอ็ด";
                        else if ((i == (intVal.Length - 2)) && (n == "2"))
                            bahtTH += "ยี่";
                        else if ((i == (intVal.Length - 2)) && (n == "1"))
                            bahtTH += "";
                        else
                            bahtTH += num[Convert.ToInt32(n)];
                        bahtTH += rank[(intVal.Length - i) - 1];
                    }
                }
                bahtTH += "บาท";
                if (decVal == "00")
                    bahtTH += "ถ้วน";
                else
                {
                    for (int i = 0; i < decVal.Length; i++)
                    {
                        n = decVal.Substring(i, 1);
                        if (n != "0")
                        {
                            if ((i == decVal.Length - 1) && (n == "1"))
                                bahtTH += "เอ็ด";
                            else if ((i == (decVal.Length - 2)) && (n == "2"))
                                bahtTH += "ยี่";
                            else if ((i == (decVal.Length - 2)) && (n == "1"))
                                bahtTH += "";
                            else
                                bahtTH += num[Convert.ToInt32(n)];
                            bahtTH += rank[(decVal.Length - i) - 1];
                        }
                    }
                    bahtTH += "สตางค์";
                }
            }
            return bahtTH;
        }
    }
}

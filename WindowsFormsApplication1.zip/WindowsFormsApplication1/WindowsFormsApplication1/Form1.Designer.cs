﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.box_prBuyer = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_product = new System.Windows.Forms.TextBox();
            this.txt_reason = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.box_method = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.box_day = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.txt_president1 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.txt_committee1 = new System.Windows.Forms.TextBox();
            this.txt_secretary1 = new System.Windows.Forms.TextBox();
            this.txt_leaderBuyer = new System.Windows.Forms.TextBox();
            this.lbl_leaderBuyer = new System.Windows.Forms.Label();
            this.txt_buyer = new System.Windows.Forms.TextBox();
            this.lbl_buyer = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.order_no = new System.Windows.Forms.NumericUpDown();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.order_productDetail = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.order_unitPrice = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.order_noUnit = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.order_total = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.btn_addOrder = new System.Windows.Forms.Button();
            this.btn_removeOrder = new System.Windows.Forms.Button();
            this.btn_clearOrder = new System.Windows.Forms.Button();
            this.btn_print = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.label25 = new System.Windows.Forms.Label();
            this.order_glPw = new System.Windows.Forms.TextBox();
            this.btn_check = new System.Windows.Forms.Button();
            this.btn_korGumNod = new System.Windows.Forms.Button();
            this.toolTip_txt_reason = new System.Windows.Forms.ToolTip(this.components);
            this.button2 = new System.Windows.Forms.Button();
            this.order_boxProductType = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.order_lastPrice = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.box_institutePw = new System.Windows.Forms.TextBox();
            this.txt_day = new System.Windows.Forms.DateTimePicker();
            this.label24 = new System.Windows.Forms.Label();
            this.txt_vendor = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.txt_no = new System.Windows.Forms.NumericUpDown();
            this.label37 = new System.Windows.Forms.Label();
            this.txt_prDate = new System.Windows.Forms.DateTimePicker();
            this.label38 = new System.Windows.Forms.Label();
            this.txt_phoneNo = new System.Windows.Forms.TextBox();
            this.txt_staff1 = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.btn_day = new System.Windows.Forms.RadioButton();
            this.btn_date = new System.Windows.Forms.RadioButton();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.txt_secretary2 = new System.Windows.Forms.TextBox();
            this.txt_committee2 = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.txt_president2 = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.btn_korGumNodPrBuyer = new System.Windows.Forms.Button();
            this.btn_personCheck = new System.Windows.Forms.CheckBox();
            this.btn_committeeCheck = new System.Windows.Forms.CheckBox();
            this.box_institute = new SergeUtils.EasyCompletionComboBox();
            this.box_biz = new SergeUtils.EasyCompletionComboBox();
            this.box_center = new SergeUtils.EasyCompletionComboBox();
            this.box_fund = new SergeUtils.EasyCompletionComboBox();
            this.box_district = new SergeUtils.EasyCompletionComboBox();
            this.txt_name = new SergeUtils.EasyCompletionComboBox();
            this.order_gl = new SergeUtils.EasyCompletionComboBox();
            this.order_typeofunit = new SergeUtils.EasyCompletionComboBox();
            this.label46 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.txt_count = new System.Windows.Forms.TextBox();
            this.txt_total = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.order_no)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_no)).BeginInit();
            this.SuspendLayout();
            // 
            // box_prBuyer
            // 
            this.box_prBuyer.AutoCompleteCustomSource.AddRange(new string[] {
            "ใบขอซื้อ",
            "ใบขอจ้าง"});
            this.box_prBuyer.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.box_prBuyer.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.box_prBuyer.ForeColor = System.Drawing.SystemColors.WindowText;
            this.box_prBuyer.FormattingEnabled = true;
            this.box_prBuyer.Items.AddRange(new object[] {
            "ใบขอซื้อ",
            "ใบขอจ้าง",
            "ใบขอเช่า"});
            this.box_prBuyer.Location = new System.Drawing.Point(1025, 175);
            this.box_prBuyer.Name = "box_prBuyer";
            this.box_prBuyer.Size = new System.Drawing.Size(556, 33);
            this.box_prBuyer.TabIndex = 0;
            this.box_prBuyer.Text = "ขอซื้อ/จ้าง";
            this.box_prBuyer.SelectedIndexChanged += new System.EventHandler(this.box_prBuyer_SelectedIndexChanged);
            this.box_prBuyer.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.box_prBuyer_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(818, 178);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(152, 26);
            this.label1.TabIndex = 1;
            this.label1.Text = "ประเภทเอกสาร :";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(967, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(135, 26);
            this.label2.TabIndex = 3;
            this.label2.Text = "ประเภทธุรกิจ :";
            this.label2.Click += new System.EventHandler(this.label2_Click_1);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 135);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(114, 26);
            this.label3.TabIndex = 5;
            this.label3.Text = "ศูนย์ต้นทุน :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(818, 138);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(158, 26);
            this.label4.TabIndex = 7;
            this.label4.Text = "กองทุน / เงินทุน :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 175);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(137, 26);
            this.label5.TabIndex = 9;
            this.label5.Text = "เขตตามหน้าที่ :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(7, 98);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(105, 26);
            this.label6.TabIndex = 11;
            this.label6.Text = "หน่วยงาน :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(188, 428);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(343, 26);
            this.label7.TabIndex = 13;
            this.label7.Text = "ภาระผูกพัน (ผังบัญชี) / หมวดสินทรัพย์ :";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.916231F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label8.Location = new System.Drawing.Point(15, 220);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(87, 26);
            this.label8.TabIndex = 17;
            this.label8.Text = "จดหมาย";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(15, 256);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(184, 26);
            this.label9.TabIndex = 18;
            this.label9.Text = "เรียน รองอธิการบดี :";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(11, 301);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(259, 26);
            this.label10.TabIndex = 23;
            this.label10.Text = "สิ่งที่ต้องการจัดซื้อหรือจัดจ้าง :";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // txt_product
            // 
            this.txt_product.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txt_product.Location = new System.Drawing.Point(312, 301);
            this.txt_product.Name = "txt_product";
            this.txt_product.Size = new System.Drawing.Size(552, 31);
            this.txt_product.TabIndex = 24;
            this.txt_product.Text = "กรุณาระบุสิ่งที่ต้องการจัดซื้อหรือจัดจ้าง";
            this.txt_product.Click += new System.EventHandler(this.txt_product_Click);
            this.txt_product.TextChanged += new System.EventHandler(this.txt_product_TextChanged);
            // 
            // txt_reason
            // 
            this.txt_reason.Location = new System.Drawing.Point(952, 301);
            this.txt_reason.Name = "txt_reason";
            this.txt_reason.Size = new System.Drawing.Size(428, 31);
            this.txt_reason.TabIndex = 26;
            this.txt_reason.Text = "กรุณาระบุจุดประสงค์";
            this.txt_reason.Click += new System.EventHandler(this.txt_reason_Click);
            this.txt_reason.TextChanged += new System.EventHandler(this.txt_reason_TextChanged);
            this.txt_reason.MouseLeave += new System.EventHandler(this.txt_reason_MouseLeave);
            this.txt_reason.MouseHover += new System.EventHandler(this.txt_reason_MouseHover);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(902, 304);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(44, 26);
            this.label11.TabIndex = 25;
            this.label11.Text = "เพื่อ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(15, 342);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(78, 26);
            this.label12.TabIndex = 27;
            this.label12.Text = "โดยวิธี :";
            // 
            // box_method
            // 
            this.box_method.AutoCompleteCustomSource.AddRange(new string[] {
            "ตกลง ข้อ 31 (1) การซื้อหรือจ้างที่มีวงเงินไม่เกิน 500,000 บาท ตามข้อบังคับจุฬาลงก" +
                "รณ์มหาวิทยาลัย ว่าด้วยการพัสดุ พ.ศ.2559"});
            this.box_method.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.box_method.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.box_method.FormattingEnabled = true;
            this.box_method.Items.AddRange(new object[] {
            "ตกลง ข้อ 31 (1) การซื้อหรือจ้างที่มีวงเงินไม่เกิน 500,000 บาท ตามข้อบังคับจุฬาลงก" +
                "รณ์มหาวิทยาลัย ว่าด้วยการพัสดุ พ.ศ.2559"});
            this.box_method.Location = new System.Drawing.Point(97, 342);
            this.box_method.Name = "box_method";
            this.box_method.Size = new System.Drawing.Size(1075, 33);
            this.box_method.TabIndex = 28;
            this.box_method.Text = "ตกลง ข้อ 31 (1) การซื้อหรือจ้างที่มีวงเงินไม่เกิน 500,000 บาท ตามข้อบังคับจุฬาลงก" +
    "รณ์มหาวิทยาลัย ว่าด้วยการพัสดุ พ.ศ.2559";
            this.box_method.SelectedIndexChanged += new System.EventHandler(this.box_method_SelectedIndexChanged);
            this.box_method.Click += new System.EventHandler(this.box_method_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(11, 1076);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(468, 26);
            this.label15.TabIndex = 33;
            this.label15.Text = "กำหนดเวลาส่งมอบพัสดุหรืองานจ้างให้แล้วเสร็จภายใน :";
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // box_day
            // 
            this.box_day.FormattingEnabled = true;
            this.box_day.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31",
            "32",
            "33",
            "34",
            "35",
            "36",
            "37",
            "38",
            "39",
            "40",
            "41",
            "42",
            "43",
            "44",
            "45",
            "46",
            "47",
            "48",
            "49",
            "50",
            "51",
            "52",
            "53",
            "54",
            "55",
            "56",
            "57",
            "58",
            "59",
            "60",
            "61",
            "62",
            "63",
            "64",
            "65",
            "66",
            "67",
            "68",
            "69",
            "70",
            "71",
            "72",
            "73",
            "74",
            "75",
            "76",
            "77",
            "78",
            "79",
            "80",
            "81",
            "82",
            "83",
            "84",
            "85",
            "86",
            "87",
            "88",
            "89",
            "90",
            "91",
            "92",
            "93",
            "94",
            "95",
            "96",
            "97",
            "98",
            "99",
            "100",
            "101",
            "102",
            "103",
            "104",
            "105",
            "106",
            "107",
            "108",
            "109",
            "110",
            "111",
            "112",
            "113",
            "114",
            "115",
            "116",
            "117",
            "118",
            "119",
            "120",
            "121",
            "122",
            "123",
            "124",
            "125",
            "126",
            "127",
            "128",
            "129",
            "130",
            "131",
            "132",
            "133",
            "134",
            "135",
            "136",
            "137",
            "138",
            "139",
            "140",
            "141",
            "142",
            "143",
            "144",
            "145",
            "146",
            "147",
            "148",
            "149",
            "150",
            "151",
            "152",
            "153",
            "154",
            "155",
            "156",
            "157",
            "158",
            "159",
            "160",
            "161",
            "162",
            "163",
            "164",
            "165",
            "166",
            "167",
            "168",
            "169",
            "170",
            "171",
            "172",
            "173",
            "174",
            "175",
            "176",
            "177",
            "178",
            "179",
            "180",
            "181",
            "182",
            "183",
            "184",
            "185",
            "186",
            "187",
            "188",
            "189",
            "190",
            "191",
            "192",
            "193",
            "194",
            "195",
            "196",
            "197",
            "198",
            "199",
            "200",
            "201",
            "202",
            "203",
            "204",
            "205",
            "206",
            "207",
            "208",
            "209",
            "210",
            "211",
            "212",
            "213",
            "214",
            "215",
            "216",
            "217",
            "218",
            "219",
            "220",
            "221",
            "222",
            "223",
            "224",
            "225",
            "226",
            "227",
            "228",
            "229",
            "230",
            "231",
            "232",
            "233",
            "234",
            "235",
            "236",
            "237",
            "238",
            "239",
            "240",
            "241",
            "242",
            "243",
            "244",
            "245",
            "246",
            "247",
            "248",
            "249",
            "250",
            "251",
            "252",
            "253",
            "254",
            "255",
            "256",
            "257",
            "258",
            "259",
            "260",
            "261",
            "262",
            "263",
            "264",
            "265",
            "266",
            "267",
            "268",
            "269",
            "270",
            "271",
            "272",
            "273",
            "274",
            "275",
            "276",
            "277",
            "278",
            "279",
            "280",
            "281",
            "282",
            "283",
            "284",
            "285",
            "286",
            "287",
            "288",
            "289",
            "290",
            "291",
            "292",
            "293",
            "294",
            "295",
            "296",
            "297",
            "298",
            "299",
            "300",
            "301",
            "302",
            "303",
            "304",
            "305",
            "306",
            "307",
            "308",
            "309",
            "310",
            "311",
            "312",
            "313",
            "314",
            "315",
            "316",
            "317",
            "318",
            "319",
            "320",
            "321",
            "322",
            "323",
            "324",
            "325",
            "326",
            "327",
            "328",
            "329",
            "330",
            "331",
            "332",
            "333",
            "334",
            "335",
            "336",
            "337",
            "338",
            "339",
            "340",
            "341",
            "342",
            "343",
            "344",
            "345",
            "346",
            "347",
            "348",
            "349",
            "350",
            "351",
            "352",
            "353",
            "354",
            "355",
            "356",
            "357",
            "358",
            "359",
            "360",
            "361",
            "362",
            "363",
            "364",
            "365",
            "366"});
            this.box_day.Location = new System.Drawing.Point(559, 1073);
            this.box_day.Name = "box_day";
            this.box_day.Size = new System.Drawing.Size(66, 33);
            this.box_day.TabIndex = 34;
            this.box_day.Text = "0";
            this.box_day.SelectedIndexChanged += new System.EventHandler(this.box_day_SelectedIndexChanged);
            this.box_day.TextChanged += new System.EventHandler(this.box_day_TextChanged);
            this.box_day.Click += new System.EventHandler(this.box_day_Click);
            this.box_day.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.box_day_KeyPress);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(639, 897);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(37, 26);
            this.label16.TabIndex = 35;
            this.label16.Text = "วัน";
            this.label16.Click += new System.EventHandler(this.label16_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.916231F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label18.Location = new System.Drawing.Point(11, 1114);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(232, 26);
            this.label18.TabIndex = 38;
            this.label18.Text = "กรุณากรอกชื่อดังต่อไปนี้";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(1096, 1245);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(171, 26);
            this.label19.TabIndex = 39;
            this.label19.Text = "ประธานกรรมการ :";
            // 
            // txt_president1
            // 
            this.txt_president1.Location = new System.Drawing.Point(1541, 1245);
            this.txt_president1.Name = "txt_president1";
            this.txt_president1.Size = new System.Drawing.Size(613, 31);
            this.txt_president1.TabIndex = 40;
            this.txt_president1.Text = "กรุณากรอกชื่อประธานกรรมการ";
            this.txt_president1.Click += new System.EventHandler(this.txt_president_Click);
            this.txt_president1.TextChanged += new System.EventHandler(this.txt_president_TextChanged);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(1096, 1282);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(103, 26);
            this.label20.TabIndex = 41;
            this.label20.Text = "กรรมการ :";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(1096, 1320);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(221, 26);
            this.label21.TabIndex = 42;
            this.label21.Text = "กรรมการและเลขานุการ :";
            // 
            // txt_committee1
            // 
            this.txt_committee1.Location = new System.Drawing.Point(1541, 1282);
            this.txt_committee1.Name = "txt_committee1";
            this.txt_committee1.Size = new System.Drawing.Size(613, 31);
            this.txt_committee1.TabIndex = 43;
            this.txt_committee1.Text = "กรุณากรอกชื่อกรรมการ";
            this.txt_committee1.Click += new System.EventHandler(this.txt_committee_Click);
            // 
            // txt_secretary1
            // 
            this.txt_secretary1.Location = new System.Drawing.Point(1541, 1320);
            this.txt_secretary1.Name = "txt_secretary1";
            this.txt_secretary1.Size = new System.Drawing.Size(613, 31);
            this.txt_secretary1.TabIndex = 44;
            this.txt_secretary1.Text = "กรุณากรอกชื่อกรรมการและเลขานุการ";
            this.txt_secretary1.Click += new System.EventHandler(this.txt_secretary_Click);
            // 
            // txt_leaderBuyer
            // 
            this.txt_leaderBuyer.Location = new System.Drawing.Point(461, 1604);
            this.txt_leaderBuyer.Name = "txt_leaderBuyer";
            this.txt_leaderBuyer.Size = new System.Drawing.Size(609, 31);
            this.txt_leaderBuyer.TabIndex = 53;
            this.txt_leaderBuyer.Text = "กรุณากรอกชื่อผู้อำนวยการของหน่วยงาน";
            this.txt_leaderBuyer.Click += new System.EventHandler(this.txt_leaderBuyer_Click);
            // 
            // lbl_leaderBuyer
            // 
            this.lbl_leaderBuyer.AutoSize = true;
            this.lbl_leaderBuyer.Location = new System.Drawing.Point(15, 1604);
            this.lbl_leaderBuyer.Name = "lbl_leaderBuyer";
            this.lbl_leaderBuyer.Size = new System.Drawing.Size(239, 26);
            this.lbl_leaderBuyer.TabIndex = 51;
            this.lbl_leaderBuyer.Text = "ผู้อำนวยการของหน่วยงาน :";
            // 
            // txt_buyer
            // 
            this.txt_buyer.Location = new System.Drawing.Point(461, 1567);
            this.txt_buyer.Name = "txt_buyer";
            this.txt_buyer.Size = new System.Drawing.Size(609, 31);
            this.txt_buyer.TabIndex = 50;
            this.txt_buyer.Text = "กรุณากรอกชื่อผู้ขอซื้อหรือขอจ้าง";
            this.txt_buyer.Click += new System.EventHandler(this.txt_buyer_Click);
            // 
            // lbl_buyer
            // 
            this.lbl_buyer.AutoSize = true;
            this.lbl_buyer.Location = new System.Drawing.Point(15, 1567);
            this.lbl_buyer.Name = "lbl_buyer";
            this.lbl_buyer.Size = new System.Drawing.Size(150, 26);
            this.lbl_buyer.TabIndex = 49;
            this.lbl_buyer.Text = "ผู้ขอซื้อ/ ขอจ้าง :";
            this.lbl_buyer.Click += new System.EventHandler(this.label26_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.916231F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label22.Location = new System.Drawing.Point(15, 394);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(114, 26);
            this.label22.TabIndex = 56;
            this.label22.Text = "รายละเอียด";
            this.label22.Click += new System.EventHandler(this.label22_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(17, 433);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(70, 26);
            this.label23.TabIndex = 58;
            this.label23.Text = "ลำดับที่";
            // 
            // order_no
            // 
            this.order_no.Location = new System.Drawing.Point(93, 431);
            this.order_no.Name = "order_no";
            this.order_no.ReadOnly = true;
            this.order_no.Size = new System.Drawing.Size(74, 31);
            this.order_no.TabIndex = 60;
            this.order_no.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.order_no.ValueChanged += new System.EventHandler(this.order_no_ValueChanged);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(18, 475);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(202, 26);
            this.label27.TabIndex = 61;
            this.label27.Text = "รายการและรายละเอียด";
            this.label27.Click += new System.EventHandler(this.label27_Click);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(1261, 471);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(125, 26);
            this.label28.TabIndex = 63;
            this.label28.Text = "ประเภทสินค้า";
            // 
            // order_productDetail
            // 
            this.order_productDetail.Location = new System.Drawing.Point(281, 474);
            this.order_productDetail.Name = "order_productDetail";
            this.order_productDetail.Size = new System.Drawing.Size(745, 31);
            this.order_productDetail.TabIndex = 65;
            this.order_productDetail.Text = "กรุณากรอกรายการและรายละเอียดสินค้า";
            this.order_productDetail.Click += new System.EventHandler(this.order_productDetail_Click);
            this.order_productDetail.TextChanged += new System.EventHandler(this.order_productDetail_TextChanged);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(17, 519);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(94, 26);
            this.label29.TabIndex = 66;
            this.label29.Text = "หน่วยนับ:";
            this.label29.Click += new System.EventHandler(this.label29_Click);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(426, 520);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(132, 26);
            this.label30.TabIndex = 68;
            this.label30.Text = "ราคาต่อหน่วย:";
            this.label30.Click += new System.EventHandler(this.label30_Click);
            // 
            // order_unitPrice
            // 
            this.order_unitPrice.Location = new System.Drawing.Point(559, 517);
            this.order_unitPrice.Name = "order_unitPrice";
            this.order_unitPrice.Size = new System.Drawing.Size(133, 31);
            this.order_unitPrice.TabIndex = 69;
            this.order_unitPrice.TextChanged += new System.EventHandler(this.order_unitPrice_TextChanged);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(698, 520);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(47, 26);
            this.label31.TabIndex = 70;
            this.label31.Text = "บาท";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(873, 521);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(61, 26);
            this.label32.TabIndex = 73;
            this.label32.Text = "หน่วย";
            this.label32.Click += new System.EventHandler(this.label32_Click);
            // 
            // order_noUnit
            // 
            this.order_noUnit.Location = new System.Drawing.Point(826, 516);
            this.order_noUnit.Name = "order_noUnit";
            this.order_noUnit.Size = new System.Drawing.Size(49, 31);
            this.order_noUnit.TabIndex = 72;
            this.order_noUnit.TextChanged += new System.EventHandler(this.order_noUnit_TextChanged);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(751, 520);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(77, 26);
            this.label33.TabIndex = 71;
            this.label33.Text = "จำนวน:";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(1242, 520);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(47, 26);
            this.label34.TabIndex = 76;
            this.label34.Text = "บาท";
            // 
            // order_total
            // 
            this.order_total.Location = new System.Drawing.Point(1016, 517);
            this.order_total.Name = "order_total";
            this.order_total.ReadOnly = true;
            this.order_total.Size = new System.Drawing.Size(220, 31);
            this.order_total.TabIndex = 75;
            this.order_total.TextChanged += new System.EventHandler(this.order_total_TextChanged);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(957, 521);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(53, 26);
            this.label35.TabIndex = 74;
            this.label35.Text = "รวม:";
            this.label35.Click += new System.EventHandler(this.label35_Click);
            // 
            // btn_addOrder
            // 
            this.btn_addOrder.Location = new System.Drawing.Point(13, 567);
            this.btn_addOrder.Name = "btn_addOrder";
            this.btn_addOrder.Size = new System.Drawing.Size(106, 38);
            this.btn_addOrder.TabIndex = 78;
            this.btn_addOrder.Text = "เพิ่ม";
            this.btn_addOrder.UseVisualStyleBackColor = true;
            this.btn_addOrder.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_removeOrder
            // 
            this.btn_removeOrder.Location = new System.Drawing.Point(13, 932);
            this.btn_removeOrder.Name = "btn_removeOrder";
            this.btn_removeOrder.Size = new System.Drawing.Size(66, 37);
            this.btn_removeOrder.TabIndex = 79;
            this.btn_removeOrder.Text = "ลบ";
            this.btn_removeOrder.UseVisualStyleBackColor = true;
            this.btn_removeOrder.Click += new System.EventHandler(this.button2_Click);
            // 
            // btn_clearOrder
            // 
            this.btn_clearOrder.Location = new System.Drawing.Point(85, 932);
            this.btn_clearOrder.Name = "btn_clearOrder";
            this.btn_clearOrder.Size = new System.Drawing.Size(121, 37);
            this.btn_clearOrder.TabIndex = 80;
            this.btn_clearOrder.Text = "ล้างรายการ";
            this.btn_clearOrder.UseVisualStyleBackColor = true;
            this.btn_clearOrder.Click += new System.EventHandler(this.button3_Click);
            // 
            // btn_print
            // 
            this.btn_print.Location = new System.Drawing.Point(22, 1647);
            this.btn_print.Name = "btn_print";
            this.btn_print.Size = new System.Drawing.Size(113, 48);
            this.btn_print.TabIndex = 81;
            this.btn_print.Text = "Print";
            this.btn_print.UseVisualStyleBackColor = true;
            this.btn_print.Click += new System.EventHandler(this.btn_print_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(10, 611);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 33;
            this.dataGridView2.Size = new System.Drawing.Size(1943, 315);
            this.dataGridView2.TabIndex = 92;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(1289, 428);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(366, 26);
            this.label25.TabIndex = 93;
            this.label25.Text = "รหัสภาระผูกพัน (ผังบัญชี) / รหัสสินทรัพย์ :";
            this.label25.Click += new System.EventHandler(this.label25_Click);
            // 
            // order_glPw
            // 
            this.order_glPw.Location = new System.Drawing.Point(1670, 425);
            this.order_glPw.Name = "order_glPw";
            this.order_glPw.Size = new System.Drawing.Size(283, 31);
            this.order_glPw.TabIndex = 94;
            // 
            // btn_check
            // 
            this.btn_check.Location = new System.Drawing.Point(1061, 465);
            this.btn_check.Name = "btn_check";
            this.btn_check.Size = new System.Drawing.Size(176, 40);
            this.btn_check.TabIndex = 95;
            this.btn_check.Text = "Suggest";
            this.btn_check.UseVisualStyleBackColor = true;
            this.btn_check.Click += new System.EventHandler(this.btn_suggest_Click);
            // 
            // btn_korGumNod
            // 
            this.btn_korGumNod.Location = new System.Drawing.Point(962, 552);
            this.btn_korGumNod.Name = "btn_korGumNod";
            this.btn_korGumNod.Size = new System.Drawing.Size(128, 38);
            this.btn_korGumNod.TabIndex = 96;
            this.btn_korGumNod.Text = "ข้อกำหนด";
            this.btn_korGumNod.UseVisualStyleBackColor = true;
            this.btn_korGumNod.Visible = false;
            this.btn_korGumNod.Click += new System.EventHandler(this.button1_Click_2);
            // 
            // toolTip_txt_reason
            // 
            this.toolTip_txt_reason.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(1713, 470);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(134, 38);
            this.button2.TabIndex = 99;
            this.button2.Text = "Check";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.btn_check_Click);
            // 
            // order_boxProductType
            // 
            this.order_boxProductType.Location = new System.Drawing.Point(1418, 471);
            this.order_boxProductType.Name = "order_boxProductType";
            this.order_boxProductType.Size = new System.Drawing.Size(252, 31);
            this.order_boxProductType.TabIndex = 100;
            this.order_boxProductType.Text = "ประเภทสินค้า";
            this.order_boxProductType.Click += new System.EventHandler(this.order_boxProductType_Click);
            this.order_boxProductType.TextChanged += new System.EventHandler(this.order_boxProductType_TextChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(707, 556);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(47, 26);
            this.label13.TabIndex = 103;
            this.label13.Text = "บาท";
            // 
            // order_lastPrice
            // 
            this.order_lastPrice.Location = new System.Drawing.Point(568, 554);
            this.order_lastPrice.Name = "order_lastPrice";
            this.order_lastPrice.Size = new System.Drawing.Size(133, 31);
            this.order_lastPrice.TabIndex = 102;
            this.order_lastPrice.TextChanged += new System.EventHandler(this.txt_lastPrice_TextChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(307, 556);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(238, 26);
            this.label14.TabIndex = 101;
            this.label14.Text = "ราคาครั้งหลังสุด/ ท้องตลาด:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(601, 95);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(129, 26);
            this.label17.TabIndex = 104;
            this.label17.Text = "รหัสหน่วยงาน";
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // box_institutePw
            // 
            this.box_institutePw.Location = new System.Drawing.Point(750, 92);
            this.box_institutePw.Name = "box_institutePw";
            this.box_institutePw.Size = new System.Drawing.Size(173, 31);
            this.box_institutePw.TabIndex = 105;
            this.box_institutePw.Text = "0163";
            this.box_institutePw.Click += new System.EventHandler(this.box_institutePw_Click);
            this.box_institutePw.TextChanged += new System.EventHandler(this.box_institutePw_TextChanged);
            // 
            // txt_day
            // 
            this.txt_day.Location = new System.Drawing.Point(826, 1076);
            this.txt_day.Name = "txt_day";
            this.txt_day.Size = new System.Drawing.Size(319, 31);
            this.txt_day.TabIndex = 106;
            this.txt_day.ValueChanged += new System.EventHandler(this.txt_day_ValueChanged);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(717, 1076);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(48, 26);
            this.label24.TabIndex = 107;
            this.label24.Text = "หรือ";
            // 
            // txt_vendor
            // 
            this.txt_vendor.Location = new System.Drawing.Point(461, 1151);
            this.txt_vendor.Name = "txt_vendor";
            this.txt_vendor.Size = new System.Drawing.Size(609, 31);
            this.txt_vendor.TabIndex = 109;
            this.txt_vendor.Text = "กรุณากรอกชื่อผู้ประกอบการ";
            this.txt_vendor.Click += new System.EventHandler(this.txt_vendor_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(18, 1156);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(139, 26);
            this.label26.TabIndex = 108;
            this.label26.Text = "ผู้ประกอบการ :";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(12, 31);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(60, 26);
            this.label36.TabIndex = 110;
            this.label36.Text = "เลขที่:";
            // 
            // txt_no
            // 
            this.txt_no.Location = new System.Drawing.Point(93, 26);
            this.txt_no.Name = "txt_no";
            this.txt_no.Size = new System.Drawing.Size(97, 31);
            this.txt_no.TabIndex = 111;
            this.txt_no.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(221, 31);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(56, 26);
            this.label37.TabIndex = 112;
            this.label37.Text = "วันที่:";
            // 
            // txt_prDate
            // 
            this.txt_prDate.Location = new System.Drawing.Point(283, 26);
            this.txt_prDate.Name = "txt_prDate";
            this.txt_prDate.Size = new System.Drawing.Size(261, 31);
            this.txt_prDate.TabIndex = 113;
            this.txt_prDate.ValueChanged += new System.EventHandler(this.txt_prDate_ValueChanged);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(563, 28);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(90, 26);
            this.label38.TabIndex = 114;
            this.label38.Text = "โทรศัพท์:";
            // 
            // txt_phoneNo
            // 
            this.txt_phoneNo.Location = new System.Drawing.Point(659, 26);
            this.txt_phoneNo.Name = "txt_phoneNo";
            this.txt_phoneNo.Size = new System.Drawing.Size(308, 31);
            this.txt_phoneNo.TabIndex = 115;
            this.txt_phoneNo.Text = "กรุณากรอกเบอร์โทรศัพท์";
            this.txt_phoneNo.Click += new System.EventHandler(this.txt_phoneNo_Click);
            // 
            // txt_staff1
            // 
            this.txt_staff1.Location = new System.Drawing.Point(463, 1245);
            this.txt_staff1.Name = "txt_staff1";
            this.txt_staff1.Size = new System.Drawing.Size(613, 31);
            this.txt_staff1.TabIndex = 117;
            this.txt_staff1.Text = "กรุณากรอกชื่อผู้ตรวจรับพัสดุ";
            this.txt_staff1.Click += new System.EventHandler(this.txt_staff1_Click);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(17, 1245);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(143, 26);
            this.label39.TabIndex = 116;
            this.label39.Text = "ผู้ตรวจรับพัสดุ :";
            // 
            // btn_day
            // 
            this.btn_day.AutoSize = true;
            this.btn_day.Location = new System.Drawing.Point(510, 1078);
            this.btn_day.Name = "btn_day";
            this.btn_day.Size = new System.Drawing.Size(21, 20);
            this.btn_day.TabIndex = 118;
            this.btn_day.TabStop = true;
            this.btn_day.UseVisualStyleBackColor = true;
            this.btn_day.CheckedChanged += new System.EventHandler(this.btn_day_CheckedChanged);
            // 
            // btn_date
            // 
            this.btn_date.AutoSize = true;
            this.btn_date.Location = new System.Drawing.Point(787, 1078);
            this.btn_date.Name = "btn_date";
            this.btn_date.Size = new System.Drawing.Size(21, 20);
            this.btn_date.TabIndex = 119;
            this.btn_date.TabStop = true;
            this.btn_date.UseVisualStyleBackColor = true;
            this.btn_date.CheckedChanged += new System.EventHandler(this.btn_date_CheckedChanged);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.916231F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label40.Location = new System.Drawing.Point(11, 1204);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(307, 26);
            this.label40.TabIndex = 120;
            this.label40.Text = "กรณีวงเงินไม่เกิน 100,000 บาท";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.916231F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label41.Location = new System.Drawing.Point(13, 1369);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(281, 26);
            this.label41.TabIndex = 123;
            this.label41.Text = "กรณีวงเงินเกิน 100,000 บาท";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(354, 1369);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(192, 26);
            this.label42.TabIndex = 124;
            this.label42.Text = "คณะกรรมการรับพัสดุ";
            // 
            // txt_secretary2
            // 
            this.txt_secretary2.Location = new System.Drawing.Point(461, 1487);
            this.txt_secretary2.Name = "txt_secretary2";
            this.txt_secretary2.Size = new System.Drawing.Size(613, 31);
            this.txt_secretary2.TabIndex = 130;
            this.txt_secretary2.Text = "กรุณากรอกชื่อกรรมการและเลขานุการ";
            this.txt_secretary2.Click += new System.EventHandler(this.txt_secretary2_Click);
            // 
            // txt_committee2
            // 
            this.txt_committee2.Location = new System.Drawing.Point(461, 1449);
            this.txt_committee2.Name = "txt_committee2";
            this.txt_committee2.Size = new System.Drawing.Size(613, 31);
            this.txt_committee2.TabIndex = 129;
            this.txt_committee2.Text = "กรุณากรอกชื่อกรรมการ";
            this.txt_committee2.Click += new System.EventHandler(this.txt_committee2_Click);
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(16, 1487);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(221, 26);
            this.label43.TabIndex = 128;
            this.label43.Text = "กรรมการและเลขานุการ :";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(16, 1449);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(103, 26);
            this.label44.TabIndex = 127;
            this.label44.Text = "กรรมการ :";
            // 
            // txt_president2
            // 
            this.txt_president2.Location = new System.Drawing.Point(461, 1412);
            this.txt_president2.Name = "txt_president2";
            this.txt_president2.Size = new System.Drawing.Size(613, 31);
            this.txt_president2.TabIndex = 126;
            this.txt_president2.Text = "กรุณากรอกชื่อประธานกรรมการ";
            this.txt_president2.Click += new System.EventHandler(this.txt_president2_Click);
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(16, 1412);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(171, 26);
            this.label45.TabIndex = 125;
            this.label45.Text = "ประธานกรรมการ :";
            // 
            // btn_korGumNodPrBuyer
            // 
            this.btn_korGumNodPrBuyer.Location = new System.Drawing.Point(1587, 171);
            this.btn_korGumNodPrBuyer.Name = "btn_korGumNodPrBuyer";
            this.btn_korGumNodPrBuyer.Size = new System.Drawing.Size(128, 38);
            this.btn_korGumNodPrBuyer.TabIndex = 132;
            this.btn_korGumNodPrBuyer.Text = "ข้อกำหนด";
            this.btn_korGumNodPrBuyer.UseVisualStyleBackColor = true;
            this.btn_korGumNodPrBuyer.Visible = false;
            this.btn_korGumNodPrBuyer.Click += new System.EventHandler(this.btn_korGumNodPrBuyer_Click);
            // 
            // btn_personCheck
            // 
            this.btn_personCheck.AutoSize = true;
            this.btn_personCheck.Location = new System.Drawing.Point(359, 1205);
            this.btn_personCheck.Name = "btn_personCheck";
            this.btn_personCheck.Size = new System.Drawing.Size(157, 30);
            this.btn_personCheck.TabIndex = 133;
            this.btn_personCheck.Text = "ผู้ตรวจรับพัสดุ";
            this.btn_personCheck.UseVisualStyleBackColor = true;
            this.btn_personCheck.CheckedChanged += new System.EventHandler(this.btn_personCheck_CheckedChanged);
            // 
            // btn_committeeCheck
            // 
            this.btn_committeeCheck.AutoSize = true;
            this.btn_committeeCheck.Location = new System.Drawing.Point(556, 1205);
            this.btn_committeeCheck.Name = "btn_committeeCheck";
            this.btn_committeeCheck.Size = new System.Drawing.Size(263, 30);
            this.btn_committeeCheck.TabIndex = 134;
            this.btn_committeeCheck.Text = "คณะกรรมการตรวจรับพัสดุุ";
            this.btn_committeeCheck.UseVisualStyleBackColor = true;
            this.btn_committeeCheck.CheckedChanged += new System.EventHandler(this.btn_committeeCheck_CheckedChanged);
            // 
            // box_institute
            // 
            this.box_institute.FormattingEnabled = true;
            this.box_institute.Items.AddRange(new object[] {
            "ศูนย์กฎหมายและนิติการ",
            "ศูนย์บริหารกลาง",
            "ศูนย์นวัตกรรมการเรียนรู้",
            "ศูนย์เครือข่ายการเรียนรู้เพื่อภูมิภาค",
            "ศูนย์บริหารความเสี่ยง",
            "ศูนย์พัฒนกิจและนิสิตเก่าสัมพันธ์",
            "ศูนย์วิเคราะห์รายได้และปฏิบัติการลงทุน",
            "ศูนย์สื่อสารองค์กร",
            "กิจการนิสิต"});
            this.box_institute.Location = new System.Drawing.Point(134, 93);
            this.box_institute.Name = "box_institute";
            this.box_institute.Size = new System.Drawing.Size(411, 33);
            this.box_institute.TabIndex = 135;
            this.box_institute.Text = "ศูนย์กฎหมายและนิติการ";
            this.box_institute.Click += new System.EventHandler(this.box_institute_Click);
            // 
            // box_biz
            // 
            this.box_biz.FormattingEnabled = true;
            this.box_biz.Items.AddRange(new object[] {
            "สนม.-กบศ(งบรายได้)  /  1101",
            "สนม.-กองทุนกาญจนาสมโภช ฯ  /  1201",
            "สนม.-เงินทุนวารสารมนุษย  /  1301",
            "สนม.-กองทุนสมเด็จพระมหิตลาฯ  /  1401",
            "สนม.-กองทุนศ.รัชมังคลาภิเษกฯ  /  1501",
            "สนม.-กท.สมเด็จพระบรมโอรสาธิฯ  /  1601",
            "สนม.-งท.จุฬาฯ 100 ปี กท.บรม  /  1701",
            "สนม.-กวจ(งบรายได้)  /  2101",
            "สนม.-กองทุนรัชดาภิเษกสมโภช  /  2201",
            "สนม.-เงินทุน ดร.คัทสึโนะ  /  2301",
            "สนม.-งท.พัฒนาทรัพย์สินทางปัญญา  /  2401",
            "สนม.-กองทุนศ.รัชมังคลาภิเษกฯ  /  2501",
            "สนม.-กวช(งบรายได้)  /  3101",
            "สนม.-กวช  /  3201",
            "สนม.-กนส(งบรายได้)  /  4101",
            "สนม.-กองทุนอุดหนุนการศึกษาฯ  /  4201",
            "สนม.-กนส  /  4301",
            "สนม.-งท.สวัสดิภาพนิสิตจุฬาฯ  /  4401",
            "สนม.-งท.ส่งเสริมการกีฬา  /  4501",
            "สนม.-กศว(งบรายได้)  /  5101",
            "สนม.-กองทุนเพื่อการทะนุบำรุงฯ  /  5201",
            "สนม.-กองทุนจุฬาฯสมเด็จพระเทพฯ  /  5301",
            "สนม.-กพบ(งบรายได้)  /  6101",
            "สนม.-กพบ  /  6201",
            "กองทุนทั่วไป  /  7001",
            "สนม.-วิจัยเพื่อ คณะนิเทศศาสตร์  /  7201",
            "สนม.-งท.บำเหน็จชดเชย  /  7301",
            "สนม.-งผด.รอตัดจ่าย  /  7901",
            "สนม.-งท.อ.บรมราชกุมารี ใน งทป.  /  7A01",
            "สนม.-กสท  /  8001",
            "สนม.-วิจัยเพื่อ คณะพาณิชย์ฯ  /  8201",
            "สนม.-กสร  /  9001",
            "สนม.-วิจัยเพื่อ คณะแพทยศาสตร์  /  9201",
            "สนม.-บัญชีสำนักงานมหาวิทยาลัย  /  9801",
            "สนม.-ผด.  /  9901",
            "สนม.-เงินทุนอื่นๆ  /  9A01",
            "สนม.-สวัสดิการเงินกู้เพื่อเคหะ  /  9B01",
            "สนม.-เงินกู้ฯ (จัดการทรัพย์สิน  /  9C01",
            "สำนักงานการจัดการทรัพย์สิน  /  9D01",
            "สนม.-กองทุนพระตำหนักดาราภิรมย์  /  9ก01",
            "สนม.-กองทุนจุฬาลงกรณ์บรมราชสมฯ  /  9ข01",
            "สนม.-งท.จุฬาฯ 100ปี-บริหารวช.  /  A101",
            "สนม.-งท.จุฬาฯ 100ปี-วิจัย  /  A201",
            "สนม.-ทั่วไปเพื่อพบ.  /  A701",
            "สนม.-งท.จุฬาฯ 100ปี-ส/ท ถาวร  /  A801",
            "สนม.-วิจัยเพื่อ คณะเภสัชศาสตร์  /  B201",
            "สนม.-ทั่วไปเพื่อ ส.เกษตร  /  B701",
            "สนม.-สินทรัพย์เพื่อ ส.(ยกเลิก)  /  B801",
            "สนม.-วิจัยเพื่อ คณะรัฐศาสตร์  /  C201",
            "สนม.-วิจัยเพื่อ คณะเศรษฐศาสตร์  /  F201",
            "สนม.-วิจัยเพื่อ คณะศิลปกรรมศาส  /  G201",
            "สนม.-สินทรัพย์ถาวรเพื่อศิลปกรร  /  G801",
            "สนม.-สำรองเพื่อศิลปกรรมศาสตร์  /  G901",
            "สนม.-วิจัยเพื่อ คณะสถาปัตยกรรม  /  H201",
            "สนม.-วิจัยเพื่อ คณะสหเวชศาสตร์  /  I201",
            "สนม.-วิจัยเพื่อ คณะสัตวแพทยศาส  /  J201",
            "สนม.-วิจัยเพื่อ คณะอักษรศาสตร์  /  K201",
            "สนม.-ศิลปะเพื่ออักษร  /  K501",
            "สนม.-วิจัยเพื่อ ปิโตร  /  M201",
            "สนม.-วิจัยเพื่อ ประชากร  /  N201",
            "สนม.-วิจัยเพื่อ วิทย์กีฬา  /  O201",
            "สนม.-สินทรัพย์ถาวรเพื่อคณะกีฬา  /  O801",
            "สนม.-วิจัยเพื่อ สถาบันการขนส่ง  /  P201",
            "สนม.-วิจัยเพื่อ เทคโนชีวภาพฯ  /  Q201",
            "สนม.-วิจัยเพื่อ สถาบันภาษา  /  R201",
            "สนม.-สินทรัพย์ถาวรเพื่อ สษ.  /  R801",
            "สนม.-บริหารวิชาการเพื่อ สวท.  /  S101",
            "สนม.-วิจัยเพื่อ สวท.  /  S201",
            "สนม.-งทป.เพื่อ สวท  /  S701",
            "สนม.-สินทรัพย์ถาวรเพื่อ สวท.  /  S801",
            "สนม.-วิจัยเพื่อ ทรัพย์น้ำ  /  T201",
            "สนม.-ทั่วไปเพื่อ ส.วิจัยทางน้ำ  /  T701",
            "สนม.-วิจัยเพื่อ พลังงาน  /  U201",
            "สนม.-วิจัยเพื่อ วิจัยโลหะ  /  V201",
            "สนม.-วิจัยเพื่อ วิทย์การแพทย์  /  W201",
            "สนม.-ทั่วไปเพื่อววส.  /  W701",
            "สนม.-วิจัยเพื่อ สังคม  /  X201",
            "สนม.-วิจัยเพื่อ แวดล้อม  /  Y201",
            "สนม.-วิจัยเพื่อ เอเชียศึกษา  /  Z201",
            "ศมว.-งวจ.  /  ก201",
            "สนม.-วิจัยเพื่อ ส.การทะเบียน  /  ข201",
            "สนม.-คก.ไทยเข้มแข็ง  /  ขข01",
            "สนม.-งทป.เพื่อส.เกษตร  /  ค701",
            "ศวฮ.-งวจ.  /  ง201",
            "สนม.-วชเพื่อ สทศ  /  จ101",
            "สนม.-วิจัยเพื่อ สทศ  /  จ201",
            "สนม.-งทป.เพื่อ สทศ  /  จ701",
            "สทส.-งบศ.  /  ฉ101",
            "สนม.-งทป.เพื่อ สทส  /  ฉ701",
            "ศสท.-งวจ  /  ช201",
            "ศก.-งนส.  /  ซ401",
            "ศสภ.-งทป.  /  ฌ701",
            "ศคภ.-งทป.  /  ญ701",
            "สนม.-สินทรัพย์ถาวรเพื่อ ศคภ.  /  ญ801",
            "สนม.วิจัยเพื่อ-ศวพ.  /  ฎ201"});
            this.box_biz.Location = new System.Drawing.Point(1177, 90);
            this.box_biz.Name = "box_biz";
            this.box_biz.Size = new System.Drawing.Size(556, 33);
            this.box_biz.TabIndex = 136;
            this.box_biz.Text = "กองทุนทั่วไป  /  7001";
            this.box_biz.SelectedIndexChanged += new System.EventHandler(this.box_biz_SelectedIndexChanged_1);
            this.box_biz.Click += new System.EventHandler(this.box_biz_Click);
            // 
            // box_center
            // 
            this.box_center.FormattingEnabled = true;
            this.box_center.Items.AddRange(new object[] {
            "สำนักบริหารการเงิน การบัญชี และการพัสดุ  /  2101010000",
            "ก.ธุรการ สผค.  /  2101010400",
            "ฝ่ายการเงิน สบง.  /  2101010500",
            "ฝ่ายการบัญชี สบง.  /  2101010600",
            "ฝ่ายการพัสดุ สบง.  /  2101010700",
            "สำนักบริหารทรัพยากรมนุษย์  /  2101030000",
            "ฝ่ายบริหารงานบุคคล สบม.  /  2101030100",
            "ฝ่ายพัฒนาบุคลากร  /  2101030200",
            "ฝ่ายพัฒนาระบบงานบุคคล  /  2101030300",
            "สำนักบริหารระบบกายภาพ  /  2101040000",
            "ฝ่ายปฏิบัติการอาคารสถานที่ สบภ.  /  2101040700",
            "ฝ่ายสถาปัตยกรรมและโครงสร้างพื้นฐาน สบภ.  /  2101040800",
            "ฝ่ายจัดการอาคารสถานที่และสารสนเทศระบบกาย  /  2101040900",
            "ศูนย์จุฬาฯ-ชนบท ศจช.  /  2101050000",
            "สำนักงานเครือข่ายการเรียนรู้ฯ สนม.  /  2101060000",
            "สำนักบริหารกิจการนิสิต  /  2101080000",
            "หน่วยหอพักนิสิต สบน.  /  2101080001",
            "หน่วยส่งเสริมสุขภาวะนิสิต สบน.  /  2101080002",
            "ฝ่ายทุนการศึกษาและบริการนิสิต สบน.  /  2101081100",
            "ฝ่ายพัฒนานิสิต สบน.  /  2101081200",
            "ฝ่ายประสานงานและเครือข่ายกิจการนิสิต สบน  /  2101081300",
            "สำนักงานเลขานุการบริหารของอธิการบดี สนม.  /  2101090000",
            "สำนักงานจัดการทรัพย์สิน สนม.  /  2101110000",
            "สำนักบริหารวิรัชกิจและเครือข่ายนานา สนม.  /  2101120000",
            "ฝ่ายกิจการต่างประเทศ สบร.  /  2101120100",
            "ฝ่ายเครือข่ายนานาชาติ สบร.  /  2101120200",
            "ฝ่ายบริการกิจการนิสิตและอาจารย์ชาวต่างปร  /  2101120300",
            "สำนักบริหารเทคโนโลยีสารสนเทศ  /  2101130000",
            "ฝ่ายโครงสร้างพื้นฐานเทคโนโลยีสารสนเทศ สบ  /  2101130500",
            "ฝ่ายระบบเทคโนโลยีสารสนเทศ สบท.  /  2101130600",
            "ฝ่ายบริการเทคโนโลยีสารสนเทศ สบท.  /  2101130700",
            "ศูนย์สื่อสารองค์กร  /  2101140000",
            "งานสารนิเทศ  /  2101140100",
            "งานสื่อสารนานาชาติ  /  2101140200",
            "สำนักงานจัดการอาคาร สนม.  /  2101160000",
            "สำนักบริหารการเงิน การบัญชี และการพัสดุ  /  2101010000",
            "ก.ธุรการ สผค.  /  2101010400",
            "ฝ่ายการเงิน สบง.  /  2101010500",
            "ฝ่ายการบัญชี สบง.  /  2101010600",
            "ฝ่ายการพัสดุ สบง.  /  2101010700",
            "สำนักบริหารทรัพยากรมนุษย์  /  2101030000",
            "ฝ่ายบริหารงานบุคคล สบม.  /  2101030100",
            "ฝ่ายพัฒนาบุคลากร  /  2101030200",
            "ฝ่ายพัฒนาระบบงานบุคคล  /  2101030300",
            "สำนักบริหารระบบกายภาพ  /  2101040000",
            "ฝ่ายปฏิบัติการอาคารสถานที่ สบภ.  /  2101040700",
            "ฝ่ายสถาปัตยกรรมและโครงสร้างพื้นฐาน สบภ.  /  2101040800",
            "ฝ่ายจัดการอาคารสถานที่และสารสนเทศระบบกาย  /  2101040900",
            "ศูนย์จุฬาฯ-ชนบท ศจช.  /  2101050000",
            "สำนักงานเครือข่ายการเรียนรู้ฯ สนม.  /  2101060000",
            "สำนักบริหารกิจการนิสิต  /  2101080000",
            "หน่วยหอพักนิสิต สบน.  /  2101080001",
            "หน่วยส่งเสริมสุขภาวะนิสิต สบน.  /  2101080002",
            "ฝ่ายทุนการศึกษาและบริการนิสิต สบน.  /  2101081100",
            "ฝ่ายพัฒนานิสิต สบน.  /  2101081200",
            "ฝ่ายประสานงานและเครือข่ายกิจการนิสิต สบน  /  2101081300",
            "สำนักงานเลขานุการบริหารของอธิการบดี สนม.  /  2101090000",
            "สำนักงานจัดการทรัพย์สิน สนม.  /  2101110000",
            "สำนักบริหารวิรัชกิจและเครือข่ายนานา สนม.  /  2101120000",
            "ฝ่ายกิจการต่างประเทศ สบร.  /  2101120100",
            "ฝ่ายเครือข่ายนานาชาติ สบร.  /  2101120200",
            "ฝ่ายบริการกิจการนิสิตและอาจารย์ชาวต่างปร  /  2101120300",
            "สำนักบริหารเทคโนโลยีสารสนเทศ  /  2101130000",
            "ฝ่ายโครงสร้างพื้นฐานเทคโนโลยีสารสนเทศ สบ  /  2101130500",
            "ฝ่ายระบบเทคโนโลยีสารสนเทศ สบท.  /  2101130600",
            "ฝ่ายบริการเทคโนโลยีสารสนเทศ สบท.  /  2101130700",
            "ศูนย์สื่อสารองค์กร  /  2101140000",
            "งานสารนิเทศ  /  2101140100",
            "งานสื่อสารนานาชาติ  /  2101140200",
            "สำนักงานจัดการอาคาร สนม.  /  2101160000",
            "ศูนย์พัฒนกิจและนิสิตเก่าสัมพันธ์  /  2101170000",
            "สำนักพิมพ์แห่งจุฬาลงกรณ์ฯ สนม.  /  2101210000",
            "งานธุรการ สำนักพิมพ์  /  2101210100",
            "งานจัดทำหนังสือ สำนักพิมพ์  /  2101210200",
            "งานการเงินและการบัญชี สำนักพิมพ์  /  2101210300",
            "งานส่งเสริมการผลิตและการตลาด สำนักพิมพ์  /  2101210400",
            "งานด้านสื่อประสม สำนักพิมพ์  /  2101210500",
            "หอพักนานาชาติศึกษิตนิเวศน์ สนม.  /  2101270000",
            "ศูนย์การศึกษาทั่วไป ศศท.  /  2101310000",
            "สถาบันไทยศึกษา สนม.  /  2101320000",
            "สำนักบริหารศิลปวัฒนธรรม สนม  /  2101330000",
            "ฝ่ายพัฒนาและส่งเสริมศิลปวัฒนธรรม สบศ.  /  2101330100",
            "ฝ่ายพิพิธภัณฑ์และหอศิลป์ สบศ.  /  2101330200",
            "หอประวัติแห่งจุฬาลงกรณ์ฯ สนม.  /  2101340000",
            "ธรรมสถาน สนม.  /  2101350000",
            "ศูนย์พุทธศาสน์ศึกษา สนม.  /  2101360000",
            "ศูนย์ยุโรปศึกษา สนม.  /  2101370000",
            "สภาคณาจารย์  /  2101400000",
            "สโมสรอาจารย์  /  2101410000",
            "ชมรมพฤทธาจารย์  /  2101420000",
            "สถาบันทรัพย์สินทางปัญญาแห่งจุฬาฯ  /  2101430000",
            "สำนักงานสภามหาวิทยาลัย สนม.  /  2101540000",
            "ศูนย์ภาษาไทยสิรินธร  /  2101550000",
            "ศูนย์รักษาความปลอดภัยและจัดการจราจร จุฬา  /  2101560000",
            "ศูนย์บริการสุขภาพ สนม.  /  2101570000",
            "ศูนย์การจัดการทรัพยากรของมหาวิทยาลัย  /  2101580000",
            "ศูนย์รัสเซียศึกษาแห่งจุฬาฯ_รายได้  /  2101590000",
            "สถาบันขงจื่อแห่งจุฬาลงกรณ์มหาวิทยาลัย_ร  /  2101600000",
            "สำนักบริหารยุทธศาสตร์และการงบประมาณ  /  2101610000",
            "ฝ่ายยุทธศาสตร์และนวัตกรรมองค์กร  /  2101610100",
            "ฝ่ายบริหารคุณภาพองค์กร  /  2101610200",
            "ฝ่ายการงบประมาณ สบย.  /  2101610300",
            "ศูนย์บริหารกลาง  /  2101620000",
            "งานสารบรรณ พิธีการ และกิจการพิเศษ  /  2101620100",
            "งานการประชุมและเลขานุการผู้บริหาร  /  2101620200",
            "หน่วยการประชุม  /  2101620201",
            "หน่วยเลขานุการผู้บริหาร  /  2101620202",
            "ศูนย์กฎหมายและนิติการ  /  2101630000",
            "ศูนย์วิเคราะห์เงินรายได้และปฏิบัติการลงท  /  2101640000",
            "Chula Global Network  /  2101650000",
            "ศูนย์บริหารความเสี่ยง  /  2101660000",
            "สำนักบริหารวิชาการ  /  2101700000",
            "ฝ่ายพัฒนาวิชาการ สบว.  /  2101700100",
            "ฝ่ายพัฒนาหลักสูตร สบว.  /  2101700200",
            "ฝ่ายบริหารทุนวิชาการ สบว.  /  2101700300",
            "สำนักบริหารวิจัย สบจ.  /  2101710000",
            "หน่วยคลินิกวิจัย สบจ.  /  2101710001",
            "ฝ่ายพัฒนาและบูรณาการงานวิจัย สบจ.  /  2101710100",
            "ฝ่ายทุนวิจัย สบจ.  /  2101710200",
            "ฝ่ายวิเคราะห์และเผยแพร่ผลงานวิจัย สบจ.  /  2101710300",
            "ศูนย์ศึกษาสันติภาพและความขัดแย้ง  /  2101720000",
            "ศูนย์อินเดียศึกษา  /  2101730000",
            "ศูนย์อาเซียนศึกษา  /  2101740000",
            "ศูนย์นวัตกรรมการเรียนรู้  /  2101750000"});
            this.box_center.Location = new System.Drawing.Point(214, 133);
            this.box_center.Name = "box_center";
            this.box_center.Size = new System.Drawing.Size(478, 33);
            this.box_center.TabIndex = 137;
            this.box_center.Text = "ศูนย์กฎหมายและนิติการ  /  2101630000";
            this.box_center.SelectedIndexChanged += new System.EventHandler(this.box_center_SelectedIndexChanged_1);
            this.box_center.Click += new System.EventHandler(this.box_center_Click);
            // 
            // box_fund
            // 
            this.box_fund.FormattingEnabled = true;
            this.box_fund.Items.AddRange(new object[] {
            "กองทุนงบแผ่นดิน-สนม.  /  1010019900",
            "กองทุนบริหารวิชาการและการศึกษา-สนม.  /  2010041000",
            "กองทุนบริหารวิชาการ/ศึกษา-สนม.(รายได้)  /  2010041001",
            "กองทุนกาญจนาภิเษกเฉลิมพระเกียรติ-สนม.  /  2010041002",
            "เงินทุนวารสารมนุษย-สนม.  /  2010041003",
            "กองทุนมหิตลาธิเบศรอดุลยเดชวิกรม-สนม.  /  2010041004",
            "กองทุนสมเด็จพระบรมโอรสธิราช  /  2010041006",
            "กองทุนจุฬาลงกรณ์ บรมราชสมภพฯ  /  2010041007",
            "เงินทุนจุฬา 100 ปี-บริหารวิชาการ  /  2010041100",
            "เงินทุนจุฬาศตวรรษที่2-บริหารวิชาการ  /  2010041200",
            "กองทุนวิจัย-สนม.  /  2010042000",
            "กองทุนวิจัย-สนม.(รายได้)  /  2010042001",
            "กองทุนรัชดาภิเษกสมโภช-สนม.  /  2010042002",
            "เงินทุน ดร.คัทสึโนะ สึเดะ มาเอดะ-สนม.  /  2010042003",
            "กองทุนรัชมังคลาภิเษกสมโภช-สนม.  /  2010042004",
            "เงินทุนจุฬา 100 ปี-วิจัย  /  2010042100",
            "เงินทุนจุฬาศตวรรษที่2-วิจัย  /  2010042200",
            "รายได้จากวิจัยรับล่วงหน้า-สนม.  /  2010042980",
            "กองทุนบริการวิชาการ-สนม.  /  2010043000",
            "กองทุนบริการวิชาการ-สนม.(รายได้)  /  2010043001",
            "กองทุนบริการวิชาการ-สนม.  /  2010043002",
            "รายได้จากบริการวิชาการรับล่วงหน้า-สนม.  /  2010043980",
            "กองทุนเพื่อกิจการนิสิต-สนม.  /  2010044000",
            "กองทุนเพื่อกิจการนิสิต-สนม.(รายได้)  /  2010044001",
            "กองทุนอุดหนุนศึกษานิสิต-สนม.  /  2010044002",
            "กองทุนเพื่อกิจการนิสิต-สนม.  /  2010044003",
            "เงินทุนส่งเสริมการกีฬาจุฬาฯ  /  2010044004",
            "กองทุนเพื่อศิลปะและวัฒนธรรม-สนม.  /  2010045000",
            "กองทุนเพื่อศิลปะและวัฒนธรรม-สนม.(รายได้)  /  2010045001",
            "กองทุนเพื่อทะนุบำรุงศิลปะ-สนม.  /  2010045002",
            "กองทุนฉลองสมเด็จพระเทพ-สนม.  /  2010045003",
            "กองทุนพระตำหนักดาราภิรมย์-สนม.  /  2010045004",
            "กองทุนเพื่อการพัฒนาบุคลากร-สนม.  /  2010046000",
            "กองทุนเพื่อการพัฒนาบุคลากร-สนม.(รายได้)  /  2010046001",
            "กองทุนเพื่อการพัฒนาบุคลากร-สนม.  /  2010046002",
            "กองทุนทั่วไป-สนม.  /  2010047000",
            "เงินทุนบำเหน็จชดเชย  /  2010047301",
            "กองทุนสินทรัพย์ถาวร-สนม.  /  2010048000",
            "เงินทุนจุฬา 100 ปี-สินทรัพย์ถาวร  /  2010048100",
            "กองทุนสำรอง-สนม.  /  2010049000",
            "กองทุนบัญชีคณะ-สนม.  /  2010049800"});
            this.box_fund.Location = new System.Drawing.Point(1025, 135);
            this.box_fund.Name = "box_fund";
            this.box_fund.Size = new System.Drawing.Size(556, 33);
            this.box_fund.TabIndex = 138;
            this.box_fund.Text = "กองทุนทั่วไป-สนม.  /  2010047000";
            this.box_fund.Click += new System.EventHandler(this.box_fund_Click);
            // 
            // box_district
            // 
            this.box_district.FormattingEnabled = true;
            this.box_district.Items.AddRange(new object[] {
            "ก.ย่อยผลผลิตวิทย์เทคโน  /  11610101100001",
            "ก.ย่อยผลผลิตวิทย์สุขภาพ  /  11610101100002",
            "ก.ย่อยผลผลิตศึกษาสังคม  /  11610101100003",
            "ก.ย่อยผลผลิตวิจัยถ่ายทอด  /  11610101100004",
            "ก.ย่อยผลผลิตบริการวิชาการ  /  11610101100005",
            "ก.สนับสนุนงานบริหารทั่วไป  /  11610101700000",
            "กิจกรรมค่าตอบแทนหัวหน้าภา  /  11630101200000",
            "ก.กิจการนโยบาย สผค.  /  11990101100000",
            "คก.จัดทำผังแม่บทเบื้องต้น  /  15410101300010",
            "ผลักดัน สนง.เกษตร  /  15410101300031",
            "คก.ประสานงานนโยบายสุขภาพ  /  15710101310003",
            "คก.OFOC  /  15710101310004",
            "สายธารน้ำใจน้องพี่สีชมพู  /  15710101310023",
            "คก.ก่อสร้างศูนย์สัตว์ฯ  /  15710101510012",
            "คก.ก่อสร้างอาคารอเนกฯ  /  15710101510014",
            "การพัฒนาระบบการบริหารจัดก  /  15710101710048",
            "คก.ศูนย์บริการสุขภาพ สบง.  /  15710101990001",
            "ก.ย่อยผลผลิตวิทย์เทคโน  /  11610103100001",
            "ก.ย่อยผลผลิตวิทย์สุขภาพ  /  11610103100002",
            "ก.ย่อยผลผลิตศึกษาสังคม  /  11610103100003",
            "ก.ย่อยผลผลิตวิจัยถ่ายทอด  /  11610103100004",
            "ก.ย่อยผลผลิตบริการวิชาการ  /  11610103100005",
            "ก.สนับสนุนงานบริหารบุคคล  /  11610103200000",
            "ก.ย่อยสมทบประกันสังคม สบม  /  11610103200001",
            "ก.ย่อยสมทบสำรองชีพ สบม  /  11610103200002",
            "ก.ย่อยอน.สาธิตฯประถม สบม  /  11610103200003",
            "ก.ย่อยอน.สาธิตฯ มัธยม สบม  /  11610103200004",
            "ก.ย่อยอน.ค่าเข็มทองคำ สบม  /  11610103200005",
            "ก.ย่อยบำเหน็จลจ.นอกฯ สบม  /  11610103200006",
            "ก.ย่อยอน.ศึกษาบุตร สบม  /  11610103200007",
            "ก.ย่อยอน.พัฒนาสุขภาพ สบม  /  11610103200008",
            "ก.ย่อยอน.บำรุงศึกษา สบม  /  11610103200009",
            "ก.ย่อยอน.รักษาพยาบาล สบม  /  11610103200010",
            "ก.ย่อยอน.ตรวจสุขภาพ สบม  /  11610103200011",
            "ก.ย่อยรักษาอุบัติเหตุ สบม  /  11610103200012",
            "ก.อุดหนุนประกันสุขภาพ พนม  /  11610103200013",
            "ก.บำเหน็จชดเชย พนม.  /  11610103200014",
            "ก.เงินสมทบ กบข เปลี่ยน  /  11610103200015",
            "ก.ย่อยเงินชดเชยวันลาพัก  /  11610103200016",
            "ก.ย่อยสวัสดิการศพ  /  11610103200017",
            "เงินสนับสนุนบำเหน็จชดเชย  /  11610103200018",
            "ก.ย่อยบำเหน็จชดเชย พนม รด  /  11610103200019",
            "ก.การพัฒนา วชก.อาจารย์  /  11610103200020",
            "ก.ย่อยหอพักบุคลากร  /  11610103200021",
            "ก.ส่งเสริมการออกกำลังกายฯ  /  11610103200022",
            "ก.สนับสนุนงานบริหารทั่วไป  /  11610103700000",
            "ก.เงินอุดหนุนภาควิชา  /  11630103200000",
            "ก.ย่อยค่าใช้จ่ายบุคลากร  /  12110103100001",
            "ก.ย่อย อน.ค่าใช้จ่ายบุคลา  /  12110103100002",
            "คก.พัฒนาระบบนิติการ  /  15710103310005",
            "คก.พัฒนาบุคลากรทุกระดับ  /  15710103310006",
            "คก.พัฒนาสวัสดิการ  /  15710103310007",
            "โครงการจุฬาฯพอเพียง  /  15710103310021",
            "คก.หอเฉลิมพระเกียรติ  /  15710103310022",
            "ระบบสมรรถนะการบริหารบุคคล  /  15710103710001",
            "พัฒนาระบบทดสอบแบบออนไลน์  /  15710103710002",
            "ประเมินค่างาน&การวิเคราะห  /  15710103710003",
            "ปลูกฝังค่านิยมหลัก  /  15710103710004",
            "พัฒนาระบบประเมินผล  /  15710103710005",
            "ขยายการประเมินค่างาน  /  15710103710063",
            "ปลูกฝังค่านิยมหลักและวัฒน  /  15710103710064",
            "ระบบเส้นทางความก้าวหน้า  /  15710103710078",
            "E-Payroll Slip  /  15710103710079",
            "คก.จุฬาสง่างามEpisode 2  /  15710103710080",
            "คก.ยกเครื่องเรื่อง HR  /  15710103710088",
            "คก.KON-DEE-CU  /  15710103710089",
            "คก.การจัดการความรู้ (KM)  /  15710103710090",
            "พัฒนาระบบโครงสร้างเงินเดื  /  15710103710102",
            "พัฒนาระบบฐานข้อมูล CU-HR  /  15710103710104",
            "โครงการ HR Speed  /  15710103710153",
            "โครงการ Employee Champio  /  15710103710154",
            "โครงการ Employee Engageme  /  15710103710155",
            "โครงการ CU Aspire  /  15710103710156",
            "คก.อบรมพัฒนาบุคลากร สบม  /  15710103990001",
            "คก.งานฉลองครบ 90 ปี สบม  /  15710103990002",
            "ก.สนับสนุนงานบริหารกายภาพ  /  11610104300000",
            "คก.ฐานข้อมูลกายภาพ  /  15710104310008",
            "คก.พัฒนาบริหารกายภาพ  /  15710104310009",
            "คก.กิจการยานพาหนะ  /  15710104310020",
            "ตกแต่งภายในหอนิทรรศก  /  15710104510001",
            "ตกแต่งภายในอ.เคมี 1  /  15710104510002",
            "ปป.ภูมิ.หน้าหอสมุด2  /  15710104510003",
            "ปป.ภูมิทัศน์แนวแกน  /  15710104510004",
            "ปป.ภูมิทัศน์อนุสาวรี  /  15710104510005",
            "ปป.ภูมิทัศวิทสุขภาพ3  /  15710104510006",
            "ปป.ร.ระบายน้ำหอนิสิต  /  15710104510007",
            "ปป.ภูมิ.ทิศใต้ส.กีฬา  /  15710104510008",
            "ปป.ภูมิ.ข้างหอประชุม  /  15710104510009",
            "ปป.หอประชุมจุฬาฯ  /  15710104510010",
            "คก.ปป.อาคารจุลจักรพงษ์  /  15710104510011",
            "คก.ก่อสร้างศูนย์สัตว์ฯ  /  15710104510012",
            "คก.สร้างอาคารรวม  /  15710104510013",
            "คก.ปป.อาคารวิจัยเพิ่มเติม  /  15710104510015",
            "คก.พัฒนาพื้นที่จุฬาฯ สระบ  /  15710104510016",
            "คก.ก่อสร้างอาคารสหสาขา  /  15710104510017",
            "คก.ก่อสร้างศูนย์กีฬา  /  15710104510018",
            "คก.ก่อสร้างอาคารจุฬานิวาส  /  15710104510019",
            "คก.อาคารจุฬานิเวศน์  /  15710104510020",
            "คก.สร้างหอพักนิสิตนานาชาต  /  15710104510021",
            "คก.ปป.อาคารประหยัดพลังงาน  /  15710104510023",
            "คก.ปป.ใช้พลังงานอาคารสูง  /  15710104510024",
            "ปรับปรุงระบบจ่ายไฟฟ้าแรงส  /  15710104510025",
            "คก.ปป.พื้นที่อาคารวิทยพัฒ  /  15710104510027",
            "คก.ทำถนน พท.จุฬาฯสระบุรี  /  15710104510028",
            "คก.สร้างทางเดินมีหลังคา  /  15710104510029",
            "ปป.ศูนย์บริการวิทย์เพิ่ม  /  15710104510031",
            "คก.เปลี่ยนสายไฟRMU  /  15710104510036",
            "ปรับปรุงระบบระบายน้ำพื้นท  /  15710104510037",
            "คก.ก่อสร้างอาคารขยะ  /  15710104510038",
            "คก.ปป.ภูมิทัศน์เรือนไม้พั  /  15710104510039",
            "คก.ปป.ภูมิทัศน์จามจุรี 8  /  15710104510040",
            "คก.ปป.ภูมิทัศน์ศ.พระเกี้ย  /  15710104510041",
            "คก.ติดตั้งระบบเสียงประกาศ  /  15710104510042",
            "คก.กส.อาคาร60ปีรัฐศาสตร์  /  15710104510044",
            "ก่อสร้างอาคารเอนกประสงค์ร  /  15710104510045",
            "ปป.ภูมิทัศน์รอบจุฬานิวาส  /  15710104510046",
            "รื้อจุฬานิวาส3-4&ปป.ภูมิฯ  /  15710104510047",
            "อาคารพัฒนาการเรียนรู  /  15710104510048",
            "สบทบสร้างศูนย์สัตว์ฯ  /  15710104510050",
            "คก.อาหารปลอดภัย  /  15710104710006",
            "คก.ปรับปรุงผังแม่บท  /  15710104710007",
            "คก.วิจัยระบบระบายน้ำ  /  15710104710008",
            "การบริหารจัดการทรัพยากรกา  /  15710104710009",
            "การตรวจสอบอาคาร  /  15710104710010",
            "คก.พัฒนาระบบต้นแบบ  /  15710104710011",
            "คก.3R+1  /  15710104710012",
            "คก.จักรยาน  /  15710104710013",
            "จุฬารักษ์โลก  /  15710104710014",
            "คก.นิสิตสีเขียว  /  15710104710015",
            "การประกันภัยอาคารสถานที่ใ  /  15710104710016",
            "ปรับปรุงอาคารเพื่อผู้พิกา  /  15710104710042",
            "ก่อสร้างศูนย์บริการกลาง  /  15710104710043",
            "ตกแต่งภายในพื้นที่สหสาขา  /  15710104710053",
            "ปรับเพิ่มเติมอาคารจอด 3  /  15710104710054",
            "ปรับปรุงระบบระบายน้ำ  /  15710104710055",
            "ก่อสร้างอาคารปฏิบัติการรว  /  15710104710056",
            "ปรับปรุงศาลาพระเกี้ยว  /  15710104710057",
            "ปรับปรุงระบบหมุนเวียนน้ำ  /  15710104710058",
            "ปรับปรุงอาคารวิทยนิเวศน์  /  15710104710060",
            "ปรับปรุงภูมิทัศน์ลานจอดรถ  /  15710104710061",
            "คก.ปป.ภูมิฯหอสระบุรี  /  15710104710072",
            "คก.ก่อสร้างจุฬานิเวศน์ใหม  /  15710104710074",
            "ปรับปรุงภูมิทัศน์อาคารยาน  /  15710104710076",
            "ติดตั้งเครื่องวัดไฟฟ้าแรง  /  15710104710083",
            "คก.ปป.ภูมิทัศน์หอประชุม  /  15710104710084",
            "รื้นถอนอาคารจุฬานิเวศน์1  /  15710104710085",
            "ปรับปรุงระบบระบายน้ำตะวัน  /  15710104710095",
            "ปรับปรุงอาคารมหาจุฬาฯและว  /  15710104710096",
            "ก่อสร้างถังเก็บน้ำจุฬาฯสร  /  15710104710097",
            "ปรับปรุงภูมิทัศน์หลังธรรม  /  15710104710098",
            "โครงการเดินรถ สกภ  /  15710104710103",
            "คก.อาคารปฏิบัติการวิจัย  /  15710104710114",
            "คก.ปรับปรุงระบบระบายน้ำพื  /  15710104710117",
            "คก.ติดตั้งลิฟท์อาคารจามจุ  /  15710104710118",
            "คก.ปรับปรุงระบบปรับอากาศ  /  15710104710119",
            "คก.จัดการพลังงาน อาคารจาม  /  15710104710120",
            "คก.สาธารณูปโภควิจัยไพรเมท  /  15710104710121",
            "ปรับปรุงพื้นที่ภายในอาคาร  /  15710104710144",
            "อาชีวอนามัยสิ่งแวดล้อมและ  /  15710104710145",
            "ปรับปรุงอาคารตามกฎหมาย ว่  /  15710104710146",
            "โรงอาหารอิ่ม อร่อย สะอาด  /  15710104710147",
            "การวางแผนและจัดการพื้นที่  /  15710104710148",
            "การจัดการพลังงาน  /  15710104710149",
            "การจัดการขยะและของเสีย  /  15710104710150",
            "การจัดการทรัพยากรน้ำ  /  15710104710151",
            "การจัดการระบบการสัญจร  /  15710104710152",
            "คก.ศ.บริการวิทสุขภาพ สกภ.  /  15710104990001",
            "คก.สร้างอ.วิจัยจุฬา สกภ.  /  15710104990002",
            "คก.หอนิทรรศการ เคมี3 สกภ.  /  15710104990003",
            "คก.ปรับปรุงชั้น6จาม9 สกภ.  /  15710104990004",
            "ตกแต่ง+ครุภัณฑ์ จาม9  /  15710104990005",
            "คก.ติดวงจรปิดจาม 9 สกภ.  /  15710104990006",
            "คก.ปป.ภูมิทัศน์อ.มหาธีรฯ  /  15710104990007",
            "คก.ติดเติมอากาศ/พืช สกภ.  /  15710104990008",
            "คก.ปป.ภูมิทัศสถ.บัน 2สกภ.  /  15710104990009",
            "ก.นิสิตเข้าศึกษาจุฬา-ชนบท  /  11130105910000",
            "ก.ย่อยสมัครสอบฯ จุฬาชนบท  /  11130105910001",
            "ก.ย่อยตรวจสภาพฯ จุฬาชนบท  /  11130105910002",
            "ก.ย่อยสัมภาษณ์ จุฬาชนบท  /  11130105910003",
            "ก.ย่อยอบรมนิสิต จุฬาชนบท  /  11130105910004",
            "ก.ย่อยประชุมนิสิตจุฬาชนบท  /  11130105910005",
            "ก.ย่อยจัดกิจกรรมฯจุฬาชนบท  /  11130105910006",
            "ก.ย่อยทุนการศึกษาจุฬาชนบท  /  11130105910007",
            "ก.ย่อยธุรก/บุคคล จุฬาชนบท  /  11130105910008",
            "ก.สส.งานบริหารทั่วไป  /  11610106210000",
            "กิจกรรมเครือข่ายการเรียนร  /  11630106210000",
            "คก.นวัตกรรมการศึกษา  /  15410106300023",
            "โครงการจุฬาฯสระบุรี  /  15410106300028",
            "คก.ร่วมสัตวะ-ราชมงคล  /  15410106990001",
            "การผลิตน้ำเชื้อสุกรและผสม  /  15420106110001",
            "สร้างศักยภาพเลี้ยงโคพื้นเ  /  15420106110002",
            "ปัญหาเชื้อโรคอาหารเป็นพิษ  /  15420106110003",
            "ผลิตแพะพันธุ์นมในน่าน  /  15420106110004",
            "ก.นิสิตและการพัฒนานิสิต  /  11130108100000",
            "ก.ย่อยพัฒนาบุคลิกภาพ นสส.  /  11130108100001",
            "ก.ย่อยพัฒนาอังกฤษ นสส.  /  11130108100002",
            "ก.ย่อยศึกษาวิชาทหาร นสส.  /  11130108100003",
            "ก.ย่อยระบบทะเบียนนิสิต  /  11130108100004",
            "ก.ย่อยใบรับกิจกรรม นสส.  /  11130108100005",
            "ก.ย่อยรางวัลอ.ด้านนิสิต  /  11130108100006",
            "ก.ย่อยภูมิคุ้มกันนิสิต  /  11130108100007",
            "ก.ย่อยประกันคุณภาพ นสส.  /  11130108100008",
            "ก.ย่อยทะเบียนกิจกรรม นสส.  /  11130108100009",
            "ก.ย่อยพัฒนาบุคลิกภาพนิสิต  /  11130108100010",
            "ก.ย่อยระบบทะเบียนกิจกรรม  /  11130108100011",
            "ก.ย่อยพัฒนาอาจารย์บุคลากร  /  11130108100012",
            "ก.ทุนอุดหนุนการศึกษา  /  11130108200000",
            "ก.ย่อยทุนนิสิตขาดแคลน  /  11130108200001",
            "ก.ย่อยรางวัลเรียนดีฯ สบน.  /  11130108200002",
            "ก.ย่อยเงินทุนภูมิพล  /  11130108200003",
            "ก.ย่อยจ้างนิสิตทำงานพิเศษ  /  11130108200004",
            "ก.ย่อยทุนนิสิต คก.พิเศษ  /  11130108200005",
            "ก.ย่อยพิธีมอบทุนการศึกษา  /  11130108200006",
            "ก.เสริมสร้างนิสิตพิการ  /  11130108200007",
            "ก.ย่อยการศึกษาและบริการ  /  11130108200008",
            "ก.ย่อยทุนการศึกษารายปี  /  11130108200009",
            "ก.แนะแนวการศึกษา/จัดหางาน  /  11130108300000",
            "ก.ย่อยให้การปรึกษานิสิต  /  11130108300001",
            "ก.ย่อยแนะแนวอาชีพศึกษาต่อ  /  11130108300002",
            "ก.ย่อยแนะแนวการศึกษาต่อ  /  11130108300003",
            "ก.ย่อยเพื่อนช่วยเพื่อน  /  11130108300004",
            "ก.ย่อยอบรมทักษะการปรึกษาฯ  /  11130108300005",
            "ก.ย่อยทดสอบทางจิตวิทยา  /  11130108300006",
            "ก.ย่อยปฐมนิเทศนิสิตใหม่  /  11130108300007",
            "ก.ย่อยแนะแนวการศึกษา  /  11130108300008",
            "ก.ย่อยแนะแนวและจัดหางาน  /  11130108300009",
            "ก.สวัสดิการหอพัก  /  11130108400000",
            "ก.ย่อยอาคารสถานที่ นสส.  /  11130108400001",
            "ก.ย่อยรักษาปลอดภัย นสส.  /  11130108400002",
            "ก.ย่อยจัดระบบนิสิตหอพัก  /  11130108400003",
            "ก..ย่อยพัฒนานิสิตหอพัก  /  11130108400004",
            "ก.ย่อยจัดการหอพักศึกษิตฯ  /  11130108400005",
            "ก.งานบริหารจัดการหอพัก  /  11130108400006",
            "ก.งานทะเบียนนิสิตหอพัก  /  11130108400007",
            "ก.งานส่งเสริมการเรียนรู้  /  11130108400008",
            "ก.สวัสดิการอนามัย  /  11130108500000",
            "ก.ย่อยตรวจรักษาโรค นสส.  /  11130108500001",
            "ก.ย่อยบริการทันตกรรม นสส.  /  11130108500002",
            "ก.ย่อยกายภาพบำบัด นสส.  /  11130108500003",
            "ก.ย่อยงานอนามัย นสส.  /  11130108500004",
            "ก.ย่อยศ.สุขภาพจุฬาฯ นสส.  /  11130108500005",
            "ก.ย่อยบุคคลศ.สุขภาพจุฬาฯ  /  11130108500006",
            "ก.ประกันอุบัติเหตุนิสิต  /  11130108600000",
            "ก.ย่อยประกันอุบัติเหตุ  /  11130108600001",
            "ก.ส่งเสริมจัดกิจกรรมนิสิต  /  11130108700000",
            "ก.ย่อยกิจกรรมสโมสรนิสิต  /  11130108700001",
            "ก.ย่อยกิจกรรมศิลปวัฒนธรรม  /  11130108700002",
            "ก.ย่อยสังคม/บำเพ็ญประโยชน  /  11130108700003",
            "ก.ย่อยส่งเสริมกิจกรรมกีฬา  /  11130108700004",
            "ก.ย่อยกิจกรรมทางวิชาการ  /  11130108700005",
            "ก.ย่อยกิจกรรมนานาชาติ  /  11130108700006",
            "ก.ย่อยโต้วาทีนานาชาติ  /  11130108700007",
            "ก.ย่อยกิจกรรมระดับบัณฑิตฯ  /  11130108700008",
            "ก.ย่อยถนนคนกิจกรรม  /  11130108700009",
            "ก.ย่อยบูรณาการกิจกรรม  /  11130108700010",
            "ก.ย่อยพัฒนาบุคคลกิจนิสิต  /  11130108700011",
            "ก.ย่อย E-Stusact  /  11130108700012",
            "ก.ย่อยส่งเสริมกิจกรรมนิสิ  /  11130108700013",
            "ก.ย่อยส่งเสริมวินัย  /  11130108700014",
            "ก.ย่อยพัฒนาสุขภาวะนิสิต  /  11130108700015",
            "ก.ย่อยกิจกรรมนานาชาติ  /  11130108700016",
            "ก.เสริมวินัยคุณธรรมฯนิสิต  /  11130108800000",
            "ก.ย่อยส่งเสริมวินัยนิสิต  /  11130108800001",
            "ก.ย่อยรณรงค์แต่งกายนิสิต  /  11130108800002",
            "ก.ย่อยคุณธรรมนิสิต  /  11130108800003",
            "ก.ย่อยปฐมนิเทศผู้นำนิสิต  /  11130108800004",
            "ก.ย่อยพัฒนาศักยภาพนิสิต  /  11130108800005",
            "ก.ย่อยยกย่องอาจารย์/นิสิต  /  11130108800006",
            "ก.ย่อยพัฒนาศักยภาพนิสิต  /  11130108800007",
            "ก.ส่งเสริมนิสิตคุณลักษณะ  /  11130108920000",
            "ก.ย่อยพัฒนากีฬาชาติ  /  11130108920001",
            "ก.ย่อยโครงการศิลปะดีเด่น  /  11130108920002",
            "ก.การพัฒนากีฬาฟุตบอล  /  11130108920003",
            "ก.ย่อยโครงการพิเศษ  /  11130108920004",
            "ก.สนับสนุนงานกิจการนิสิต  /  11610108400000",
            "ก.ย่อยงานธุรการ/บุคคล  /  11610108400001",
            "ก.ย่อยบุคคลกิจกรมส่งเสริม  /  11610108400002",
            "ก.ย่อยปชส.และฐานฯนิสิต  /  11610108400003",
            "ก.ย่อยบริหารจัดการสำนัก  /  11610108400004",
            "ก.ย่อยพัฒนาอาจารย์  /  11610108400005",
            "ก.ย่อยสารสนเทศ  /  11610108400006",
            "ทุนอุดหนุนการศึกษา  /  15410108300026",
            "พัฒนากีฬาจุฬาฯ  /  15410108300027",
            "พัฒนาสุขภาวะนิสิต  /  15410108300034",
            "พัฒนาดนตรี  /  15410108300035",
            "สร้างจิตอาสา  /  15410108300036",
            "ทุนการศึกษานิสิต  /  15410108300037",
            "จัดตั้ง international stu  /  15410108710123",
            "การพัฒนารูปแบบการวัดและปร  /  15410108710124",
            "การเชื่อมโยงกิจกรรมนิสิตก  /  15410108710125",
            "เสริมสร้างการเชื่อมโยงกับ  /  15410108710126",
            "พัฒนาธุรกิจต้นแบบสู่การเป  /  15410108710127",
            "คก.ส่งเสริมการกีฬา  /  15410108710170",
            "คก.สร้างเสริมสำนึกสาธารณะ  /  15410108710171",
            "คก.การประเมินผลนิสิตรายบุ  /  15410108710172",
            "ก.เลขานุการบริหาร  /  11630109140000",
            "ก.ตรวจสอบภายใน  /  11630110130000",
            "ก.วิรัชกิจ  /  11630112110000",
            "คก.พัฒนาสนง.วิรัชกิจ  /  15410112300003",
            "ร่วมกิจกรรมวิชาชีพนานาชาต  /  15410112710031",
            "ประชาสัมพันธ์จุฬาในนานาชา  /  15410112710032",
            "Chula Global Ambassadors  /  15410112710137",
            "การจัดนิทรรศการการศึกษาแ  /  15410112710138",
            "ก.เทคโนโลยีสารสนเทศ  /  11620113100000",
            "ก.ย่อยเครือข่ายคอมพ์ สบท.  /  11620113100001",
            "ก.ย่อยเทคโนฯสารสนเทศ สบท.  /  11620113100002",
            "ก.ย่อยศูนย์เรียนรู้ สบท.  /  11620113100003",
            "ก.ย่อยงานธุรการ สบท.  /  11620113100004",
            "ก.ย่อย คก.ยุทธศาสตร์ สบท.  /  11620113100005",
            "พัฒนาการเรียน/สอนไกล สบท.  /  11620113100006",
            "ก.สารสนเทศการบริหาร สบท.  /  11620113100007",
            "การเรียนการสอนทางไกล  /  15410113300022",
            "ยกระดับธรรมาภิบาลด้านไอที  /  15410113710143",
            "ก.ประชาสัมพันธ์  /  11630114120000",
            "งานสื่อสารนานาชาติ  /  11630114120001",
            "บริการข่าวสาร แบ่งปันความ  /  15410114710133",
            "ก.จัดการอาคาร  /  11630116180000",
            "ก.นิสิตเก่าสัมพันธ์  /  11630117150000",
            "ก.การเรียน/สอนศึกษาทั่วไป  /  11110131200000",
            "ก.ย่อยเรียนสอน ศษ.ทั่วไป  /  11110131200001",
            "ก.ย่อยหอประชุม ศษ.ทั่วไป  /  11110131200002",
            "ก.ย่อยผช.สอน ศษ.ทั่วไป  /  11110131200003",
            "ก.ย่อยในหลักสูต ศษ.ทั่วไป  /  11110131200004",
            "ก.ย่อยทดสอบไทยฯ ศษ.ทั่วไป  /  11110131200005",
            "ก.ย่อยประชาสัมฯ ศษ.ทั่วไป  /  11110131200006",
            "ก.ย่อยพัฒนาสหฯ ศษ.ทั่วไป  /  11110131200007",
            "ก.ย่อยฐานข้อมูล ศษ.ทั่วไป  /  11110131200008",
            "ก.ย่อยปก.คุณภาพ ศษ.ทั่วไป  /  11110131200009",
            "ก.ย่อยปรับสูตร ศษ.ทั่วไป  /  11110131200010",
            "ก.ย่อยรายงานปี ศษ.ทั่วไป  /  11110131200011",
            "ก.ย่อยเครือข่าย ศษ.ทั่วไป  /  11110131200012",
            "ก.ย่อยเสริมไอที ศษ.ทั่วไป  /  11110131200013",
            "ก.ย่อยสัมมนาอจ.ศษ.ทั่วไป  /  11110131200014",
            "ก.ย่อยเสริมหลักสูตร ศษ.ทป  /  11110131200015",
            "ก.ย่อยธุร/บุคคล ศษ.ทั่วไป  /  11110131200016",
            "ก.ศูนย์ยุโรปศึกษา สนม.  /  11630137270000",
            "ก.สภาคณาจารย์  /  11630140170000",
            "ก.สโมสรอาจารย์  /  11630141190000",
            "ก.สนับสนุนงานบริหารทั่วไป  /  11610142700000",
            "ก.สนับสนุนงานบริหารทั่วไป  /  11610154700000",
            "คก.วัดก.ใช้ภาษาไทย  /  15410155110001",
            "คก.วัดก.ใช้ภาษาไทย  /  15410155300001",
            "ขยายโอกาสพัฒนาภ.ไทย  /  15410155300025",
            "พัฒนาแบบทดสอบภาษาไทย  /  15410155710046",
            "พัฒนาทักษะการใช้ภาษาไทย  /  15410155710047",
            "ก.ย่อยงานรักษาความปลอดภัย  /  11630156220000",
            "กิจกรรมศูนย์สุขภาพ  /  11630157230000",
            "กิจกรรมเทคโนโลยีสารสนเทศ  /  11620158100000",
            "ก.ศูนย์รัสเซียศึกษา  /  11630159230000",
            "กิจกรรมสถาบันขงจื่อ  /  11630160240000",
            "ก.ย่อยยุทธ/นวต สบย  /  11120161400001",
            "ก.ย่อยบริหารคุณภาพ สบย  /  11120161400002",
            "ก.ย่อยสารสนเทศ สบย  /  11120161500001",
            "ก.ย่อยผลผลิตวิทย์เทคโน  /  11610161100001",
            "ก.ย่อยผลผลิตวิทย์สุขภาพ  /  11610161100002",
            "ก.ย่อยผลผลิตศึกษาสังคม  /  11610161100003",
            "ก.ย่อยผลผลิตวิจัยถ่ายทอด  /  11610161100004",
            "ก.ย่อยผลผลิตบริการวิชาการ  /  11610161100005",
            "ก.ย่อยยุทธศาสตร์&นวัตกรรม  /  11610161150001",
            "ก.ย่อยสนับสนุนการงบประมาณ  /  11610161150002",
            "ก.ย่อยธุรการยุทธ สบย  /  11610161500004",
            "ก.ย่อยธุรการบริหาร สบย  /  11610161500005",
            "ก.ย่อยธุรการสำนัก สบย  /  11610161500006",
            "ก.สนับสนุนงานบริหารทั่วไป  /  11610161700000",
            "ก.ย่อยธุรการสำนัก สบย  /  11610161700001",
            "ก.ค่าตอบแทนหัวหน้าภาค  /  11630161200000",
            "ก.กิจการนโยบาย สบย.  /  11990161100000",
            "ค.CU-Quality Ways Ep.II  /  15410161300013",
            "โครงการ1 ช่วย9 สบย  /  15410161990003",
            "ก.งานบริหารบุคคล ศ.บริหาร  /  11610162200000",
            "ก.เลขานุการบริหาร  /  11630162140000",
            "ก.สนับสนุนงานบริหารบุคคล  /  11610163200000",
            "ก.บริหารการลงทุน  /  11610164800000",
            "ก.พัฒนาเรียนรู้(ยกเลิก)  /  11620165400000",
            "คก.หน่วยนวัตกรรม(ยกเลิก)  /  15410165300014",
            "ก.บริหารความเสี่ยง  /  11120166410000",
            "ทุนเพิ่มคุณวุฒิ  /  11120170100001",
            "ทุนระยะสั้น  /  11120170100002",
            "ก.พัฒนาวิชาการ  /  11120170200000",
            "รับเข้าศึกษา  /  11120170200001",
            "กิจกรรมวิชาการ  /  11120170200002",
            "วิจัยพัฒนาวิชาการ  /  11120170200003",
            "พัฒนาวิทย์พื้นฐาน  /  11120170200004",
            "พัฒนาหลักสูตร  /  11120170300001",
            "กำกับหลักสูตร  /  11120170300002",
            "สนับสนุนทุนพัฒนานิสิต  /  11130170200001",
            "บริหารธุรการ  /  11610170700001",
            "คก.สนับสนุนทุน ASEAN  /  15410170300004",
            "ทุนปริญญาเอก  /  15410170300005",
            "ทุนดุษฎีภิพรรธน์  /  15410170300008",
            "คก.หน่วยนวัตกรรม(ยกเลิก)  /  15410170300014",
            "สนง.บริหารแผน วชก.  /  15410170300024",
            "นำร่องนักอักษรศาสตร์  /  15410170300038",
            "จุฬาฯ ประชาคมอาเซียน  /  15410170300040",
            "คก.จุฬาศตวรรษที่2  /  15410170300041",
            "การขับเคลื่อนคุณภาพหลักสู  /  15410170710134",
            "ทุนสมทบสำหรับอาจารย์/นักว  /  15410170710135",
            "ก.สนับสนุนงานกิจการวิจัย  /  11610171600000",
            "ก.ย่อยธุรการ สบจ.  /  11610171700001",
            "ส่งเสริมเคลื่อนตัว  /  15410171710049",
            "ศูนย์ให้คำปรึกษาสถิติ  /  15410171710050",
            "คก.เชื่อมโยงงานวิจัยฯ (In  /  15410171710051",
            "งานวิจัยสู่สังคม  /  15410171710052",
            "ก.ศูนย์อินเดียศึกษา  /  11630173250000",
            "ก.ศูนย์อาเซียนศึกษา  /  11630174260000",
            "ก.พัฒนาเรียนรู้ด้วยอิเลคโ  /  11620175400000",
            "คก.หน่วยนวัตกรรมเรียนรู้  /  15410175300014"});
            this.box_district.Location = new System.Drawing.Point(214, 172);
            this.box_district.Name = "box_district";
            this.box_district.Size = new System.Drawing.Size(478, 33);
            this.box_district.TabIndex = 139;
            this.box_district.Text = "ก.สนับสนุนงานบริหารบุคคล  /  11610103200000";
            this.box_district.Click += new System.EventHandler(this.box_district_Click);
            // 
            // txt_name
            // 
            this.txt_name.FormattingEnabled = true;
            this.txt_name.Items.AddRange(new object[] {
            "ผู้ช่วยศาสตราจารย์ ดร.ปมทอง มาลากุล ณ อยุธยา",
            "ศาสตราจารย์ นายแพทย์เกียรติ รักษ์รุ่งธรรม",
            "รองศาสตราจารย์ ดร.บัญชา ชลาภิรมย์",
            "ศาสตราจารย์ นายแพทย์ ดร.นรินทร์ หิรัญสุทธิกุล",
            "รองศาสตราจารย์ ดร.บุญไชย สถิตมั่นในธรรม",
            "ผู้ช่วยศาสตราจารย์ ดร.พิมพ์พนา ปีตธวัชชัย",
            "รองศาสตราจารย์ วันชัย มีชาติ",
            "รองศาสตราจารย์ ดร.วิศณุ ทรัพย์สมพล",
            "ผู้ช่วยศาสตราจารย์ ดร.พิรงรอง รามสูต"});
            this.txt_name.Location = new System.Drawing.Point(312, 256);
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(601, 33);
            this.txt_name.TabIndex = 140;
            this.txt_name.Text = "กรุณาเลือกชื่อรองอธิการบดี";
            this.txt_name.Click += new System.EventHandler(this.txt_name_Click_1);
            // 
            // order_gl
            // 
            this.order_gl.FormattingEnabled = true;
            this.order_gl.Items.AddRange(new object[] {
            "เงินประจำตำแหน่งบริหาร(ไม่มีวาระ)  /  5011010108",
            "เงินเดือนพนักงานมหาวิทยาลัย  /  5011010111",
            "เงินเดือนพนักงานประจำโครงการ  /  5011010112",
            "เงินเดือนข้าราชการ  /  5011010203",
            "ค่าตอบแทนรายเดือนของข้าราชการ  /  5011010204",
            "ค่าตอบแทนรายเดือน 8-8ว  /  5011010205",
            "เงินเดือนลูกจ้างประจำเงินนอกงบประมาณแผ่นดิน  /  5011010303",
            "เงินเดือนลูกจ้างประจำเงินงบประมาณแผ่นดิน  /  5011010401",
            "ค่าตอบแทนรายเดือนของลูกจ้างประจำ  /  5011010402",
            "เงินประจำตำแหน่งทางวิชาการ  /  5011020104",
            "เงินประจำตำแหน่งวิชาชีพเฉพาะ  /  5011020105",
            "เงินประจำตำแหน่งผู้เชี่ยวชาญเฉพาะ  /  5011020106",
            "ค่าตอบแทนรายเดือน 8-8ว  /  5011020112",
            "เงินเพิ่มสำหรับตำแหน่งที่มีเหตุพิเศษ ตำแหน่งนิติกร  /  5011020113",
            "เงินเพิ่มค่าครองชีพข้าราชการ  /  5011030104",
            "เงินเพิ่มค่าครองชีพลูกจ้างประจำ  /  5011030106",
            "เงินเพิ่มค่าครองชีพพนักงานมหาวิทยาลัย  /  5011030111",
            "เงินอุดหนุนสวัสดิการ  /  5011040312",
            "ค่าจ้างชั่วคราว  /  5012020101",
            "เงินประจำตำแหน่งผู้บริหาร  /  5031010202",
            "เงินประจำตำแหน่งพนักงานรักษาความปลอดภัยฯ  /  5031010203",
            "ค่าตอบแทนช่วยราชการ  /  5031020101",
            "ค่าตอบแทนช่วยราชการอื่น  /  5031020201",
            "ค่าตอบแทนการบริหารหลักสูตร  /  5031030001",
            "ค่าตอบแทนพิเศษภาระงานบริหาร  /  5031030201",
            "ค่าตอบแทนการสอน  /  5031040101",
            "ค่าตอบแทนการสอนของอาจารย์ชาวต่างประเทศ  /  5031040102",
            "ค่าตอบแทนการสอนพิเศษ  /  5031040103",
            "ค่าตอบแทนวิทยากร  /  5031040201",
            "ค่าตอบแทนการสอบ  /  5031040301",
            "ค่าตอบแทนกรรมการสอบวิทยานิพนธ์  /  5031040302",
            "ค่าตอบแทนกรรมการสัมภาษณ์/ตรวจสุขภาพ  /  5031040303",
            "ค่าตอบแทนการตรวจและออกข้อสอบ  /  5031040304",
            "ค่าตท.กก.สอบวัดคุณสมบัติ/สอบประมวลความรู้/ค้นคว้า  /  5031040305",
            "ค่าตอบแทนเฉพาะงาน  /  5031050001",
            "ค่าตอบแทนผู้ควบคุมปฏิบัติการ  /  5031050002",
            "ค่าตอบแทนผู้ทรงคุณวุฒิ/ผู้เชี่ยวชาญ  /  5031050003",
            "ค่าตอบแทนกรรมการพิจารณาผลงานวิชาการ  /  5031050004",
            "ค่าตอบแทนนักวิจัย/ผู้ช่วยนักวิจัย  /  5031050005",
            "ค่าตอบแทนคณะกรรมการดำเนินโครงการ  /  5031050007",
            "ค่าตอบแทนการออกแบบงานก่อสร้าง  /  5031050008",
            "ค่าควบคุมงานก่อสร้าง  /  5031050009",
            "ค่าเบี้ยประชุมกรรมการ  /  5031060001",
            "ค่าตอบแทนการปฏิบัติงานนอกเวลา  /  5031070001",
            "ช่วยเหลือค่ารักษา ขรก.&ลจ.ประจำ-คนไข้นอก รพ.รัฐ  /  5031080101",
            "ช่วยเหลือค่ารักษาพยาบาลขรก.&ลจ.ประจำ-คนไข้ในรพ.รัฐ  /  5031080102",
            "ช่วยเหลือค่ารักษา ขรก.&ลจ.ประจำ-คนไข้ใน รพ.เอกชน  /  5031080103",
            "ค่ารักษาผู้ป่วยนอก-รพ.รัฐ-ผู้รับเบี้ยหวัด/บำนาญ  /  5031080104",
            "ช่วยเหลือค่ารักษาข้าราชการบำนาญ-คนไข้ใน รพ.รัฐ  /  5031080105",
            "ค่ารักษาพยาบาล  /  5031080106",
            "ค่ารักษาพยาบาลของนิสิต  /  5031080107",
            "ช่วยเหลือค่ารักษาข้าราชการบำนาญ-คนไข้ใน รพ.เอกชน  /  5031080108",
            "ช่วยเหลือค่ารักษา ลจ.ประจำเงินนอก-คนไข้ใน รพ.เอกชน  /  5031080109",
            "ค่าบำรุงการศึกษาและค่าเล่าเรียน  /  5031080201",
            "ค่าบำรุงการศึกษา&ค่าเล่าเรียนของบุตรข้าราชการบำนาญ  /  5031080202",
            "เงินอุดหนุนการศึกษาบุตร  /  5031080203",
            "ค่าเช่าบ้าน  /  5031089901",
            "เงินสวัสดิการปฎิบัติงานประจำพื้นที่พิเศษ  /  5031089902",
            "ค่าสวัสดิการอื่น ๆ  /  5031089999",
            "เงินบำเหน็จ  /  5031090101",
            "เงินบำเหน็จตกทอด  /  5031090102",
            "เงินบำเหน็จดำรงชีพ  /  5031090103",
            "เงินบำเหน็จลูกจ้างชั่วคราวชาวต่างประเทศ  /  5031090104",
            "เงินบำเหน็จรายเดือน  /  5031090106",
            "เงินบำนาญปกติ  /  5031090201",
            "เงินบำนาญพิเศษ  /  5031090202",
            "เงินช่วยเหลือรายเดือนผู้รับเบี้ยหวัดบำนาญ  /  5031090203",
            "เงินช่วยค่าครองชีพผู้รับเบี้ยหวัดบำนาญ  /  5031090204",
            "เงินช่วยพิเศษกรณีผู้รับบำนาญตาย  /  5031099901",
            "เงินช่วยเหลือพิเศษกรณีเสียชีวิต  /  5031099902",
            "เงินช่วยเหลือตามมาตรการของรัฐบาล  /  5031099903",
            "เงินบำเหน็จบำนาญอื่น  /  5031099999",
            "ค่าตอบแทนพิเศษของข้าราชการ  /  5031110101",
            "ค่าตอบแทนพิเศษของลูกจ้างประจำ  /  5031110103",
            "เงินค่าตอบแทนเต็มขั้นพนักงานมหาวิทยาลัย  /  5031110107",
            "เงินเพิ่มสำหรับตำแหน่งที่มีเหตุพิเศษ(พตส)  /  5031110201",
            "เงินรางวัล  /  5031110301",
            "ค่าตอบแทนเงินรางวัลที่เกี่ยวกับผลงานวิชาการ/วิจัย  /  5031990001",
            "ค่าตอบแทนเหมาจ่าย  /  5031990002",
            "ค่าตอบแทนนิสิตช่วยงาน  /  5031990003",
            "ค่าตอบแทนผู้อุทิศตนเป็นนักวิชาการ  /  5031990004",
            "ค่าตอบแทนพิเศษเบื้องต้นสำหรับคณาจารย์  /  5031990005",
            "ค่าตอบแทนบุคลากรทางการแพทย์  /  5031990006",
            "ค่าตอบแทนอื่น  /  5031990199",
            "ค่าลงทะเบียนไปประชุมสัมมนาและฝึกอบรมในประเทศ  /  5032010101",
            "ค่าเบี้ยเลี้ยงไปประชุมสัมมนาและฝึกอบรมในประเทศ  /  5032010102",
            "ค่าที่พักไปประชุมสัมมนาและฝึกอบรมในประเทศ  /  5032010103",
            "ค่าเบี้ยเลี้ยงที่พักไปประชุมสัมมนาในปท.(เหมาจ่าย)  /  5032010104",
            "ค่าพาหนะไปประชุมสัมมนาและฝึกอบรมในประเทศ  /  5032010105",
            "ค่าใช้จ่ายอื่นในการไปประชุมสัมมนา&ฝึกอบรมในประเทศ  /  5032010106",
            "ค่าใช้จ่ายศึกษาดูงานนอกสถานที่  /  5032010107",
            "ค่าลงทะเบียนไปประชุมสัมมนาและฝึกอบรมต่างประเทศ  /  5032010201",
            "ค่าเบี้ยเลี้ยงไปประชุมสัมมนาและฝึกอบรมต่างประเทศ  /  5032010202",
            "ค่าที่พักไปประชุมสัมมนาและฝึกอบรมต่างประเทศ  /  5032010203",
            "ค่าเบี้ยเลี้ยงที่พักไปประชุมสัมมนาตปท.(เหมาจ่าย)  /  5032010204",
            "ค่าพาหนะไปประชุมสัมมนาและฝึกอบรมต่างประเทศ  /  5032010205",
            "คชจ.อื่นในการไปประชุมสัมมนา&ฝึกอบรมตปท.  /  5032010206",
            "ค่าใช้จ่ายในการจัดประชุมสัมมนาและฝึกอบรมในประเทศ  /  5032010301",
            "ค่าอาหารว่างและเครื่องดื่มในการสัมมนาและฝึกอบรม  /  5032010311",
            "ค่าอาหารว่างและเครื่องดื่มในการจัดประชุม  /  5032010312",
            "ค่าอาหารในการสัมมนาและฝึกอบรม  /  5032010313",
            "ค่าอาหารในการจัดประชุมราชการ  /  5032010314",
            "ค่าใช้จ่ายในการจัดประชุมสัมมนาและฝึกอบรมต่างประเทศ  /  5032010401",
            "ค่าเบี้ยเลี้ยงในการเดินทางปฏิบัติราชการในประเทศ  /  5032020101",
            "ค่าที่พักในการเดินทางปฏิบัติราชการในประเทศ  /  5032020102",
            "ค่าเบี้ยเลี้ยงที่พัก-ปฏิบัติราชการในปท.(เหมาจ่าย)  /  5032020103",
            "ค่าพาหนะในการเดินทางปฏิบัติราชการในประเทศ  /  5032020104",
            "ค่าโดยสารเครื่องบินในเดินทางปฏิบัติราชการในประเทศ  /  5032020105",
            "ค่าใช้จ่ายอื่นในการเดินทางปฏิบัติราชการในประเทศ  /  5032020106",
            "ค่าใช้จ่ายศึกษาดูงานนอกสถานที่  /  5032020107",
            "ค่าเบี้ยเลี้ยงในเดินทางปฏิบัติราชการในต่างประเทศ  /  5032020201",
            "ค่าที่พักในเดินทางปฏิบัติราชการในต่างประเทศ  /  5032020202",
            "ค่าเบี้ยเลี้ยงที่พัก-ปฏิบัติราชการในตปท.(เหมาจ่าย)  /  5032020203",
            "ค่าพาหนะในเดินทางปฏิบัติราชการในต่างประเทศ  /  5032020204",
            "ค่าโดยสารเครื่องบินในเดินทางปฏิบัติราชการในตปท.  /  5032020205",
            "ค่าใช้จ่ายอื่นในเดินทางปฏิบัติราชการในต่างประเทศ  /  5032020206",
            "ค่าเบี้ยเลี้ยงของชาวต่างประเทศ  /  5032030101",
            "ค่าที่พักของชาวต่างประเทศ  /  5032030102",
            "ค่าพาหนะของชาวต่างประเทศ  /  5032030103",
            "ค่าพาหนะ เบี้ยเลี้ยง ที่พักของชาวตปท. (เหมาจ่าย)  /  5032030104",
            "ค่าใช้จ่ายอื่นของชาวต่างประเทศ  /  5032030105",
            "ค่าซ่อมแซมและบำรุงรักษาครุภัณฑ์สำนักงาน  /  5032040101",
            "ค่าซ่อมแซมและบำรุงรักษาครุภัณฑ์การศึกษา  /  5032040102",
            "ค่าซ่อมแซมและบำรุงรักษาครุภัณฑ์ก่อสร้าง  /  5032040103",
            "ค่าซ่อมแซมและบำรุงรักษาครุภัณฑ์การเกษตร  /  5032040104",
            "ค่าซ่อมแซมและบำรุงรักษาครุภัณฑ์โรงงาน  /  5032040105",
            "ค่าซ่อมแซมและบำรุงรักษาครุภัณฑ์ไฟฟ้าและวิทยุ  /  5032040106",
            "ค่าซ่อมแซมและบำรุงรักษาครุภัณฑ์คอมพิวเตอร์  /  5032040107",
            "ค่าซ่อมแซมและบำรุงรักษาครุภัณฑ์โฆษณาและเผยแพร่  /  5032040108",
            "ค่าซ่อมแซม&บำรุงรักษาครุภัณฑ์วิทยาศาสตร์&การแพทย์  /  5032040109",
            "ค่าซ่อมแซมและบำรุงรักษาครุภัณฑ์งานบ้านงานครัว  /  5032040110",
            "ค่าซ่อมแซมและบำรุงรักษาครุภัณฑ์กีฬา  /  5032040111",
            "ค่าซ่อมแซมและบำรุงรักษาครุภัณฑ์คนตรีและนาฏศิลป์  /  5032040112",
            "ค่าซ่อมแซม&บำรุงรักษาครุภัณฑ์ยานพาหนะ&ขนส่งจดทบ.  /  5032040113",
            "ค่าซ่อมแซม&บำรุงรักษาคภ.ยานพาหนะ&ขนส่งไม่จดทบ.  /  5032040114",
            "ค่าซ่อมแซมและบำรุงรักษาครุภัณฑ์อาวุธ  /  5032040115",
            "ค่าซ่อมแซมและบำรุงรักษาครุภัณฑ์สนาม  /  5032040116",
            "ค่าซ่อมแซมและบำรุงรักษาครุภัณฑ์สำรวจ  /  5032040117",
            "ค่าซ่อมแซม&บำรุงรักษาครุภัณฑ์อุปกรณ์ห้องปฎิบัติการ  /  5032040118",
            "ค่าซ่อมแซมและบำรุงรักษาอาคาร  /  5032040201",
            "ค่าซ่อมแซมและบำรุงรักษาระบบสาธารณูปโภคภายในอาคาร  /  5032040301",
            "ค่าซ่อมแซมและบำรุงรักษาระบบสาธารณูปโภคภายนอกอาคาร  /  5032040401",
            "ค่าซ่อมแซมและบำรุงรักษาภูมิสถาปัตยกรรม  /  5032040501",
            "ค่าซ่อมแซมและบำรุงรักษาศิลปวัตถุ  /  5032040601",
            "ค่าซ่อมแซมและบำรุงรักษาสิ่งของหายาก  /  5032040602",
            "ค่าซ่อมแซมและบำรุงรักษาระบบคอมพิวเตอร์  /  5032040701",
            "ค่าซ่อมแซมและบำรุงรักษาฐานข้อมูล  /  5032040702",
            "ค่าซ่อมแซมครุภัณฑ์  /  5032040901",
            "ค่าจ้างเหมาจ่าย  /  5032050001",
            "ค่าบริการทำความสะอาด  /  5032060101",
            "ค่าบริการกำจัดปลวก หนู แมลง  /  5032060102",
            "ค่าบริการเก็บขยะ  /  5032060103",
            "ค่าบริการจัดการตกแต่งสถานที่  /  5032060104",
            "ค่าบริการบำรุงรักษาลิฟท์  /  5032060105",
            "ค่าจ้างบริการความปลอดภัย  /  5032060106",
            "ค่าจ้างเหมาบริการอื่น  /  5032060107",
            "ค่าธรรมเนียมธนาคาร  /  5032070101",
            "ค่าธรรมเนียมฟ้องคดี  /  5032079901",
            "ค่าธรรมเนียมและค่าบำรุงสมาชิก  /  5032079902",
            "ค่าธรรมเนียมสมัครแข่งขันกีฬา  /  5032079903",
            "ค่าธรรมเนียมอื่น  /  5032079904",
            "ค่าธรรมเนียมการจัดการ  /  5032079905",
            "ค่าธรรมเนียมรับฝากทรัพย์สิน  /  5032079906",
            "ค่ารับรอง  /  5032080101",
            "ค่าของที่ระลึก  /  5032080102",
            "ค่าใช้จ่ายในพิธีการ  /  5032080201",
            "ค่าใช้จ่ายพิธีทางศาสนา  /  5032080202",
            "ค่าใช้จ่ายในพิธีการของนิสิต  /  5032080203",
            "ค่าเบี้ยประกันภัยอาคาร  /  5032090001",
            "ค่าเบี้ยประกันภัยทรัพย์สิน  /  5032090002",
            "ค่าเบี้ยประกันภัยยานพาหนะ  /  5032090003",
            "ค่าเบี้ยประกันอุบัติเหตุเดินทาง  /  5032090004",
            "ค่าเบี้ยประกันสุขภาพ  /  5032090005",
            "เงินชดเชยสมาชิก กบข.  /  5032990101",
            "เงินสมทบ กบข.  /  5032990102",
            "สมทบกท.สำรองเลี้ยงชีพพนักงาน&เจ้าหน้าที่รัฐ (กสจ)  /  5032990201",
            "เงินสมทบ - เงินประกันสังคมในส่วนของนายจ้าง  /  5032990301",
            "เงินสมทบ - กองทุนเงินสำรองเลี้ยงชีพ  /  5032990401",
            "ค่าทะเบียนสมาชิกกองทุนเงินสำรองเลี้ยงชีพ  /  5032990402",
            "ค่าอาหารและเครื่องดื่ม  /  5032999901",
            "ค่าใช้จ่ายโฆษณาประชาสัมพันธ์  /  5032999902",
            "ค่าเช่าสถานที่และทรัพย์สิน  /  5032999904",
            "คชจ.บำรุงอาคารสถานที่ทรัพย์สินระหว่างหน่วยงานภายใน  /  5032999905",
            "ค่าเช่าโปรแกรมสำเร็จรูป  /  5032999906",
            "ค่าใช้จ่ายในการแข่งขันกีฬา  /  5032999907",
            "ค่าของขวัญ ของรางวัลและเงินรางวัล  /  5032999908",
            "ค่าขนส่งระหว่างประเทศ  /  5032999909",
            "ค่าตรวจและวิเคราะห์ทางห้องปฎิบัติการ  /  5032999910",
            "ค่าสมัครสอบแบบทดสอบต่างประเทศ  /  5032999911",
            "ค่าใช้จ่ายจัดทำเอกสารประกอบการบรรยาย  /  5032999912",
            "ค่าใช้จ่ายในการจัดทำหนังสือสำคัญ  /  5032999913",
            "ค่าใช้จ่ายในการเดินทางกรรมการ  /  5032999915",
            "ค่าสอบบัญชี  /  5032999916",
            "ค่าภาษีรถยนต์  /  5032999917",
            "ค่าถ่ายเอกสาร  /  5032999918",
            "เงินสนับสนุนค่าใช้จ่ายในการใช้ร่างอาจารย์ใหญ่  /  5032999919",
            "ค่าใช้จ่ายเบ็ดเตล็ด  /  5032999999",
            "ค่าวัสดุสำนักงาน  /  5033000001",
            "ค่าวัสดุการศึกษา  /  5033000002",
            "ค่าวัสดุก่อสร้าง  /  5033000003",
            "ค่าวัสดุการเกษตร  /  5033000004",
            "ค่าวัสดุโรงงาน  /  5033000005",
            "ค่าวัสดุไฟฟ้าและวิทยุ  /  5033000006",
            "ค่าวัสดุคอมพิวเตอร์  /  5033000007",
            "ค่าวัสดุโฆษณาและเผยแพร่  /  5033000008",
            "ค่าวัสดุวิทยาศาสตร์และการแพทย์  /  5033000009",
            "ค่าวัสดุงานบ้านงานครัว  /  5033000010",
            "ค่าวัสดุกีฬา  /  5033000011",
            "ค่าวัสดุดนตรีและนาฏศิลป์  /  5033000012",
            "ค่าวัสดุยานพาหนะและขนส่ง  /  5033000013",
            "ค่าวัสดุอาวุธ  /  5033000014",
            "ค่าวัสดุสนาม  /  5033000015",
            "ค่าวัสดุสำรวจ  /  5033000016",
            "ค่าวัสดุเครื่องแต่งกาย  /  5033000017",
            "ค่าวัสดุเชื้อเพลิงและหล่อลื่น  /  5033000018",
            "ค่าวัสดุเครื่องบริโภค  /  5033000019",
            "ค่าวัสดุคงคลัง (เงินอุดหนุน)  /  5034000001",
            "ค่าไฟฟ้า  /  5041000001",
            "ค่าน้ำประปา  /  5042000001",
            "ค่าไปรษณีย์และโทรเลข  /  5043000001",
            "ค่าโทรศัพท์และโทรสารในประเทศ  /  5044000001",
            "ค่าโทรศัพท์และโทรสารต่างประเทศ  /  5044000002",
            "ค่าบริการด้าน Internet  /  5045000001",
            "ค่าบริการสื่อสารและโทรคมนาคมอื่น  /  5045000003",
            "ค่าเช่าช่องสัญญาณ  /  5045000004",
            "ค่าสาธารณูปโภค ประจำปี 2552  /  5049000000",
            "เงินอุดหนุนสนับสนุนคณะ/สถาบัน/ศูนย์/สำนัก  /  5052010102",
            "เงินอุดหนุนค่าสวัสดิการอื่นๆ  /  5052010103",
            "เงินอุดหนุนคชจ.ในการไปประชุม สัมนา ฝึกอบรมในตปท.  /  5052010105",
            "เงินอุดหนุนค่าธรรมเนียมต่างๆ  /  5052010106",
            "เงินอุดหนุนค่าใช้จ่ายในพิธีการ  /  5052010107",
            "เงินอุดหนุนค่าวัสดุ  /  5052010108",
            "เงินอุดหนุนค่าสาธารณูปโภค  /  5052010109",
            "เงินบำเหน็จชดเชยพนม.หมวดเงินอุดหนุน  /  5052010111",
            "เงินชดเชยวันลาพักผ่อนพนม.หมวดเงินอุดหนุน  /  5052010112",
            "เงินบำเหน็จชดเชยพนม.  /  5052010113",
            "งินบำเหน็จชดเชยพนม.  /  5052010114",
            "เงินชดเชยกรณีให้ออกจากงาน หมวดเงินอุดหนุน  /  5052010115",
            "เงินชดเชยกรณีให้ออกจากงาน  /  5052010116",
            "เงินอุดหนุนภาควิชา  /  5052010301",
            "เงินอุดหนุนการศึกษาของนิสิต  /  5053010001",
            "เงินทุนอุดหนุนการศึกษาผู้ช่วยสอน  /  5053010002",
            "เงินทุนอุดหนุนการทำวิทยานิพนธ์  /  5053010003",
            "เงินทุนอุดหนุนค่าเล่าเรียน/ค่าธรรมเนียมการศึกษา  /  5053010004",
            "เงินทุนเฉลิมพระเกียรติ 72 พรรษา  /  5053010005",
            "เงินทุนอุดหนุนการไปเสนอผลงานวิชาการในประเทศ  /  5053010006",
            "เงินทุนอน.การไปเสนอผลงานวิชาการในตปท. (นิสิตป.เอก)  /  5053010007",
            "รายจ่ายทุนการศึกษา  /  5053010008",
            "เงินทุนดุษฎีบัณฑิตเพื่อพัฒนาศาสตร์  /  5053010009",
            "เงินทุนวิจัยต่างประเทศ  /  5053010010",
            "เงินทุนสำหรับผู้มีความสามารถพิเศษ  /  5053010011",
            "เงินทุนอุดหนุนนิสิตต่างประเทศ  /  5053010012",
            "เงินทุนเอุดหนุนการศึกษาเงินทุนสมเด็จพระเทพฯ  /  5053010013",
            "เงินอุดหนุนการศึกษาของอาจารย์  /  5053020001",
            "เงินอุดหนุนการศึกษาขั้นพื้นฐาน (ร.ร.สาธิตจุฬาฯ)  /  5053030001",
            "เงินอุดหนุนโครงการเรียนฟรี  /  5053030002",
            "เงินอุดหนุนค่าตอบแทนบุคลากรของโครงการวิจัย  /  5054010001",
            "เงินอุดหนุนค่าใช้สอยและวัสดุโครงการวิจัย  /  5054010004",
            "เงินอุดหนุนค่าดำเนินงานวิจัยของมหาวิทยาลัย  /  5054010005",
            "เงินอุดหนุนค่าจ้างบุคลากรของโครงการวิจัย  /  5054010006",
            "เงินอุดหนุนเพื่อสนับสนุนการเผยแพร่ผลงานวิจัย  /  5054020001",
            "เงินอุดหนุนค่าวัสดุวิทยาศาสตร์  /  5055020001",
            "เงินอุดหนุนคณะ&หน่วยงานที่เกี่ยวข้อง(ตั้งสหสาขา)  /  5055020002",
            "เงินอุดหนุนกิจกรรมทางวิชาการ  /  5055020004",
            "เงินอุดหนุนกิจกรรมสโมสรนิสิต  /  5055020005",
            "เงินอุดหนุนเพื่อสนับสนุนกิจกรรมภายในหน่วยงานอื่นๆ  /  5055020006",
            "เงินอุดหนุนพัฒนาวิชาการ  /  5056010001",
            "เงินอน.สมทบกท.ตามพันธกิจจากการให้บริการทางวิชาการ  /  5056010002",
            "เงินอุดหนุนจากรัฐจัดสรรให้หน่วยงาน  /  5059010006",
            "เงินอุดหนุนค่าจ้าง พนง.วิสามัญ  /  5059020001",
            "เงินอุดหนุนค่าตอบแทนบุคลากรของโครงการเฉพาะ  /  5059110001",
            "เงินอุดหนุนค่าดำเนินงานของโครงการเฉพาะ  /  5059110002",
            "เงินอุดหนุนงบลงทุนของโครงการเฉพาะ  /  5059110003",
            "เงินอุดหนุนเงินสมทบ - เงินประกันสังคม  /  5059110004",
            "เงินอุดหนุนค่าเช่าบ้าน  /  5059110007",
            "เงินอุดหนุนค่าตอบแทนของโครงการเฉพาะ  /  5059110008",
            "เงินอุดหนุนค่าใช้สอยของโครงการเฉพาะ  /  5059110009",
            "เงินอุดหนุนค่าวัสดุของโครงการเฉพาะ  /  5059110010",
            "เงินอุดหนุนค่าสาธารณูปโภคของโครงการเฉพาะ  /  5059110011",
            "งบลงทุน (เงินอุดหนุน) ครุภัณฑ์  /  5065000002",
            "ค่าใช้จ่ายงบลงทุน (เงินอุดหนุน) มูลค่าต่ำ  /  5065000003",
            "ค่าใช้จ่ายงบลงทุน (เงินอุดหนุน) สิ่งก่อสร้าง  /  5065000004",
            "ค่าใช้จ่ายงบลงทุน (เงินอุดหนุน) AUC  /  5065000005",
            "จส.ตามงปม.ให้กท./งท.บริหารวิชาการ-ส.ภาษาไทยสิรินธร  /  5101000002",
            "เงิน จส.ตามงปม.ให้กท./งท ทั่วไป-ศูนย์บริการสุขภาพ  /  5107000002",
            "หนี้สูญ  /  5901000001",
            "ค่าภาษีและค่าธรรมเนียมในการออกของ  /  5991000001",
            "ค่าปรับผิดสัญญาจัดซื้อจัดจ้าง  /  5991000002",
            "บัญชีค่าใช้จ่ายเงินช่วยเหลือผู้ประสบภัย  /  5999000001",
            "บัญชีส่วนต่างราคาในใบแจ้งหนี้กับใบสั่งซื้อ  /  5999900001",
            "เงินสำรอง  /  5999900007",
            "พักค่าใช้จ่ายบุคลากร  /  5999900009",
            "บัญชีพักเงินสด  /  5999900011",
            "บัญชีพักค่าใช้จ่ายค้างจ่าย(ไม่ตัดงบประมาณ)  /  5999900012",
            "IC-เงินปันผลจ่าย  /  5999900017",
            "ค่าครุภัณฑ์สำนักงาน  /  ",
            "ค่าครุภัณฑ์ยานพาหนะและขนส่ง  /  ",
            "ค่าครุภัณฑ์การเกษตร  /  ",
            "ค่าครุภัณฑ์ไฟฟ้าและวิทยุ  /  ",
            "ค่าครุภัณฑ์โฆษณาและเผยแพร่  /  ",
            "ค่าครุภัณฑ์วิทยาศาสตร์การแพทย์  /  ",
            "ค่าครุภัณฑ์งานบ้านงานครัว  /  ",
            "ค่าครุภัณฑ์โรงงาน  /  ",
            "ค่าครุภัณฑ์กีฬา  /  ",
            "ค่าครุภัณฑ์สำรวจ  /  ",
            "ค่าครุภัณฑ์อาวุธ  /  ",
            "ค่าครุภัณฑ์ดนตรีและนาฏศิลป์  /  ",
            "ค่าครุภัณฑ์คอมพิวเตอร์  /  "});
            this.order_gl.Location = new System.Drawing.Point(547, 423);
            this.order_gl.Name = "order_gl";
            this.order_gl.Size = new System.Drawing.Size(720, 33);
            this.order_gl.TabIndex = 141;
            this.order_gl.Text = "ประเภทภาระผูกพัน / หมวดทรัพย์สิน";
            this.order_gl.SelectedIndexChanged += new System.EventHandler(this.order_gl_SelectedIndexChanged);
            this.order_gl.Click += new System.EventHandler(this.order_gl_Click);
            // 
            // order_typeofunit
            // 
            this.order_typeofunit.FormattingEnabled = true;
            this.order_typeofunit.Items.AddRange(new object[] {
            "%",
            "%0",
            "หนึ่ง",
            "วัน",
            "mm2/s",
            "cm/s",
            "m/min",
            "ตl",
            "ตf",
            "พิโคฟาเรด",
            "A",
            "กิกะโอห์ม",
            "g/m3",
            "เอเคอร์",
            "kg/dm3",
            "กิโลโมล",
            "ND",
            "เมกะนิวตัน",
            "MOhm",
            "MV",
            "ตA",
            "ถุง",
            "แท่ง",
            "ขวด",
            "Bq/kg",
            "มิลลิฟาเรด",
            "Mol/m3",
            "โมล/ลิตร",
            "nA",
            "cm3/s",
            "นาโนฟาเรด",
            "N/mm2",
            "ลบ.ซม.",
            "แรงเทียน",
            "ลบ.ดม.",
            "เซนติเมตร",
            "ตร.ซม.",
            "cm/h",
            "Case",
            "เซนติลิตร",
            "ซีเมนส์/ม.",
            "t/m3",
            "VA",
            "องศา",
            "เดซิเมตร",
            "ถัง",
            "โหล",
            "ชิ้น",
            "Enzy.Units",
            "Enzyme/ml",
            "F",
            "ฟาเรนไฮต์",
            "ฟุต",
            "ตารางฟุต",
            "ลูกบาศก์ft",
            "กรัม",
            "gai/liter",
            "กรัมทองคำ",
            "เซลเซียส",
            "g/hg",
            "กิกะจูล",
            "g/kg",
            "g/l",
            "US แกลลอน",
            "Gal/Mi(US)",
            "กรัม/โมล",
            "g/m2",
            "Gal/hr US",
            "ตg/m3",
            "รวม",
            "g act.ing.",
            "ชั่วโมง",
            "เฮกตาร์",
            "เฮกโตลิตร",
            "hPa",
            "เฮิรตซ์",
            "นิ้ว",
            "ตารางนิ้ว",
            "ลบ.นิ้ว",
            "J",
            "ปี",
            "J/kg",
            "J/(kg*K)",
            "J/mol",
            "K",
            "kA",
            "กระป๋อง",
            "คาร์ตัน",
            "kBq/kg",
            "กิโลกรัม",
            "kg/m2",
            "kg/kg",
            "kg/mol",
            "kg/s",
            "kg/m3",
            "kg ac.ing.",
            "kHz",
            "กล่อง",
            "กิโลจูล",
            "KJ/kg",
            "KJ/mol",
            "กิโลเมตร",
            "km2",
            "กม./ชม.",
            "m3/m3",
            "K/min",
            "K/s",
            "กิโลโอห์ม",
            "kPa",
            "kt",
            "กิโลโวลต์",
            "kVA",
            "KW",
            "kwh",
            "kai/kg",
            "ลิตร",
            "ลิตร/นาที",
            "US ปอนด์",
            "หน่วย",
            "l/100 km",
            "l/mol.s",
            "Liter/hr",
            "เมตร",
            "%(มวล)",
            "%0(มวล)",
            "ม./วินาที",
            "ตารางเมตร",
            "1/M2",
            "ตร.ม./ว.",
            "ลบ.เมตร",
            "ลบ.ม./ว.",
            "mA",
            "มิลลิบาร์",
            "m.bar/s",
            "เมกะจูล",
            "มิลลิกรัม",
            "mg/cm2",
            "mg/g",
            "mg/kg",
            "mg/l",
            "mg/m3",
            "เมกะวัตต์",
            "MHz",
            "ไมล์",
            "ตารางไมล์",
            "ไมโครเมตร",
            "min.",
            "ตs",
            "มิลลิจูล",
            "มิลลิลิตร",
            "ml/m3",
            "ml act.in.",
            "mm",
            "mm2",
            "mm/a",
            "mmol/g",
            "mm/h",
            "mmol/kg",
            "มิลลิโมล",
            "ลบ.มม.",
            "mm/s",
            "mN/m",
            "mol/kg",
            "โมล",
            "เดือน",
            "เมกะปาสคาล",
            "ppb(มวล)",
            "Mi/Gal(US)",
            "ppm(mass)",
            "mPa.s",
            "ppt(m)",
            "m.Pa/s",
            "m3/h",
            "ms",
            "m/s2",
            "มิลลิเทสลา",
            "m/h",
            "มิลลิโวลต์",
            "MVA",
            "มิลลิวัตต์",
            "MWh",
            "N",
            "นาโนเมตร",
            "N/m",
            "นาโนวินาที",
            "Ohm*cm",
            "โอห์ม",
            "Ohm*m",
            "ออนซ์",
            "Fld.oz US",
            "จุด",
            "Pa",
            "คู่",
            "แพค",
            "แพลเลต",
            "Pascal sec",
            "Grp Share",
            "1/min",
            "ppb",
            "ppm",
            "ppt",
            "บุคคล",
            "พิโควินาที",
            "ไพนท์ US l",
            "ควอรท US l",
            "g/cm3",
            "ม้วน",
            "s",
            "ชิ้น",
            "ชั่วโมง",
            "วัน",
            "1/cm3",
            "D",
            "หลักพัน",
            "1/m3",
            "ตัน",
            "US ตัน",
            "",
            "ตg/l",
            "V",
            "%(ปริมาตร)",
            "%o(V)",
            "ตS/cm",
            "Millimol/l",
            "ค่า",
            "ppb(V)",
            "ppm(V)",
            "ppt(V)",
            "W",
            "สัปดาห์",
            "W/(m*K)",
            "kg/s*m2",
            "หลา",
            "ตารางหลา",
            "ลบ.หลา",
            "License",
            "กรง",
            "กรอบ",
            "กระถาง",
            "กระบอก",
            "กระปุก",
            "กระสอบ",
            "กล้อง",
            "กลุ่ม",
            "ก้อน",
            "กิโลตัน",
            "กุรุส",
            "แกลลอน",
            "ขด",
            "ข้าง",
            "ครั้ง",
            "คัน",
            "คิว",
            "เครื่อง",
            "โคม",
            "งวด",
            "งาน",
            "จอ",
            "ฉบับ",
            "ชั้น",
            "ชุด",
            "ซอง",
            "ดวง",
            "ดอก",
            "ด้าม",
            "ต้น",
            "ตลับ",
            "ตัว",
            "ตู้",
            "ถ้วย",
            "แถว",
            "ท่อ",
            "ท่อน",
            "เที่ยว",
            "แท่ง",
            "แท่น",
            "นัด",
            "บาน",
            "ใบ",
            "ปี๊บ",
            "ปื้น",
            "ผืน",
            "แผง",
            "แผ่น",
            "ฝา",
            "แพ็ค",
            "แฟ้ม",
            "ภาพ/รูป",
            "มัด",
            "เม็ด",
            "ระบบ",
            "รายการ",
            "รีม",
            "เรือน",
            "ล้อ",
            "ลัง",
            "ลูก",
            "เล่ม",
            "เลา",
            "วง",
            "เส้น",
            "หน่วย",
            "หลอด",
            "หลัง",
            "ห่อ",
            "หีบ",
            "องค์",
            "อัน",
            "ไวแอล",
            "แอมพูล",
            "แนบูล",
            "คอก",
            "โครงการ",
            "ห้อง",
            "โถ",
            "เตา",
            "เตียง",
            "คอลัมน์",
            "ที่",
            "หัว",
            "พระรูป",
            "ราง",
            "ลำ",
            "โปรแกรม",
            "กล่อง12",
            "ลัง72",
            "กล่อง500",
            "หีบ20",
            "หีบ24",
            "พวง",
            "กล่อง6",
            "คู่สาย",
            "จาน",
            "บอร์ด",
            "คาบ",
            "มอดูล",
            "เรื่อง",
            "แคปซูล",
            "กล่อง8",
            "สัดส่วน",
            "บุคคล",
            "กล่อง",
            "ลัง",
            "หีบ"});
            this.order_typeofunit.Location = new System.Drawing.Point(110, 515);
            this.order_typeofunit.Name = "order_typeofunit";
            this.order_typeofunit.Size = new System.Drawing.Size(310, 33);
            this.order_typeofunit.TabIndex = 142;
            this.order_typeofunit.Text = "กรุณากรอกหน่วยนับ";
            this.order_typeofunit.SelectedIndexChanged += new System.EventHandler(this.order_typeofunit_SelectedIndexChanged);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(15, 993);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(72, 26);
            this.label46.TabIndex = 143;
            this.label46.Text = "ทั้งหมด";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(127, 993);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(75, 26);
            this.label48.TabIndex = 145;
            this.label48.Text = "รายการ";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(483, 993);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(47, 26);
            this.label49.TabIndex = 148;
            this.label49.Text = "บาท";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(209, 993);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(133, 26);
            this.label51.TabIndex = 146;
            this.label51.Text = "เป็นจำนวนเงิน";
            // 
            // txt_count
            // 
            this.txt_count.Location = new System.Drawing.Point(85, 988);
            this.txt_count.Name = "txt_count";
            this.txt_count.ReadOnly = true;
            this.txt_count.Size = new System.Drawing.Size(42, 31);
            this.txt_count.TabIndex = 149;
            this.txt_count.Text = "0";
            this.txt_count.TextChanged += new System.EventHandler(this.txt_count_TextChanged);
            // 
            // txt_total
            // 
            this.txt_total.Location = new System.Drawing.Point(348, 988);
            this.txt_total.Name = "txt_total";
            this.txt_total.ReadOnly = true;
            this.txt_total.Size = new System.Drawing.Size(131, 31);
            this.txt_total.TabIndex = 150;
            this.txt_total.Text = "0";
            this.txt_total.TextChanged += new System.EventHandler(this.txt_total_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1965, 1503);
            this.Controls.Add(this.txt_total);
            this.Controls.Add(this.txt_count);
            this.Controls.Add(this.label49);
            this.Controls.Add(this.label51);
            this.Controls.Add(this.label48);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.box_district);
            this.Controls.Add(this.box_fund);
            this.Controls.Add(this.box_center);
            this.Controls.Add(this.box_biz);
            this.Controls.Add(this.box_institute);
            this.Controls.Add(this.btn_committeeCheck);
            this.Controls.Add(this.btn_personCheck);
            this.Controls.Add(this.btn_korGumNodPrBuyer);
            this.Controls.Add(this.txt_secretary2);
            this.Controls.Add(this.txt_committee2);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.txt_president2);
            this.Controls.Add(this.label45);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.btn_date);
            this.Controls.Add(this.btn_day);
            this.Controls.Add(this.txt_staff1);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.txt_phoneNo);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.txt_prDate);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.txt_no);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.txt_vendor);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.txt_day);
            this.Controls.Add(this.box_institutePw);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.order_lastPrice);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.order_boxProductType);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btn_korGumNod);
            this.Controls.Add(this.btn_check);
            this.Controls.Add(this.order_glPw);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.btn_print);
            this.Controls.Add(this.btn_clearOrder);
            this.Controls.Add(this.btn_removeOrder);
            this.Controls.Add(this.btn_addOrder);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.order_total);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.order_noUnit);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.order_unitPrice);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.order_productDetail);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.order_no);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.txt_leaderBuyer);
            this.Controls.Add(this.lbl_leaderBuyer);
            this.Controls.Add(this.txt_buyer);
            this.Controls.Add(this.lbl_buyer);
            this.Controls.Add(this.txt_secretary1);
            this.Controls.Add(this.txt_committee1);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.txt_president1);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.box_day);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.box_method);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txt_reason);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txt_product);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.box_prBuyer);
            this.Controls.Add(this.txt_name);
            this.Controls.Add(this.order_gl);
            this.Controls.Add(this.order_typeofunit);
            this.Name = "Form1";
            this.Text = "ระบบการจัดซื้อจัดจ้างที่ไม่มีERP ก่อนเข้าหน่วยพัสดุ ";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.order_no)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_no)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txt_product;
        private System.Windows.Forms.TextBox txt_reason;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox box_method;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox box_day;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txt_president1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txt_committee1;
        private System.Windows.Forms.TextBox txt_secretary1;
        private System.Windows.Forms.TextBox txt_leaderBuyer;
        private System.Windows.Forms.Label lbl_leaderBuyer;
        private System.Windows.Forms.TextBox txt_buyer;
        private System.Windows.Forms.Label lbl_buyer;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.NumericUpDown order_no;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox order_productDetail;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox order_unitPrice;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox order_noUnit;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox order_total;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Button btn_addOrder;
        private System.Windows.Forms.Button btn_removeOrder;
        private System.Windows.Forms.Button btn_clearOrder;
        private System.Windows.Forms.Button btn_print;
        public System.Windows.Forms.ComboBox box_prBuyer;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox order_glPw;
        private System.Windows.Forms.Button btn_check;
        private System.Windows.Forms.Button btn_korGumNod;
        private System.Windows.Forms.ToolTip toolTip_txt_reason;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox order_boxProductType;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox order_lastPrice;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox box_institutePw;
        private System.Windows.Forms.DateTimePicker txt_day;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txt_vendor;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.NumericUpDown txt_no;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.DateTimePicker txt_prDate;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox txt_phoneNo;
        private System.Windows.Forms.TextBox txt_staff1;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.RadioButton btn_day;
        private System.Windows.Forms.RadioButton btn_date;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox txt_secretary2;
        private System.Windows.Forms.TextBox txt_committee2;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox txt_president2;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Button btn_korGumNodPrBuyer;
        private System.Windows.Forms.CheckBox btn_personCheck;
        private System.Windows.Forms.CheckBox btn_committeeCheck;
        private SergeUtils.EasyCompletionComboBox box_institute;
        private SergeUtils.EasyCompletionComboBox box_biz;
        private SergeUtils.EasyCompletionComboBox box_center;
        private SergeUtils.EasyCompletionComboBox box_fund;
        private SergeUtils.EasyCompletionComboBox box_district;
        private SergeUtils.EasyCompletionComboBox txt_name;
        private SergeUtils.EasyCompletionComboBox order_gl;
        private SergeUtils.EasyCompletionComboBox order_typeofunit;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox txt_count;
        private System.Windows.Forms.TextBox txt_total;
    }
}

